#! python3
# -*- coding: utf-8 -*-
"""Block → Revit
Bước 1: chọn NHIỀU file CAD link (mỗi file 1 tầng) + tầng của từng file.
Bước 2: làm từng tầng (đổi file CAD ngay trong form, không phải tắt/bật tool) hoặc
bấm "Chạy tất cả tầng" để làm hàng loạt. Mỗi tầng làm lần lượt:
  1) Tường: đọc layer tường của file CAD rồi dựng tường Revit (2 nét/1 nét, nối qua cửa,
     căn lưới, khớp góc).
  2) Cửa đi & Cửa sổ: gán family bằng bảng có ảnh (family trong project hoặc nạp từ
     thư mục .rfa), tự tạo type theo chiều dài block, đặt vào tường.
  3) Nội thất: đặt family theo level từ block (căn tâm & hướng theo block); family có
     instance parameter kích thước (Width/Length/Depth...) thì kéo bằng block.
  4) Thang: dựng thang từ block thang (1 vế / nhiều vế).
  5) Sàn: đặt Room tự động rồi tạo sàn theo biên Room.
  + Nút "Reset family": đọc lại toàn bộ family trong project.
Giao diện sáng/tối (tự theo Revit, đổi tay bằng nút trên header)."""
import os
import re
import sys
import json
import math
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
# pyRevit CPython giữ module cũ trong bộ nhớ giữa các lần chạy -> buộc nạp lại bản mới
for _m in [m for m in list(sys.modules) if m.startswith("b2r_")]:
    del sys.modules[_m]

from pyrevit import revit
from Autodesk.Revit.DB import Transaction

import b2r_ui as UI
import b2r_api as API
import b2r_picker as PK
from b2r_ui import WF, Point, Size, T, STATE
from System import AppDomain
from System.Drawing import Icon, Color
import b2r_cad as CAD
import b2r_geom as G
import b2r_walls as WL
import b2r_build as B
import b2r_treads as TR
import b2r_furn as FU
import b2r_lib as LB

doc = revit.doc
uidoc = revit.uidoc
FORM_KEY = "B2R_FORM"
APP_TITLE = u"Block → Revit"
NONE_TEXT = u"—  bấm hoặc gõ chữ để chọn family  —"
MAP_FILE = os.path.join(HERE, "mapping.json")
BATCH = {"on": False, "log": [], "floor": u""}    # trạng thái chạy hàng loạt nhiều tầng


class forms(object):
    """Thay thế pyrevit.forms (không hỗ trợ trên CPython)."""

    @staticmethod
    def alert(msg, title=None, sub_msg=None, yes=False, no=False, exitscript=False):
        if BATCH["on"]:       # chạy hàng loạt: không bật hộp thoại, gom vào bảng tổng kết
            line = msg if not sub_msg else u"{} — {}".format(msg, u" | ".join(
                x for x in sub_msg.split(u"\n")[:3] if x.strip()))
            BATCH["log"].append((BATCH["floor"], line))
            UI.log(u"[{}] {}".format(BATCH["floor"], line))
            if exitscript:
                raise SystemExit
            return True if (yes or no) else None
        r = UI.alert(msg, title or APP_TITLE, sub_msg, yes_no=bool(yes or no))
        if exitscript:
            raise SystemExit
        return r


MM = 304.8
KIND_TXT = {"level": u"Theo level", "door": u"Cửa đi", "window": u"Cửa sổ",
            "wall": u"Treo tường"}


# ------------------------------------------------------------------ tiện ích
def load_map():
    try:
        with open(MAP_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_map(m):
    try:
        with open(MAP_FILE, "w", encoding="utf-8") as f:
            json.dump(m, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def safe(fn):
    def wrap(*a, **k):
        try:
            return fn(*a, **k)
        except Exception as ex:
            UI.log(traceback.format_exc())
            try:
                forms.alert(u"Có lỗi: {}\n\nChi tiết đã ghi vào Block2Revit.log "
                            u"(cùng thư mục tool).".format(ex), title=APP_TITLE)
            except Exception:
                pass
    return wrap


def apiw(fn):
    """Handler của form MODELESS: chạy trong API context của Revit (ExternalEvent) + bắt lỗi."""
    sf = safe(fn)
    h = API.api(sf)
    h.raw = sf       # bản gọi thẳng (đã ở API context) dùng cho chạy hàng loạt
    return h


def report(title, ok_line, problems):
    sub = u"\n".join(problems[:15])
    if len(problems) > 15:
        sub += u"\n… và {} mục khác (xem Block2Revit.log)".format(len(problems) - 15)
    for p in problems:
        UI.log(u"{}: {}".format(title, p))
    forms.alert(ok_line, title=title, sub_msg=sub or None)


def pick_family_gallery(symbols, title=u"Chọn family", kind_filter=u"all", initial=u"",
                        current=None):
    """Thư viện family dạng thẻ có ảnh + tìm kiếm thông minh (chạy trong API context)."""
    return PK.pick_family(symbols, title, kind_filter, initial, current)


# ------------------------------------------------------------------ BƯỚC 1: chọn nhiều CAD
def pick_cads(infos, lv_names):
    """Hộp thoại chọn nhiều file CAD link + tầng của từng file (đã tự đoán, sửa được).
    Trả list dict(label, obj, level, title) theo thứ tự tầng, hoặc None nếu huỷ."""
    sw, sh = UI.work_area()
    f = UI.new_dialog(u"Bước 1 · Chọn các file CAD (mỗi file 1 tầng)", min(980, sw - 60),
                      min(560, sh - 80), True)
    f.MinimumSize = Size(700, 360)
    top = UI.panel(WF.DockStyle.Top, 58, "toolbar")
    hint = UI.lbl(u"Tick các file CAD cần dùng và kiểm tra cột Tầng (tool tự đoán theo Level đặt "
                  u"CAD / tên file). Sang bước 2 bạn làm từng tầng hoặc chạy tất cả các tầng.",
                  16, 8, "sub")
    hint.AutoSize = False
    hint.SetBounds(16, 8, 900, 42)
    hint.Anchor = WF.AnchorStyles.Top | WF.AnchorStyles.Left | WF.AnchorStyles.Right
    top.Controls.Add(hint)
    grid = UI.make_grid()
    grid.RowTemplate.Height = 34
    grid.Columns.Add(UI.col_check("use", u"Dùng", 60))
    grid.Columns.Add(UI.col_text("cad", u"File CAD", 470))
    grid.Columns.Add(UI.col_combo("lv", u"Tầng (Level)", 200, lv_names))
    grid.Columns.Add(UI.col_text("src", u"Nguồn đoán tầng", 120))
    grid.DataError += lambda s, e: setattr(e, "ThrowException", False)
    for k, d in enumerate(infos):
        ri = grid.Rows.Add()
        row = grid.Rows[ri]
        row.Tag = k
        row.Cells["use"].Value = True
        row.Cells["cad"].Value = d["label"]
        row.Cells["lv"].Value = d["level"] if d["level"] in lv_names else None
        row.Cells["src"].Value = d["src"] or u"(chưa đoán được - hãy chọn)"
    bottom = UI.panel(WF.DockStyle.Bottom, 60, "bottom")
    ok = UI.btn(u"Tiếp tục  →", 0, 14, 130, 34, "primary")
    cancel = UI.btn(u"Hủy", 0, 14, 104, 34)
    cancel.DialogResult = WF.DialogResult.Cancel
    b_all = UI.btn(u"Chọn hết", 16, 14, 100, 34)
    b_none = UI.btn(u"Bỏ hết", 122, 14, 90, 34)
    for c in (ok, cancel, b_all, b_none):
        bottom.Controls.Add(c)
    UI.pin_right(bottom, cancel, 16)
    UI.pin_right(bottom, ok, 130)

    def set_all(v):
        grid.EndEdit()
        for r in grid.Rows:
            r.Cells["use"].Value = v
    b_all.Click += lambda s, e: set_all(True)
    b_none.Click += lambda s, e: set_all(False)
    res = {"v": None}

    def on_ok(s, e):
        grid.EndEdit()
        out, miss = [], []
        for r in grid.Rows:
            if not bool(r.Cells["use"].Value):
                continue
            lv = r.Cells["lv"].Value
            if lv not in lv_names:
                miss.append(str(r.Cells["cad"].Value))
                continue
            d = infos[int(r.Tag)]
            out.append({"label": d["label"], "obj": d["obj"], "level": lv,
                        "title": u"{}  →  {}".format(d["label"], lv)})
        if miss:
            UI.alert(u"Còn file CAD chưa chọn tầng:", APP_TITLE, u"\n".join(miss))
            return
        if not out:
            UI.alert(u"Hãy tick ít nhất 1 file CAD.", APP_TITLE)
            return
        res["v"] = out
        f.DialogResult = WF.DialogResult.OK
        f.Close()
    ok.Click += on_ok
    f.Controls.Add(grid)
    f.Controls.Add(top)
    f.Controls.Add(bottom)
    f.CancelButton = cancel
    UI.style_controls(f)
    UI.style_grid(grid)
    f.ShowDialog()
    f.Dispose()
    return res["v"]


def run_form(entries, symbols):
    S = UI.SET
    levels = B.get_levels(doc)
    lv_names = [l.Name for l in levels]
    lv_by = dict((l.Name, l) for l in levels)
    act_lv = B.active_level(doc)
    mapping = load_map()
    stair_types = B.get_stair_types(doc)
    # form MODELESS: đọc trước mọi thứ cần từ Revit, handler chỉ dùng dữ liệu thường
    lv_elev = dict((l.Name, l.Elevation) for l in levels)
    try:
        n_pre = UI.prefetch_previews([(k, v[0]) for k, v in symbols.items()
                                      if v[1] in ("door", "window", "level", "wall")], 72, 6.0)
        UI.log(u"Tạo trước {} ảnh family".format(n_pre))
    except Exception:
        pass

    form = WF.Form()
    form.Text = APP_TITLE
    form.Font = UI.font(9.5)
    _sw, _sh = UI.work_area()
    form.FormBorderStyle = WF.FormBorderStyle.Sizable     # kéo được cả 4 cạnh / 4 góc
    form.MaximizeBox = True
    form.MinimizeBox = True
    form.Size = Size(min(1180, _sw - 60), min(800, _sh - 60))
    form.MinimumSize = Size(min(760, _sw - 20), min(520, _sh - 20))   # thu nhỏ thoải mái
    form.StartPosition = WF.FormStartPosition.Manual
    form.Location = Point(max(0, _sw - form.Width - 40), 20)
    try:
        small = UI.load_logo(32)
        form.Icon = Icon.FromHandle(small.GetHicon())
    except Exception:
        pass

    # ---------------- header ----------------
    header = UI.panel(WF.DockStyle.Top, 146, "header")
    pic_logo = WF.PictureBox()
    pic_logo.Location = Point(16, 10)
    pic_logo.Size = Size(40, 40)
    pic_logo.SizeMode = WF.PictureBoxSizeMode.Zoom
    lbl_title = UI.lbl(APP_TITLE, 66, 7, "title")
    lbl_sub = UI.lbl(u"", 68, 36, "sub")
    btn_theme = UI.btn(u"", 1090, 12, 130, 32)
    btn_clrhl = UI.btn(u"✕  Xoá khoanh màu", 930, 12, 156, 32)
    btn_reset = UI.btn(u"↻  Reset family", 770, 12, 150, 32)
    tab_names = [u"1 · Tường", u"2 · Cửa đi / Cửa sổ", u"3 · Nội thất", u"4 · Thang", u"5 · Sàn"]
    tabs = []
    for i, nm in enumerate(tab_names):
        b = UI.btn(nm, 16 + i * 176, 100, 170, 40, "tab")
        tabs.append(b)
    line_h = WF.Panel()
    line_h.Tag = "line"
    line_h.Location = Point(0, 145)
    line_h.Size = Size(4000, 1)
    line_h.Anchor = WF.AnchorStyles.Top | WF.AnchorStyles.Left | WF.AnchorStyles.Right
    lbl_cad = UI.lbl(u"File CAD / Tầng:", 16, 66)
    cb_cad = UI.combo(138, 60, 520, [e["title"] for e in entries])
    btn_all = UI.btn(u"▶  Chạy tất cả tầng…", 672, 58, 210, 32, "primary")
    btn_all.Enabled = len(entries) > 1
    for c in [pic_logo, lbl_title, lbl_sub, lbl_cad, cb_cad, btn_all, btn_theme, btn_clrhl,
              btn_reset, line_h] + tabs:
        header.Controls.Add(c)
    UI.pin_right(header, btn_theme, 16)
    UI.pin_right(header, btn_clrhl, 154)
    UI.pin_right(header, btn_reset, 318)

    def lay_tabs(s_=None, e_=None):
        W = header.ClientSize.Width
        n = len(tabs)
        w = max(100, min(210, int((W - 32 - 4 * (n - 1)) / n)))
        for i, b in enumerate(tabs):
            b.SetBounds(16 + i * (w + 4), 100, w, 40)
        line_h.Width = W
    header.SizeChanged += lay_tabs

    CARRY = {}                    # lựa chọn mang từ tầng này sang tầng sau (layer, loại thang/sàn, ...)
    CUR = {"X": None, "idx": -1}  # nội dung (5 trang) của file CAD đang làm
    guard = {"busy": False}
    LAYOUTS, LAYOUTS_B = [], []
    host = UI.panel(WF.DockStyle.Fill)
    pages = []

    def build_content(entry, sc, act_lv):
        """Dựng 5 trang (Tường, Cửa, Nội thất, Thang, Sàn) cho 1 file CAD / 1 tầng.
        Gọi lại mỗi khi đổi file CAD: form giữ nguyên, chỉ thay các trang."""
        groups = CAD.group_blocks(sc)
        # ======================================================== TAB Cửa đi/Cửa sổ + TAB Nội thất
        DOOR_KW = (u"cửa", u"cua", u"door", u"cổng")
        WIN_KW = (u"cửa sổ", u"cua so", u"window", u"win")
        STAIR_KW = (u"thang", u"stair", u"step")
        sync = {"lock": False}
        pgs = []

        def _lows(g):
            s = set(ly.lower() for ly in g["layers"])
            s.update(n.lower() for n in g["names"])
            return s

        def win_like(g):
            return any(k in x for x in _lows(g) for k in WIN_KW)

        def door_like(g):
            return (not win_like(g)) and any(k in x for x in _lows(g) for k in DOOR_KW)

        def stair_like(g):
            return any(k in x for x in _lows(g) for k in STAIR_KW)

        sess = CARRY.setdefault("sess", {})   # family người dùng đã gán TRONG PHIÊN này (mang qua các tầng)
        ANON_RE = re.compile(r"^(block#\d+|\*.*|a\$c.*)$", re.I)     # tên block vô danh (hay trùng giữa các file CAD)
        NOISE_KW = (u"dim", u"text", u"ghi chú", u"ghi chu", u"trục", u"truc", u"lưới", u"luoi",
                    u"grid", u"defpoints", u"hatch", u"khung", u"title", u"axis", u"note", u"tên")

        def gkey(n):
            """Khóa gán = TÊN + HÌNH block: 'block#66' của file này không nhầm với 'block#66' của file khác."""
            try:
                fp = sc.defs[n]["fp"]
            except Exception:
                fp = u""
            return u"{}|{}".format(n.lower(), fp)

        def fpkey(g):
            """Khoá gán theo RIÊNG HÌNH block (không kèm tên): block giống hình ở tầng khác
            (tên vô danh Block#NN đổi lung tung giữa các file) vẫn nhận lại family đã gán."""
            d = g.get("defn") or {}
            fp = d.get("fp")
            return (u"fp|" + fp) if (fp and fp != "empty" and d.get("segs")) else None

        def keys_of(g):
            ks = [gkey(n) for n in g["names"]]
            fk = fpkey(g)
            if fk:
                ks.append(fk)
            return ks

        def mapped_key(g):
            """Family đã gán cho nhóm TRONG PHIÊN này (KHÔNG tự lấy từ mapping.json cũ):
            khớp tên+hình trước, không có thì khớp theo hình -> gán xong ở tầng 1 là các tầng
            sau tự điền cho mọi block giống hình."""
            got = [sess.get(gkey(n)) for n in g["names"]]
            got = [m for m in got if m and m.get("sym") in symbols]
            if got:
                return got[0]
            fk = fpkey(g)
            m = sess.get(fk) if fk else None
            return m if (m and m.get("sym") in symbols) else None

        def recall_for(g, kinds):
            """Gợi ý từ mapping.json (lần trước): khớp tên+hình; tên cũ chỉ nhận nếu KHÔNG phải tên vô danh."""
            fk = fpkey(g)
            m = mapping.get(fk) if fk else None
            if m and m.get("sym") in symbols and symbols[m["sym"]][1] in kinds:
                return m
            for n in g["names"]:
                m = mapping.get(gkey(n))
                if not m and not ANON_RE.match(n):
                    m = mapping.get(n.lower())
                if m and m.get("sym") in symbols and symbols[m["sym"]][1] in kinds:
                    return m
            return None

        def noise_like(g):
            return any(k in x for x in _lows(g) for k in NOISE_KW)

        def sig_index():
            """fp của MỌI hình block ở MỌI tầng -> chữ ký hình (không phụ thuộc xoay/lật) để nhận block
            'gần giống' giữa các tầng (mỗi tầng vẽ lệch vài nét thì dấu vân tay tuyệt đối không trùng)."""
            idx = CARRY.get("sigidx")
            if idx is None:
                idx = {}
                for e_ in entries:
                    sc_ = e_.get("sc")
                    if sc_ is None:
                        continue
                    seen = set()
                    for ins in sc_.insts:
                        d_ = sc_.defs.get(ins["name"]) or {}
                        fp_ = d_.get("fp")
                        if (not fp_) or fp_ == "empty" or (not d_.get("segs")) or ins["name"] in seen:
                            continue
                        seen.add(ins["name"])
                        if fp_ in idx:
                            continue
                        try:
                            idx[fp_] = FU.signature(CAD.inst_parts(sc_, ins)[0])
                        except Exception:
                            idx[fp_] = None
                CARRY["sigidx"] = idx
            return idx

        def group_sig(g):
            fp_ = (g.get("defn") or {}).get("fp")
            idx = sig_index()
            if fp_ in idx:
                return idx[fp_]
            try:
                sg = FU.signature(CAD.inst_parts(sc, g["insts"][0])[0])
            except Exception:
                sg = None
            idx[fp_] = sg
            return sg

        FZ_MIN = 0.80
        FZ_CACHE = {}

        def fuzzy_for(g, kinds, force=False):
            """Block GẦN GIỐNG (tầng khác / vẽ lệch vài nét) đã gán trong phiên này hoặc lưu trong mapping.json.
            Trả (độ giống, bản ghi) hoặc None."""
            if not (force or S.get("auto_recall", True)):
                return None
            sg = group_sig(g)
            if not sg:
                return None
            best = None
            seen = set()
            for src in (sess, mapping):
                for k, m in list(src.items()):
                    if (not k.startswith(u"fp|")) or k in seen:
                        continue
                    seen.add(k)
                    if (not m) or m.get("sym") not in symbols or symbols[m["sym"]][1] not in kinds:
                        continue
                    s2 = m.get("sig") or sig_index().get(k[3:])
                    if not s2:
                        continue
                    sc_ = FU.similar(sg, s2)
                    if sc_ >= FZ_MIN and (best is None or sc_ > best[0]):
                        best = (sc_, m)
            return best

        CAT_CACHE = {}

        def guess_cat(g):
            """(loại, độ tin cậy, lý do) - CHỈ theo tên layer của block (không đoán theo tên/hình/kích thước)."""
            key = (tuple(g["names"]), (g.get("defn") or {}).get("fp"))
            if key in CAT_CACHE:
                return CAT_CACHE[key]
            try:
                res = FU.cat_from_layers(list(g["layers"]))
            except Exception:
                res = ("other", 0.0, u"")
            CAT_CACHE[key] = res
            return res

        def commit_maps():
            """Gom gán family của các tab vào mapping (trong bộ nhớ)."""
            for p in pgs:
                sets, dels = p["collect"]()
                sess.update(sets)
                mapping.update(sets)
                for n in dels:
                    sess.pop(n, None)
                    mapping.pop(n, None)

        def regroup(val):
            if sync["lock"]:
                return
            sync["lock"] = True
            try:
                commit_maps()
                groups[:] = CAD.group_blocks(sc, bool(val))
                for p in pgs:
                    p["ck_merge"].Checked = bool(val)
                    p["fill"]()
                    p["filter"]()
            finally:
                sync["lock"] = False

        def WF_cell(row, name):
            class _V(object):
                pass
            v = _V()
            v.Text = str(row.Cells[name].Value or u"")
            return v

        def _no_throw(s, e):
            e.ThrowException = False

        # ---------------- zoom + KHOANH MÀU vùng của dòng đang chọn ----------------
        _bb_cache = {}
        HL = {"ids": []}
        RED, ORANGE = (255, 0, 0), (255, 140, 0)

        def inst_box(ins):
            k = id(ins)
            if k not in _bb_cache:
                try:
                    _bb_cache[k] = CAD.inst_bbox(sc, ins)
                except Exception:
                    _bb_cache[k] = (ins["tf"][0], ins["tf"][1], ins["tf"][0], ins["tf"][1])
            return _bb_cache[k]

        def rect_poly(b, pad=120.0):
            return [(b[0] - pad, b[1] - pad), (b[2] + pad, b[1] - pad),
                    (b[2] + pad, b[3] + pad), (b[0] - pad, b[3] + pad)]

        def wall_poly(w, pad=100.0):
            """Hình chữ nhật bao 1 tường (x0,y0,x1,y1,dày) mm, nới pad - để zoom + khoanh màu."""
            L = math.hypot(w[2] - w[0], w[3] - w[1]) or 1.0
            ux, uy = (w[2] - w[0]) / L, (w[3] - w[1]) / L
            nx, ny = -uy, ux
            h = w[4] / 2.0 + pad
            x0, y0, x1, y1 = w[0] - ux * pad, w[1] - uy * pad, w[2] + ux * pad, w[3] + uy * pad
            return [(x0 + nx * h, y0 + ny * h), (x1 + nx * h, y1 + ny * h),
                    (x1 - nx * h, y1 - ny * h), (x0 - nx * h, y0 - ny * h)]

        def poly_box(pts):
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            return (min(xs), min(ys), max(xs), max(ys))

        def hl_clear_now():
            """Xoá nét khoanh (gọi trong API context)."""
            if HL["ids"]:
                try:
                    HL["ids"] = B.hl_draw(doc, uidoc.ActiveView, HL["ids"], [])
                except Exception:
                    UI.log(traceback.format_exc())

        def show_polys(polys, i, margin, extra=None, zoom=True):
            """Zoom tới polys[i], khoanh ĐỎ đậm vị trí đó; các vị trí còn lại cùng dòng: khoanh CAM.
            extra: các nét vẽ thêm [(điểm, màu, độ dày)] vd hình thang tool sẽ dựng."""
            cur = polys[i]
            box = poly_box(cur)
            big = max(box[2] - box[0], box[3] - box[1])
            shapes = []
            others = [p for k, p in enumerate(polys) if k != i][:80]
            for p in others:
                shapes.append((p, ORANGE, 5))
            shapes.append((cur, RED, 9))
            ring = rect_poly(box, max(250.0, 0.15 * big))      # vòng khoanh ngoài cho dễ thấy
            shapes.append((ring, RED, 4))
            for sh_ in (extra or []):
                shapes.append(sh_)

            def job():
                HL["ids"] = B.hl_draw(doc, uidoc.ActiveView, HL["ids"], shapes)
                if zoom:
                    B.zoom_rect(uidoc, box[0], box[1], box[2], box[3], margin)
            API.post(job)

        def attach_zoom(grid, get_polys, info=None, skip_cols=(), margin=1500.0, extra_fn=None):
            """Chọn 1 dòng -> zoom + khoanh màu vị trí đầu tiên của dòng; bấm lại đúng dòng đó ->
            sang vị trí kế tiếp (đỏ = đang xem, cam = các vị trí còn lại của dòng)."""
            st = {"tag": None, "i": 0, "fresh": False}

            def do_zoom(row, cycle):
                polys = get_polys(row)
                if not polys:
                    return
                st["i"] = (st["i"] + 1) % len(polys) if cycle else 0
                st["tag"] = row.Tag
                if info is not None:
                    try:
                        info(u"Đang xem vị trí {}/{} trong Revit (khoanh đỏ)" + (
                            u" - bấm lại dòng này để sang vị trí kế tiếp" if len(polys) > 1 else u""),
                             st["i"] + 1, len(polys))
                    except Exception:
                        pass
                show_polys(polys, st["i"], margin, extra=extra_fn(row) if extra_fn else None)

            def sel_changed(s_, e_):
                try:
                    if not grid.ContainsFocus:
                        return
                    row = grid.CurrentRow
                    if row is None or row.Tag is None or row.Tag == st["tag"]:
                        return
                    st["fresh"] = True
                    do_zoom(row, False)
                except Exception:
                    UI.log(traceback.format_exc())

            def clicked(s_, e_):
                try:
                    if e_.RowIndex < 0:
                        return
                    fresh = st["fresh"]
                    st["fresh"] = False
                    if grid.Columns[e_.ColumnIndex].Name in skip_cols or fresh:
                        return
                    row = grid.Rows[e_.RowIndex]
                    do_zoom(row, row.Tag == st["tag"])
                except Exception:
                    UI.log(traceback.format_exc())
            grid.SelectionChanged += sel_changed
            grid.CellClick += clicked

        def do_load_folder(kinds):
            """Chọn folder -> chọn file .rfa -> nạp vào project. Trả {key: (sym, kind)} của các
            type vừa nạp (đúng loại của tab), hoặc None."""
            d = WF.FolderBrowserDialog()
            d.Description = u"Chọn thư mục chứa file family (.rfa)"
            old = S.get("fam_folder", u"")
            if old and os.path.isdir(old):
                d.SelectedPath = old
            if d.ShowDialog() != WF.DialogResult.OK:
                return None
            folder = d.SelectedPath
            S["fam_folder"] = folder
            UI.save_settings()
            files = []
            for root, _d, fns in os.walk(folder):
                for fn in fns:
                    low = fn.lower()
                    if low.endswith(".rfa") and not re.search(r"\.\d{4}\.rfa$", low):
                        files.append(os.path.join(root, fn))
            if not files:
                forms.alert(u"Không thấy file .rfa nào trong thư mục này.", title=APP_TITLE)
                return None
            labs = dict((os.path.relpath(p, folder), p) for p in files)
            sel = UI.select_list(sorted(labs.keys(), key=lambda s: s.lower()),
                                 u"Chọn file family cần nạp (tick nhiều file được)", True)
            if not sel:
                return None
            problems = []
            t = Transaction(doc, u"Nạp family từ thư mục")
            t.Start()
            try:
                stems = B.load_families(doc, [labs[k] for k in sel], problems)
                t.Commit()
            except Exception:
                t.RollBack()
                raise
            for k, v in B.get_symbols(doc).items():
                if k not in symbols:
                    symbols[k] = v
                    for p in pgs:
                        if v[1] in p["kinds"]:
                            pass
            sub = dict((k, v) for k, v in symbols.items()
                       if v[1] in kinds and any(k.startswith(s + u" : ") for s in stems))
            for p in problems:
                UI.log(u"Nạp family: " + p)
            if not sub:
                forms.alert(u"Đã nạp {} file nhưng không có type nào đúng loại của tab này "
                            u"(tab Cửa: cửa đi/cửa sổ; tab Nội thất: family đặt theo level).".format(
                                len(stems)),
                            title=APP_TITLE, sub_msg=u"\n".join(problems[:10]) or None)
                return None
            return sub

        def make_block_page(mode):
            hosted = mode in ("door", "window")
            kinds = (u"door", u"window") if hosted else (u"level", u"wall")
            page = UI.panel(WF.DockStyle.Fill)
            grid = UI.make_grid()
            grid.Columns.Add(UI.col_img("img", u"Block", 84))
            grid.Columns.Add(UI.col_text("name", u"Tên block (gộp theo hình)", 190))
            grid.Columns.Add(UI.col_text("qty", u"SL", 42))
            grid.Columns.Add(UI.col_text("dim", u"Kích thước (mm)", 100))
            if hosted:
                grid.Columns.Add(UI.col_combo("kind", u"Loại cửa\n(chọn trước)", 96,
                                              [KIND_TXT["door"], KIND_TXT["window"]]))
            famcol = UI.col_text("fam", u"Family đặt  (bấm vào ô hoặc gõ chữ để tìm)", 300)
            grid.Columns.Add(famcol)
            grid.Columns.Add(UI.col_img("fimg", u"Family", 84))
            if not hosted:
                grid.Columns.Add(UI.col_text("kind", u"Loại", 78))
                grid.Columns.Add(UI.col_combo("cat", u"Loại nội thất\n(theo layer, sửa được)", 130,
                                              FU.CAT_LABELS))
                grid.Columns.Add(UI.col_check("fit", u"Co giãn\ntheo block", 70))
            grid.Columns.Add(UI.col_text("w", u"Rộng (mm)\n(trống = tự đo)", 98, False))
            grid.Columns.Add(UI.col_text("h", u"Cao (mm)" if hosted else u"Cao (mm)\n(trống = giữ nguyên)",
                                         70 if hosted else 110, False))
            grid.Columns.Add(UI.col_text("sill", u"Cao đáy (mm)", 84, False))
            grid.Columns.Add(UI.col_text("z", u"Z offset (mm)", 84, False))
            grid.Columns.Add(UI.col_text("rot", u"Xoay thêm (°)\n(0/90/180/270)" if hosted else
                                         u"Lệch mặt trước (°)\n(0/90/180/270)", 110, False))
            for cn in ((u"z", u"rot") if hosted else (u"w", u"sill")):
                grid.Columns[cn].Visible = False
            grid.ColumnHeadersHeight = 44
            grid.DataError += _no_throw

            tb = UI.panel(WF.DockStyle.Top, 206 if not hosted else 140, "toolbar")
            tb_filter = UI.txt(0, 0, 180)
            VIEW_ITEMS = [u"Block đúng loại của tab", u"Chưa gán family", u"Đã gán (sẽ đặt)",
                          u"Tất cả block (kể cả loại khác)"]
            cb_view = UI.combo(0, 0, 270, VIEW_ITEMS)
            cb_view.SelectedIndex = 0
            dirty = set()                  # dòng (chỉ số nhóm) người dùng vừa sửa - chỉ các dòng này mới ghi vào mapping
            ld = {"on": False}             # đang nạp lưới bằng code: không tính là người dùng sửa
            ck_merge = UI.chk(u"Gộp block giống hình (khác tên)", 0, 0, True)
            layer_map = {}
            layer_items = [u"(tất cả layer)"]
            for ly in sorted(set(ly for g in groups for ly in g["layers"])):
                lab = u"{}  ({} block)".format(ly, sc.layers_blocks.get(ly, 0))
                layer_map[lab] = ly
                layer_items.append(lab)
            cb_layer = UI.combo(0, 0, 210, layer_items)
            cb_layer.SelectedIndex = 0
            cb_level = UI.combo(0, 0, 200, lv_names)
            cb_level.SelectedItem = act_lv.Name
            tb_radius = UI.txt(0, 0, 56, str(int(S.get("radius", 600))))
            ck_swing = UI.chk(u"Đảo hướng mở cửa", 0, 0, bool(S.get("flip_swing", False)))
            ck_hinge = UI.chk(u"Đảo bản lề", 0, 0, bool(S.get("flip_hinge", False)))
            ck_align = UI.chk(u"Tự khớp hướng & căn tâm family theo hình block", 0, 0,
                              bool(S.get("align", True)))
            ck_front = UI.chk(u"Đặt theo mặt trước (hiểu giường, tủ, wc...)", 0, 0,
                              bool(S.get("use_front", True)))
            ck_recall = UI.chk(u"Tự điền block giống từ tầng / lần trước", 0, 0,
                               bool(S.get("auto_recall", True)))
            ck_find = UI.chk(u"Tự tìm & nạp family theo layer (model + thư viện) cho dòng chưa gán", 0, 0,
                             bool(S.get("auto_find", True)))

            btn_assign = UI.btn(u"Chọn family cho dòng đang chọn…", 0, 0, 280, 32, "primary")
            btn_folder = UI.btn(u"Nạp family từ thư mục…", 0, 0, 220, 32)
            btn_clearfam = UI.btn(u"Bỏ gán", 0, 0, 90, 32)
            btn_recall = UI.btn(u"Điền family đã nhớ (lần trước)", 0, 0, 280, 32)
            btn_find = UI.btn(u"Tự tìm family theo layer", 0, 0, 220, 32)
            rows = [
                [UI.lbl(u"Lọc tên block:", 0, 0), tb_filter, UI.lbl(u"Layer:", 0, 0), cb_layer],
                [UI.lbl(u"Hiển thị:", 0, 0), cb_view, ck_merge, ck_recall],
            ]
            if hosted:
                rows.append([UI.lbl(u"Level đặt:", 0, 0), cb_level,
                             UI.lbl(u"Tường gần nhất trong (mm):", 0, 0), tb_radius, ck_swing, ck_hinge])

            else:
                rows.append([UI.lbl(u"Level đặt:", 0, 0), cb_level, ck_align, ck_front])
                rows.append([ck_find])
            rows.append([btn_assign, btn_folder, btn_clearfam, btn_recall] +
                        ([btn_find] if not hosted else []))
            for r in rows:
                for c in r:
                    tb.Controls.Add(c)
            LAYOUTS.append((tb, rows))

            bt = UI.panel(WF.DockStyle.Bottom, 64, "bottom")
            btn_save = UI.btn(u"Lưu mapping", 16, 14, 120)
            lbl_stat = UI.lbl(u"", 150, 21, "sub")
            btn_place = UI.btn({"door": u"Đặt cửa đi / cửa sổ"}.get(mode, u"Đặt nội thất"),
                               0, 12, 200, 40, "primary")
            for c in (btn_save, lbl_stat, btn_place):
                bt.Controls.Add(c)
            LAYOUTS_B.append((bt, btn_save, lbl_stat, btn_place))
            page.Controls.Add(grid)
            page.Controls.Add(tb)
            page.Controls.Add(bt)

            def block_dim(g):
                d = g["defn"]
                if not d["segs"]:
                    return u""
                xs = [s[0] for s in d["segs"]] + [s[2] for s in d["segs"]]
                ys = [s[1] for s in d["segs"]] + [s[3] for s in d["segs"]]
                tf = g["insts"][0]["tf"]
                return u"{:.0f} × {:.0f}".format((max(xs) - min(xs)) * math.hypot(tf[2], tf[3]),
                                                  (max(ys) - min(ys)) * math.hypot(tf[4], tf[5]))

            def refresh_row(row):
                key = row.Cells["fam"].Value
                it = symbols.get(key) if key else None
                if not it:
                    row.Cells["fimg"].Value = None
                    if not hosted:
                        row.Cells["kind"].Value = u""
                    return
                sym, kind = it
                img = UI.fam_preview_cached(key, 72)
                row.Cells["fimg"].Value = img
                if img is None:
                    def _job(row=row, key=key, sym=sym):
                        try:
                            if row.Cells["fam"].Value == key:
                                row.Cells["fimg"].Value = UI.fam_preview(key, sym, 72)
                        except Exception:
                            pass
                    try:
                        API.post(_job)
                    except Exception:
                        pass
                row.Cells["kind"].Value = KIND_TXT[kind]
                if hosted:
                    if not str(row.Cells["h"].Value or u"").strip():
                        row.Cells["h"].Value = u"2100" if kind == "door" else u"1500"
                    if not str(row.Cells["sill"].Value or u"").strip():
                        row.Cells["sill"].Value = u"0" if kind == "door" else u"900"
                else:
                    if str(row.Cells["rot"].Value or u"").strip() in (u"", u"0"):
                        _fr = sess.get(u"fam|" + key) or mapping.get(u"fam|" + key)
                        row.Cells["rot"].Value = (str((_fr or {}).get("rot", u"0")) if _fr else u"0")
                    _zs = str(row.Cells["z"].Value or u"").strip()
                    if kind == "wall":
                        if _zs in (u"", u"0"):
                            row.Cells["z"].Value = u"1000"     # treo tường: cao độ mặc định so với level
                    elif not _zs:
                        row.Cells["z"].Value = u"0"

            def mapped_fuzzy(g):
                """(bản ghi, độ giống|None): đã gán trong phiên -> nhớ chính xác từ mapping.json ->
                block gần giống. Chỉ dòng người dùng sửa/đặt mới ghi lại mapping."""
                m = mapped_key(g)
                if m is not None:
                    return m, None
                if not S.get("auto_recall", True):
                    return None, None
                m = recall_for(g, kinds)
                if m is not None:
                    return m, None
                best = fuzzy_for(g, kinds)
                if best:
                    return best[1], best[0]
                return None, None

            def type_match(g):
                if hosted:
                    return door_like(g) or win_like(g)
                return (not door_like(g)) and (not win_like(g)) and (not stair_like(g)) \
                    and (not noise_like(g))

            def in_page(g, m):
                mode = cb_view.SelectedIndex
                if mode == 3:
                    return True
                here = m is not None and symbols[m["sym"]][1] in kinds
                other = m is not None and not here          # đã gán ở tab khác (vd cửa) -> không hiện ở tab này
                if mode == 2:
                    return here
                if mode == 1:
                    return (not here) and (not other) and type_match(g)
                return here or ((not other) and type_match(g))

            def update_stat():
                assigned = objs = 0
                for row in grid.Rows:
                    if row.Cells["fam"].Value in symbols:
                        assigned += 1
                        objs += len(groups[int(row.Tag)]["insts"])
                lbl_stat.Text = u"{} dòng  ·  đã gán {}  ·  sẽ đặt {} đối tượng".format(
                    grid.Rows.Count, assigned, objs)

            def fill():
                ld["on"] = True
                try:
                    _fill_rows()
                finally:
                    ld["on"] = False
                update_stat()

            def _fill_rows():
                grid.Rows.Clear()
                dirty.clear()
                for gi, g in enumerate(groups):
                    m, fz = mapped_fuzzy(g)
                    if not in_page(g, m):
                        continue
                    ri = grid.Rows.Add()
                    row = grid.Rows[ri]
                    row.Tag = gi
                    row.Cells["img"].Value = UI.draw_segs(g["defn"]["segs"], 72)
                    nm = u", ".join(g["names"])
                    _ss = set(sess[gkey(n)]["sym"] for n in g["names"]
                              if sess.get(gkey(n)) and sess[gkey(n)].get("sym") in symbols
                              and symbols[sess[gkey(n)]["sym"]][1] in kinds)
                    if len(_ss) > 1:           # các block giống hình đang gán family khác nhau
                        nm += u"  ⚠ (đang gán {} family khác nhau - bỏ 'Gộp' để xem riêng)".format(len(_ss))
                    row.Cells["name"].Value = nm
                    row.Cells["name"].ToolTipText = nm + (u"\n(các tên này có hình giống nhau)"
                                                          if len(g["names"]) > 1 else u"")
                    row.Cells["qty"].Value = str(len(g["insts"]))
                    row.Cells["dim"].Value = block_dim(g)
                    if hosted:
                        if m is not None and symbols[m["sym"]][1] in kinds:
                            row.Cells["kind"].Value = KIND_TXT[symbols[m["sym"]][1]]
                        else:
                            row.Cells["kind"].Value = KIND_TXT["window" if win_like(g) else "door"]
                    if m is not None and symbols[m["sym"]][1] in kinds:
                        row.Cells["fam"].Value = m["sym"]
                        for c in ("w", "h", "sill", "z", "rot"):
                            row.Cells[c].Value = m.get(c, u"")
                        if (not hosted) and not m.get("v"):
                            row.Cells["rot"].Value = u"0"     # bản ghi cũ: 'xoay thêm' kiểu cũ không còn đúng
                        if fz is not None:
                            row.DefaultCellStyle.BackColor = Color.FromArgb(255, 236, 170)
                            row.DefaultCellStyle.ForeColor = Color.FromArgb(40, 40, 40)
                            row.Cells["name"].ToolTipText = (
                                u"{}\nKhớp GẦN GIỐNG {:.0f}% với block đã gán - kiểm tra lại "
                                u"(đặt xong sẽ được nhớ).".format(nm, fz * 100.0))
                    else:
                        row.Cells["fam"].Value = NONE_TEXT
                    if not hosted:
                        _ct = guess_cat(g)[0]          # loại theo LAYER luôn thắng bản ghi cũ
                        if _ct == "other":
                            _ct = (m or {}).get("cat") if (m is not None and symbols.get(m.get("sym"))) else None
                            if _ct not in FU.CAT_LABEL:
                                _ct = "other"
                        row.Cells["cat"].Value = FU.CAT_LABEL.get(_ct, FU.CAT_LABEL["other"])
                        row.Cells["fit"].Value = (str((m or {}).get("fit", u"1")) != u"0")
                    refresh_row(row)

            def apply_filter():
                q = tb_filter.Text.strip()
                only = False
                ly = layer_map.get(cb_layer.Text)
                grid.CurrentCell = None
                for row in grid.Rows:
                    g = groups[int(row.Tag)]
                    vis = True
                    if q and UI.smart_score(q, u" ".join(list(g["names"]) + list(g["layers"]))) <= 0:
                        vis = False
                    if only and row.Cells["fam"].Value in symbols:
                        vis = False
                    if ly and ly not in g["layers"]:
                        vis = False
                    row.Visible = vis
                    if not vis and row.Selected:
                        row.Selected = False       # dòng ẩn không được còn "đang chọn" (tránh gán nhầm)
                update_stat()

            def g_changed(s, e):
                if e.RowIndex < 0 or ld["on"]:
                    return
                try:
                    dirty.add(int(grid.Rows[e.RowIndex].Tag))
                except Exception:
                    pass
                cname = grid.Columns[e.ColumnIndex].Name
                if cname == "fam":
                    refresh_row(grid.Rows[e.RowIndex])
                    update_stat()
                elif cname == "kind" and hosted:
                    row = grid.Rows[e.RowIndex]
                    want = row_kind(row)
                    it = symbols.get(row.Cells["fam"].Value)
                    if it is not None and it[1] != want:
                        row.Cells["fam"].Value = NONE_TEXT       # family cũ sai loại -> bỏ chọn
                    # chiều cao / cao đáy mặc định theo loại mới (nếu chưa tự sửa)
                    if str(row.Cells["h"].Value or u"").strip() in (u"", u"2100", u"1500"):
                        row.Cells["h"].Value = u"2100" if want == "door" else u"1500"
                    if str(row.Cells["sill"].Value or u"").strip() in (u"", u"0", u"900"):
                        row.Cells["sill"].Value = u"0" if want == "door" else u"900"
                    update_stat()
            grid.CellValueChanged += g_changed
            grid.CurrentCellDirtyStateChanged += lambda s, e: grid.CommitEdit(
                WF.DataGridViewDataErrorContexts.Commit)
            ck_merge.CheckedChanged += lambda s, e: regroup(ck_merge.Checked)

            def on_view(s, e):
                if sync["lock"]:
                    return
                commit_maps()
                fill()
                apply_filter()
            cb_view.SelectedIndexChanged += on_view
            def on_recall_tick(s, e):
                if sync["lock"] or ld["on"]:
                    return
                S["auto_recall"] = bool(ck_recall.Checked)
                commit_maps()
                fill()
                apply_filter()
            ck_recall.CheckedChanged += on_recall_tick
            tb_filter.TextChanged += lambda s, e: apply_filter()
            cb_layer.SelectedIndexChanged += lambda s, e: apply_filter()

            def collect():
                sets, dels = {}, []
                for row in grid.Rows:
                    if int(row.Tag) not in dirty:
                        continue               # dòng không sửa: giữ nguyên mapping từng block
                    g = groups[int(row.Tag)]
                    key = row.Cells["fam"].Value
                    for nl in keys_of(g):
                        if key in symbols:
                            sets[nl] = {"sym": key,
                                        "w": str(row.Cells["w"].Value or u""),
                                        "h": str(row.Cells["h"].Value or u""),
                                        "sill": str(row.Cells["sill"].Value or u""),
                                        "z": str(row.Cells["z"].Value or u""),
                                        "rot": str(row.Cells["rot"].Value or u""),
                                        "v": 2}
                            try:
                                _sg = group_sig(g)
                                if _sg:
                                    sets[nl]["sig"] = _sg
                            except Exception:
                                pass
                            if not hosted:
                                sets[nl]["cat"] = FU.LABEL_CAT.get(str(row.Cells["cat"].Value or u""),
                                                                   "other")
                                sets[nl]["fit"] = u"1" if bool(row.Cells["fit"].Value) else u"0"
                                sets[u"fam|" + key] = {"sym": key, "v": 2,
                                                       "rot": str(row.Cells["rot"].Value or u"0")}
                        else:
                            old = sess.get(nl)
                            if old and old.get("sym") in symbols and symbols[old["sym"]][1] in kinds:
                                dels.append(nl)
                dirty.clear()
                return sets, dels

            KIND2 = {KIND_TXT["door"]: "door", KIND_TXT["window"]: "window"}

            def row_kind(row):
                """Loại cửa của dòng (đã chọn ở cột 'Loại cửa')."""
                return KIND2.get(str(row.Cells["kind"].Value or u""), "door")

            def kind_symbols(kf=None):
                return dict((k, v) for k, v in symbols.items()
                            if v[1] in kinds and (kf is None or v[1] == kf))

            def sel_kind(rows_sel):
                """Loại cửa chung của các dòng đang chọn; None nếu không phải trang cửa;
                u'mixed' nếu lẫn cửa đi và cửa sổ."""
                if not hosted:
                    return None
                ks = set(row_kind(r) for r in rows_sel)
                if len(ks) == 1:
                    return list(ks)[0]
                return u"mixed"

            def assign_dialog(rows_sel, initial=u""):
                """Mở thư viện family cho các dòng đã chọn (chạy trong API context)."""
                if not rows_sel:
                    forms.alert(u"Hãy chọn (bôi đen) các dòng cần gán trước.", title=APP_TITLE)
                    return
                kf = sel_kind(rows_sel)
                if kf == u"mixed":
                    forms.alert(u"Các dòng đang chọn lẫn cửa đi và cửa sổ. Hãy chọn các dòng cùng "
                                u"'Loại cửa' (cột Loại cửa) rồi gán family.", title=APP_TITLE)
                    return
                cur = rows_sel[0].Cells["fam"].Value
                key = pick_family_gallery(kind_symbols(kf), kind_filter=kf or u"all",
                                          initial=initial, current=cur if cur in symbols else None)
                if key:
                    for r in rows_sel:
                        r.Cells["fam"].Value = key
                    apply_filter()             # đang lọc "chưa gán" thì dòng vừa gán biến mất ngay

            @apiw
            def on_assign(s, e):
                assign_dialog([r for r in grid.SelectedRows if r.Visible])
            btn_assign.Click += on_assign

            def sel_rows_of(row_index):
                sel = [r for r in grid.SelectedRows if r.Visible]
                row = grid.Rows[row_index]
                return sel if row in sel else [row]

            @apiw
            def on_fam_click(s, e):
                if e.RowIndex < 0 or grid.Columns[e.ColumnIndex].Name != "fam":
                    return
                assign_dialog(sel_rows_of(e.RowIndex))
            grid.CellClick += on_fam_click

            @apiw
            def on_cell_dbl(s, e):
                if e.RowIndex < 0 or grid.Columns[e.ColumnIndex].Name in ("fam", "kind"):
                    return
                if grid.Columns[e.ColumnIndex].Name in ("w", "h", "sill", "z", "rot"):
                    return
                assign_dialog(sel_rows_of(e.RowIndex))
            grid.CellDoubleClick += on_cell_dbl

            TYPE_OK = ("fam", "name", "img", "dim", "qty", "fimg")

            def on_keypress(s, e):
                """Chọn dòng rồi gõ chữ/số (vd 's') -> mở thư viện family đã tìm sẵn 's'."""
                try:
                    ch = str(e.KeyChar)
                    cur = grid.CurrentCell
                    if cur is None or grid.IsCurrentCellInEditMode:
                        return
                    if grid.Columns[cur.ColumnIndex].Name not in TYPE_OK:
                        return
                    if len(ch) != 1 or not (ch.isalnum() or ch in u"-_."):
                        return
                    e.Handled = True
                    rows_ = sel_rows_of(cur.RowIndex)
                    API.post(safe(lambda: assign_dialog(rows_, ch)))
                except Exception:
                    UI.log(traceback.format_exc())
            grid.KeyPress += on_keypress

            def fam_fmt(s, e):
                try:
                    if e.RowIndex >= 0 and grid.Columns[e.ColumnIndex].Name == "fam":
                        v = e.Value
                        if v == NONE_TEXT or v is None:
                            e.CellStyle.ForeColor = T()["sub"]
                            e.CellStyle.Font = UI.font(9, False)
                        else:
                            e.CellStyle.Font = UI.font(9.5, True)
                except Exception:
                    pass
            grid.CellFormatting += fam_fmt

            @apiw
            def on_folder(s, e):
                sub = do_load_folder(kinds)
                if not sub:
                    return
                rows_sel = [r for r in grid.SelectedRows if r.Visible]
                if not rows_sel:
                    forms.alert(u"Đã nạp family vào project.\nBôi đen các dòng rồi bấm vào ô Family "
                                u"(hoặc gõ chữ) để chọn.", title=APP_TITLE)
                    return
                kf = sel_kind(rows_sel)
                if kf == u"mixed":
                    forms.alert(u"Các dòng đang chọn lẫn cửa đi và cửa sổ. Hãy chọn các dòng cùng "
                                u"'Loại cửa' rồi gán family.", title=APP_TITLE)
                    return
                if kf:
                    sub = dict((k, v) for k, v in sub.items() if v[1] == kf)
                if not sub:
                    forms.alert(u"Các family vừa nạp không có type loại này.", title=APP_TITLE)
                    return
                key = pick_family_gallery(sub, kind_filter=kf or u"all")
                if key:
                    for r in rows_sel:
                        r.Cells["fam"].Value = key
                    apply_filter()
            btn_folder.Click += on_folder

            @safe
            def on_clear_fam(s, e):
                for r in [r for r in grid.SelectedRows if r.Visible]:
                    r.Cells["fam"].Value = NONE_TEXT
                apply_filter()
            btn_clearfam.Click += on_clear_fam

            @safe
            def on_recall(s, e):
                """Điền family đã gán ở các lần trước cho các dòng CHƯA gán đang hiển thị (không tự làm)."""
                n = 0
                for row in grid.Rows:
                    if not row.Visible or row.Cells["fam"].Value in symbols:
                        continue
                    m = recall_for(groups[int(row.Tag)], kinds)
                    if m is None:
                        _b = fuzzy_for(groups[int(row.Tag)], kinds, True)
                        m = _b[1] if _b else None
                    if m is None:
                        continue
                    row.Cells["fam"].Value = m["sym"]
                    for c in ("w", "h", "sill", "z", "rot"):
                        if m.get(c):
                            row.Cells[c].Value = m.get(c, u"")
                    n += 1
                apply_filter()
                lbl_stat.Text = (u"Đã điền {} dòng từ family đã nhớ - kiểm tra lại rồi mới Đặt".format(n)
                                 if n else u"Không có family đã nhớ nào khớp (tên + hình) với các dòng đang hiện")
            btn_recall.Click += on_recall

            @safe
            def on_save(s, e):
                commit_maps()
                save_map(mapping)
                lbl_stat.Text = u"Đã lưu mapping → mapping.json"
            btn_save.Click += on_save

            # ---------------- TỰ TÌM FAMILY THEO LAYER (model + thư viện .rfa) ----------------
            def lib_files():
                """File .rfa trong thư viện (settings 'fam_folder'); chưa có thư mục thì hỏi 1 lần."""
                folder = S.get("fam_folder", u"")
                if not (folder and os.path.isdir(folder)):
                    if CARRY.get("lib_asked"):
                        return []
                    CARRY["lib_asked"] = True
                    d = WF.FolderBrowserDialog()
                    d.Description = u"Chọn thư mục THƯ VIỆN family (.rfa) để tool tự tìm family theo layer"
                    if d.ShowDialog() != WF.DialogResult.OK:
                        return []
                    folder = d.SelectedPath
                    S["fam_folder"] = folder
                    UI.save_settings()
                cache = CARRY.setdefault("libidx", {})
                if cache.get("folder") != folder:
                    cache["folder"] = folder
                    cache["files"] = LB.scan_folder(folder)
                    UI.log(u"Thư viện family '{}': {} file .rfa".format(folder, len(cache["files"])))
                return cache["files"]

            def block_ab(g):
                """(dài, ngắn) mm của THÂN block (bỏ cung mở cánh, nét rời) - dùng chọn family theo kích thước."""
                try:
                    body, _a, _s = CAD.inst_parts(sc, g["insts"][0])
                    r = FU.body_rect(body)
                    return (r[2], r[3]) if r else None
                except Exception:
                    return None

            def auto_find(rows_, force=False):
                """Với từng dòng nội thất chưa gán: loại (theo layer) -> chọn family trong model/thư viện theo tên
                + kích thước -> nạp file .rfa còn thiếu vào model -> chọn type gần kích thước -> điền vào dòng.
                Trả (số dòng điền, [ghi chú])."""
                notes = []
                todo_ = []
                for row in rows_:
                    if (not force) and row.Cells["fam"].Value in symbols:
                        continue
                    cat = FU.LABEL_CAT.get(str(row.Cells["cat"].Value or u""), "other")
                    if cat in ("other", "accessory"):
                        continue
                    todo_.append((row, cat))
                if not todo_:
                    return 0, notes
                cands = LB.make_candidates(symbols, lib_files(), ("level", "wall"))
                picks = []
                for row, cat in todo_:
                    g = groups[int(row.Tag)]
                    ab = block_ab(g)
                    r = LB.choose(cat, cands, ab)
                    if r is None:
                        notes.append(u"Không tìm thấy family '{}' cho {} (x{}, {})".format(
                            FU.CAT_LABEL.get(cat, cat), g["names"][0], len(g["insts"]),
                            u"{:.0f}x{:.0f}".format(ab[0], ab[1]) if ab else u"?"))
                        continue
                    picks.append((row, cat, ab, r))
                paths = sorted(set(r[1]["path"] for _r, _c, _a, r in picks if r[1]["path"]))
                if paths:
                    problems_ = []
                    t_ = Transaction(doc, u"Nạp family theo layer")
                    t_.Start()
                    try:
                        B.load_families(doc, paths, problems_)
                        t_.Commit()
                    except Exception:
                        t_.RollBack()
                        raise
                    for p_ in problems_:
                        UI.log(u"Nạp family: " + p_)
                        notes.append(u"Nạp family lỗi: " + p_)
                    for k_, v_ in B.get_symbols(doc).items():
                        if k_ not in symbols:
                            symbols[k_] = v_
                n_ok = 0
                for row, cat, ab, (score, cand) in picks:
                    key = cand["key"]
                    if cand["path"]:
                        stem = cand["fam"]
                        tys = [k_ for k_, v_ in symbols.items()
                               if v_[1] in ("level", "wall") and k_.split(u" : ")[0] == stem]
                        key = LB.pick_type(tys, ab)
                    if not key or key not in symbols:
                        notes.append(u"Đã nạp '{}' nhưng không có type đặt theo level".format(cand["label"]))
                        continue
                    row.Cells["fam"].Value = key
                    row.DefaultCellStyle.BackColor = Color.FromArgb(255, 236, 170)
                    row.DefaultCellStyle.ForeColor = Color.FromArgb(40, 40, 40)
                    row.Cells["name"].ToolTipText = (
                        u"Tự tìm theo layer ({}): {}  (điểm {:.2f}) - kiểm tra lại, đặt xong sẽ được nhớ.".format(
                            FU.CAT_LABEL.get(cat, cat), key, score))
                    UI.log(u"[TỰ TÌM] {} (x{}) layer={} loại={} cỡ={} -> {} (điểm {:.2f}{})".format(
                        groups[int(row.Tag)]["names"][0], len(groups[int(row.Tag)]["insts"]),
                        u",".join(sorted(groups[int(row.Tag)]["layers"])), cat,
                        u"{:.0f}x{:.0f}".format(ab[0], ab[1]) if ab else u"?", key, score,
                        u", vừa nạp từ thư viện" if cand["path"] else u""))
                    n_ok += 1
                return n_ok, notes

            @apiw
            def on_find(s, e):
                rows_ = [r for r in grid.Rows if r.Visible]
                n, notes = auto_find(rows_)
                apply_filter()
                lbl_stat.Text = u"Đã tự tìm family cho {} dòng (tô vàng) - kiểm tra lại rồi Đặt".format(n)
                if notes:
                    report(APP_TITLE, u"Đã tự tìm family cho {} dòng.".format(n), notes)
            btn_find.Click += on_find

            def cad_wall_faces():
                """Không có tường Revit: dùng nét tường trong CAD (layer tường đã chọn ở tab Tường)."""
                try:
                    want = set(wst["layers"])
                except Exception:
                    want = set()
                out = []
                for ly, segs_ in sc.segs_by_layer.items():
                    low = ly.lower()
                    if ly in want or (not want and any(k in low for k in (u"tường", u"tuong", u"wall"))):
                        for sg in segs_:
                            if math.hypot(sg[2] - sg[0], sg[3] - sg[1]) >= 300.0:
                                out.append((sg[0], sg[1], sg[2], sg[3]))
                return out

            def dbg_place(rec, inst_, info, famkey):
                """Ghi log số liệu thật của từng món đặt: vị trí block CAD / vị trí family sau khi đặt / độ lệch."""
                try:
                    segs_ = CAD.inst_segs(sc, rec)
                    xs = [q[0] for q in segs_] + [q[2] for q in segs_]
                    ys = [q[1] for q in segs_] + [q[3] for q in segs_]
                    if xs:
                        bc = ((max(xs) + min(xs)) / 2.0, (max(ys) + min(ys)) / 2.0,
                              max(xs) - min(xs), max(ys) - min(ys))
                    else:
                        bc = (rec["tf"][0], rec["tf"][1], 0.0, 0.0)
                    fb = B._bbox_xy(inst_) or (0.0, 0.0, 0.0, 0.0)
                    if info is not None:
                        r_ = info["rect"]
                        fr = u"loại={} thân={:.0f}x{:.0f} tâm thân=({:.0f},{:.0f}) mặt trước={} tin cậy={:.2f} [{}]".format(
                            info.get("cat"), r_[2], r_[3], r_[0], r_[1],
                            (u"({:.2f},{:.2f})".format(info["face"][0], info["face"][1])
                             if info.get("face") else u"chưa biết"), info.get("conf", 0.0),
                            info.get("how", u""))
                    else:
                        fr = u"không phân tích được thân block"
                    UI.log(u"[ĐẶT] {} gốc=({:.0f},{:.0f}) tâm nét=({:.0f},{:.0f}) cỡ nét={:.0f}x{:.0f} | "
                           u"{} | family '{}' tâm=({:.0f},{:.0f}) cỡ={:.0f}x{:.0f} | lệch=({:.0f},{:.0f})".format(
                               rec["name"], rec["tf"][0], rec["tf"][1], bc[0], bc[1], bc[2], bc[3], fr,
                               famkey, fb[0], fb[1], fb[2], fb[3], fb[0] - bc[0], fb[1] - bc[1]))
                except Exception:
                    UI.log(traceback.format_exc())

            def compute_fronts(level):
                """{id(block): thông tin mặt trước} cho MỌI block nội thất của tầng (kể cả block chưa gán
                family, để tab đầu giường biết giường ở đâu...). Lưng sát tường / đầu giường / két / cánh tủ."""
                faces = []
                try:
                    faces = FU.faces_from_walls(B.host_walls(doc, level))
                except Exception:
                    UI.log(traceback.format_exc())
                src = u"tường Revit"
                if not faces:
                    faces = cad_wall_faces()
                    src = u"nét tường CAD"
                row_cat = {}
                for row in grid.Rows:
                    row_cat[int(row.Tag)] = FU.LABEL_CAT.get(str(row.Cells["cat"].Value or u""))
                per_group, flat = {}, []
                for gi, g in enumerate(groups):
                    if not type_match(g):
                        continue
                    cat = row_cat.get(gi) or guess_cat(g)[0]
                    items = []
                    for rec in g["insts"]:
                        info = None
                        try:
                            body, arcs_m, sw_m = CAD.inst_parts(sc, rec)
                            info = FU.analyze_front(cat, body, arcs_m, sw_m, faces)
                            if info is not None:
                                info["body"] = body
                        except Exception:
                            UI.log(traceback.format_exc())
                        items.append((info, rec))
                    FU.consensus([(i_, r_["tf"]) for i_, r_ in items])
                    per_group[gi] = items
                    flat.extend(i_ for i_, _r in items if i_)
                FU.resolve_scene(flat)
                out = {}
                n_ok = n_no = 0
                for items in per_group.values():
                    for info, rec in items:
                        if info is not None:
                            out[id(rec)] = info
                            if info["face"]:
                                n_ok += 1
                            else:
                                n_no += 1
                UI.log(u"Mặt trước nội thất ({}): {} block có hướng, {} chưa biết (dùng khớp hình)".format(
                    src, n_ok, n_no))
                return out

            @apiw
            def on_place(s, e):
                hl_clear_now()
                level = lv_by.get(cb_level.Text, act_lv)
                if hosted:
                    S["radius"] = UI.num(tb_radius, 600)
                    S["flip_swing"] = bool(ck_swing.Checked)
                    S["flip_hinge"] = bool(ck_hinge.Checked)
                else:
                    S["align"] = bool(ck_align.Checked)
                    S["use_front"] = bool(ck_front.Checked)
                S["auto_recall"] = bool(ck_recall.Checked)
                find_notes = []
                if (not hosted) and bool(ck_find.Checked):
                    S["auto_find"] = True
                    try:
                        _n, find_notes = auto_find([r for r in grid.Rows if r.Visible])
                    except Exception:
                        UI.log(traceback.format_exc())
                        find_notes = [u"Tự tìm family lỗi (xem Block2Revit.log)"]
                elif not hosted:
                    S["auto_find"] = False
                todo = []
                for row in grid.Rows:
                    key = row.Cells["fam"].Value
                    if key in symbols:
                        todo.append((row, symbols[key]))
                if not todo:
                    forms.alert(u"Chưa gán family nào.", title=APP_TITLE,
                                sub_msg=u"\n".join(find_notes[:10]) or None)
                    return
                for _row, _it in todo:
                    dirty.add(int(_row.Tag))        # đặt = xác nhận: các dòng điền tự động cũng được nhớ
                commit_maps()
                save_map(mapping)
                UI.save_settings()
                walls = None
                cache = {}
                orient_cache = {}
                walls_item = None
                n_lv = n_door = n_win = 0
                fronts = {}
                if (not hosted) and bool(S.get("use_front", True)) and bool(S.get("align", True)):
                    try:
                        fronts = compute_fronts(level)
                    except Exception:
                        UI.log(traceback.format_exc())
                        fronts = {}
                problems = list(find_notes)
                logf = lambda m: problems.append(m) if m not in problems else None
                if hosted:
                    walls = B.host_walls(doc, level)
                    if not walls:
                        forms.alert(u"Level '{}' chưa có tường thẳng nào. Hãy dựng tường ở tab "
                                    u"Tường trước.".format(level.Name), title=APP_TITLE)
                        return
                del B.ORIENT_WARN[:]
                t = Transaction(doc, u"Đặt cửa" if hosted else u"Đặt nội thất")
                t.Start()
                try:
                    for row, (sym, kind) in todo:
                        g = groups[int(row.Tag)]
                        if kind in ("level", "wall"):
                            z = UI.num(WF_cell(row, "z"), 0)
                            rot_off = UI.num(WF_cell(row, "rot"), 0)
                            _hs = str(row.Cells["h"].Value or u"").strip()
                            h_val = UI.num(WF_cell(row, "h"), 0) if _hs else None
                            for rec in g["insts"]:
                                try:
                                    if kind == "wall":
                                        if walls_item is None:
                                            walls_item = B.host_walls(doc, level)
                                        B.place_wall_mounted(doc, level, sym, rec, z, sc, walls_item,
                                                             S.get("radius", 600), orient_cache,
                                                             fit=False,
                                                             h_mm=(h_val or None))
                                    else:
                                        _inst = B.place_level_based(doc, level, sym, rec, z, sc,
                                                                    rot_off, bool(S.get("align", True)),
                                                                    orient_cache,
                                                                    fit=bool(row.Cells["fit"].Value),
                                                                    h_mm=(h_val or None),
                                                                    front=fronts.get(id(rec)))
                                        dbg_place(rec, _inst, fronts.get(id(rec)),
                                                  row.Cells["fam"].Value)
                                    n_lv += 1
                                except Exception as ex:
                                    problems.append(u"{}: {}".format(rec["name"], ex))
                        else:
                            opt = {"h": UI.num(WF_cell(row, "h"), 2100 if kind == "door" else 1500),
                                   "sill": UI.num(WF_cell(row, "sill"), 0),
                                   "w_fixed": UI.num(WF_cell(row, "w"), 0),
                                   "radius": S.get("radius", 600),
                                   "flip_swing": S.get("flip_swing", False),
                                   "flip_hinge": S.get("flip_hinge", False), "round": 10}
                            n, sk = B.place_hosted(doc, level, sym, kind, g, sc, walls, opt, cache, logf)
                            problems.extend(sk)
                            if kind == "door":
                                n_door += n
                            else:
                                n_win += n
                    t.Commit()
                except Exception:
                    t.RollBack()
                    raise
                for _w in B.ORIENT_WARN:
                    if _w not in problems:
                        problems.append(_w)
                try:
                    _miss = [groups[int(r_.Tag)] for r_ in grid.Rows
                             if r_.Visible and r_.Cells["fam"].Value not in symbols
                             and type_match(groups[int(r_.Tag)])]
                    if _miss:
                        _nm = u", ".join(u"{} (x{})".format(g_["names"][0], len(g_["insts"]))
                                         for g_ in _miss[:6])
                        problems.append(u"Chưa có family cho {} loại block ({} đối tượng): {}{}".format(
                            len(_miss), sum(len(g_["insts"]) for g_ in _miss), _nm,
                            u" …" if len(_miss) > 6 else u""))
                except Exception:
                    pass
                if hosted:
                    report(APP_TITLE, u"Đã đặt {} cửa đi, {} cửa sổ.".format(n_door, n_win), problems)
                else:
                    report(APP_TITLE, u"Đã đặt {} nội thất.".format(n_lv), problems)
            btn_place.Click += on_place

            attach_zoom(grid,
                        lambda row: [rect_poly(inst_box(i)) for i in groups[int(row.Tag)]["insts"]],
                        info=lambda msg, i, n: setattr(lbl_stat, "Text", msg.format(i, n)),
                        skip_cols=("fam", "kind", "w", "h", "sill", "z", "rot"))

            def snap_blk():
                if hosted:
                    S["radius"] = UI.num(tb_radius, 600)
                    S["flip_swing"] = bool(ck_swing.Checked)
                    S["flip_hinge"] = bool(ck_hinge.Checked)
                else:
                    S["align"] = bool(ck_align.Checked)
                    S["use_front"] = bool(ck_front.Checked)
                    S["auto_find"] = bool(ck_find.Checked)
                S["auto_recall"] = bool(ck_recall.Checked)

            P = {"mode": mode, "page": page, "grid": grid, "kinds": kinds, "famcol": famcol,
                 "ck_merge": ck_merge, "fill": fill, "filter": apply_filter, "collect": collect,
                 "snap": snap_blk, "place": on_place.raw}
            pgs.append(P)
            return P

        pg_door = make_block_page("door")
        pg_item = make_block_page("item")
        p_door, p_item = pg_door["page"], pg_item["page"]

        # ======================================================== TAB Tường (CAD → Tường)
        wl_obj = entry["obj"]
        if "wlayers" not in entry:          # đọc layer 1 lần / file CAD (nặng), nút 'Đọc lại layer' để làm mới
            try:
                entry["wlayers"] = WL.list_layers(doc, wl_obj)
            except Exception:
                UI.log(traceback.format_exc())
                entry["wlayers"] = []
        wl_all = entry["wlayers"]
        wall_types = WL.basic_wall_types(doc)
        WALL_KW = (u"wall", u"tuong", u"tường")
        DOORL_KW = (u"door", u"window", u"cua", u"cửa")
        UNCONN = u"(không có - dùng chiều cao)"
        MODE_ITEMS = [u"2 nét / 1 tường (2 mặt tường)", u"1 nét = tim tường"]

        def guess_layers():
            wl = [ly for ly in wl_all if any(k in ly.lower() for k in WALL_KW)]
            dl = [ly for ly in wl_all if ly not in wl and any(k in ly.lower() for k in DOORL_KW)]
            cw = [ly for ly in CARRY.get("wall_layers", []) if ly in wl_all]
            cd = [ly for ly in CARRY.get("door_layers", []) if ly in wl_all]
            return (cw or wl), (cd or dl)

        _gw, _gd = guess_layers()
        wst = {"layers": _gw, "door_layers": _gd}

        p_wall = UI.panel(WF.DockStyle.Fill)
        tbx_wlog = WF.TextBox()
        tbx_wlog.Multiline = True
        tbx_wlog.ReadOnly = True
        tbx_wlog.ScrollBars = WF.ScrollBars.Vertical
        tbx_wlog.Dock = WF.DockStyle.Bottom
        tbx_wlog.Height = 120
        g_w = UI.make_grid()
        g_w.RowTemplate.Height = 36
        g_w.Columns.Add(UI.col_text("th", u"Bề dày CAD (mm)", 130))
        g_w.Columns.Add(UI.col_text("n", u"Số tường", 100))
        g_w.Columns.Add(UI.col_text("len", u"Tổng dài (m)", 120))
        g_w.Columns.Add(UI.col_text("wt", u"Loại tường sẽ dùng", 420))
        g_w.DataError += _no_throw
        wstate = {"walls": []}

        tb_w = UI.panel(WF.DockStyle.Top, 130, "toolbar")
        btn_wl = UI.btn(u"Chọn layer tường…", 0, 0, 190)
        lbl_wl = UI.lbl(u"", 0, 0, "sub")
        btn_dl = UI.btn(u"Chọn layer cửa…", 0, 0, 190)
        lbl_dl = UI.lbl(u"", 0, 0, "sub")
        btn_wrescan = UI.btn(u"Đọc lại layer", 0, 0, 150)
        wt_labels = [u"{}  ({:.0f} mm)".format(wt.Name, wt.Width * MM) for wt in wall_types]
        cb_wt = UI.combo(0, 0, 340, wt_labels)
        _cwt = CARRY.get("wtype")
        if cb_wt.Items.Count:
            cb_wt.SelectedIndex = 0
            if _cwt in wt_labels:
                cb_wt.SelectedItem = _cwt
        ck_wauto = UI.chk(u"Tự chọn/tạo type theo độ dày đo từ CAD (chỉ với type 1 lớp)", 0, 0,
                          bool(S.get("w_auto", True)))
        cb_wbase = UI.combo(0, 0, 170, lv_names)
        cb_wbase.SelectedItem = act_lv.Name
        cb_wtop = UI.combo(0, 0, 210, [UNCONN] + lv_names)
        tb_wboff = UI.txt(0, 0, 62, str(int(S.get("w_boff", -50))))
        tb_wtoff = UI.txt(0, 0, 62, str(int(S.get("w_toff", -50))))
        tb_wh = UI.txt(0, 0, 62, str(int(S.get("w_h", 3300))))
        cb_wmode = UI.combo(0, 0, 250, MODE_ITEMS)
        cb_wmode.SelectedIndex = 0 if S.get("w_double", True) else 1
        tb_wtmin = UI.txt(0, 0, 56, str(int(S.get("w_tmin", 60))))
        tb_wtmax = UI.txt(0, 0, 56, str(int(S.get("w_tmax", 500))))
        tb_wgap = UI.txt(0, 0, 62, str(int(S.get("w_gap", 3000))))
        tb_wmin = UI.txt(0, 0, 56, str(int(S.get("w_min", 100))))
        tb_wdoor = UI.txt(0, 0, 62, str(int(S.get("w_door", 1000))))
        ck_wgrid = UI.chk(u"Căn tường phẳng với lưới (Grid) gần nhất", 0, 0, bool(S.get("w_grid", True)))
        ck_wface = UI.chk(u"Tự nhận: lưới giữa tường → tim, lưới ở mép → mặt tường", 0, 0,
                          bool(S.get("w_face", True)))
        tb_wsnap = UI.txt(0, 0, 56, str(int(S.get("w_snap", 600))))
        tb_wang = UI.txt(0, 0, 46, str(int(S.get("w_ang", 3))))
        tb_wext = UI.txt(0, 0, 56, str(int(S.get("w_ext", 50))))

        rows_w = [
            [btn_wl, lbl_wl, btn_wrescan],
            [btn_dl, lbl_dl],
            [UI.lbl(u"Loại tường:", 0, 0), cb_wt, ck_wauto],
            [UI.lbl(u"Level đáy", 0, 0), cb_wbase, UI.lbl(u"Offset chân (mm)", 0, 0), tb_wboff,
             UI.lbl(u"Level đỉnh", 0, 0), cb_wtop, UI.lbl(u"Offset đỉnh (mm)", 0, 0), tb_wtoff,
             UI.lbl(u"Cao khi không có Level đỉnh (mm)", 0, 0), tb_wh],
            [UI.lbl(u"Kiểu vẽ CAD:", 0, 0), cb_wmode, UI.lbl(u"Dày min (mm)", 0, 0), tb_wtmin,
             UI.lbl(u"Dày max (mm)", 0, 0), tb_wtmax],
            [UI.lbl(u"Hở tối đa nối tường (mm)", 0, 0), tb_wgap,
             UI.lbl(u"Dài tối thiểu (mm)", 0, 0), tb_wmin,
             UI.lbl(u"Cửa cách tường tối đa (mm)", 0, 0), tb_wdoor],
            [ck_wgrid, ck_wface, UI.lbl(u"Sai số căn lưới (mm)", 0, 0), tb_wsnap,
             UI.lbl(u"Lệch góc (độ)", 0, 0), tb_wang, UI.lbl(u"Kéo/cắt góc (mm)", 0, 0), tb_wext],
        ]
        for r in rows_w:
            for c in r:
                tb_w.Controls.Add(c)
        LAYOUTS.append((tb_w, rows_w))
        bt_w = UI.panel(WF.DockStyle.Bottom, 64, "bottom")
        btn_wan = UI.btn(u"Phân tích", 16, 14, 130)
        lbl_stat_w = UI.lbl(u"Chọn layer tường (và layer cửa để nối tường qua cửa) → Phân tích (xem trước, "
                            u"bấm dòng để zoom) → Vẽ tường. Dựng tường trước, đặt cửa sau.", 160, 21, "sub")
        btn_wbuild = UI.btn(u"Vẽ tường", 0, 12, 200, 40, "primary")
        for c in (btn_wan, lbl_stat_w, btn_wbuild):
            bt_w.Controls.Add(c)
        LAYOUTS_B.append((bt_w, btn_wan, lbl_stat_w, btn_wbuild))
        p_wall.Controls.Add(g_w)
        p_wall.Controls.Add(tbx_wlog)
        p_wall.Controls.Add(tb_w)
        p_wall.Controls.Add(bt_w)

        def wlog(msg):
            tbx_wlog.Text = msg.replace(u"\r\n", u"\n").replace(u"\n", u"\r\n")

        def wlabels():
            lbl_wl.Text = u", ".join(wst["layers"]) if wst["layers"] else u"(chưa chọn)"
            lbl_dl.Text = (u", ".join(wst["door_layers"]) if wst["door_layers"]
                           else u"(chưa chọn - tường chỉ nối theo khoảng hở)")
            UI.layout_rows(tb_w, rows_w)
        wlabels()

        def next_level_name(name):
            i = lv_names.index(name) if name in lv_names else -1
            return lv_names[i + 1] if 0 <= i < len(lv_names) - 1 else None

        def wtop_default(s_=None, e_=None):
            """Mặc định: tường chạy từ level đáy ĐẾN level ngay phía trên (vd Level 1 → Level 2)."""
            nx = next_level_name(cb_wbase.Text)
            cb_wtop.SelectedItem = nx if nx else UNCONN

        def wtop_changed(s_=None, e_=None):
            tb_wh.Enabled = (cb_wtop.SelectedIndex <= 0)       # chỉ nhập cao khi không có Level đỉnh
        cb_wbase.SelectedIndexChanged += wtop_default
        cb_wtop.SelectedIndexChanged += wtop_changed
        wtop_default()
        wtop_changed()

        def clear_prev():
            g_w.Rows.Clear()
            wstate["walls"] = []

        @safe
        def on_wl(s, e):
            sel = UI.select_list(wl_all, u"Chọn layer tường", True, wst["layers"])
            if sel is not None:
                wst["layers"] = list(sel)
                wlabels()
                clear_prev()
        btn_wl.Click += on_wl

        @safe
        def on_dl(s, e):
            sel = UI.select_list(wl_all, u"Chọn layer CỬA đi / cửa sổ (để nối tường qua cửa)", True,
                                 wst["door_layers"])
            if sel is not None:
                wst["door_layers"] = list(sel)
                wlabels()
                clear_prev()
        btn_dl.Click += on_dl

        @apiw
        def on_wrescan(s, e):
            try:
                new = WL.list_layers(doc, wl_obj)
            except Exception:
                UI.log(traceback.format_exc())
                new = []
            wl_all[:] = new
            wst["layers"] = [ly for ly in wst["layers"] if ly in wl_all]
            wst["door_layers"] = [ly for ly in wst["door_layers"] if ly in wl_all]
            if not wst["layers"] and not wst["door_layers"]:
                wst["layers"], wst["door_layers"] = guess_layers()
            wlabels()
            clear_prev()
            lbl_stat_w.Text = u"Đã đọc lại: {} layer".format(len(wl_all))
        btn_wrescan.Click += on_wrescan

        def wall_snap():
            """Lưu các ô nhập của tab Tường (mang sang tầng sau)."""
            S["w_auto"] = bool(ck_wauto.Checked)
            S["w_boff"], S["w_toff"] = UI.num(tb_wboff, -50), UI.num(tb_wtoff, -50)
            S["w_h"] = UI.num(tb_wh, 3300)
            S["w_double"] = (cb_wmode.SelectedIndex <= 0)
            S["w_tmin"], S["w_tmax"] = UI.num(tb_wtmin, 60), UI.num(tb_wtmax, 500)
            S["w_gap"], S["w_min"] = UI.num(tb_wgap, 3000), UI.num(tb_wmin, 100)
            S["w_door"] = UI.num(tb_wdoor, 1000)
            S["w_grid"], S["w_face"] = bool(ck_wgrid.Checked), bool(ck_wface.Checked)
            S["w_snap"], S["w_ang"], S["w_ext"] = UI.num(tb_wsnap, 600), UI.num(tb_wang, 3), UI.num(tb_wext, 50)

        def make_SW():
            """Đọc form -> dict cài đặt cho b2r_walls (đơn vị feet). None nếu thiếu/sai (đã báo)."""
            if not wst["layers"]:
                forms.alert(u"Hãy chọn layer tường trước.", title=APP_TITLE)
                return None
            wi = cb_wt.SelectedIndex
            if not (0 <= wi < len(wall_types)):
                forms.alert(u"Project chưa có Wall Type (Basic) hoặc chưa chọn loại tường.", title=APP_TITLE)
                return None
            base = lv_by.get(cb_wbase.Text, act_lv)
            top = lv_by.get(cb_wtop.Text) if cb_wtop.SelectedIndex > 0 else None
            if top is not None and top.Elevation <= base.Elevation + WL.FT:
                forms.alert(u"Level đỉnh phải cao hơn level đáy.", title=APP_TITLE)
                return None
            wall_snap()
            UI.save_settings()
            FT = WL.FT
            base_type = wall_types[wi]
            return {
                "cad": wl_obj, "base_level": base, "top_level": top,
                "base_off": S["w_boff"] * FT, "top_off": S["w_toff"] * FT, "height": S["w_h"] * FT,
                "layers": list(wst["layers"]),
                "door_layers": [ly for ly in wst["door_layers"] if ly not in wst["layers"]],
                "door_tol": S["w_door"] * FT,
                "wall_type": base_type, "base_width": base_type.Width,
                "auto_type": bool(S["w_auto"]), "double": bool(S["w_double"]),
                "tmin": S["w_tmin"] * FT, "tmax": S["w_tmax"] * FT,
                "max_gap": S["w_gap"] * FT, "min_len": S["w_min"] * FT,
                "min_overlap": min(100.0, S["w_min"] / 2.0) * FT,
                "seg_min": 20 * FT, "ang_tol": 1.0,
                "do_grid": bool(S["w_grid"]), "snap_face": bool(S["w_face"]),
                "snap_tol": S["w_snap"] * FT, "grid_ang_tol": S["w_ang"], "ext_tol": S["w_ext"] * FT,
            }

        @apiw
        def on_wan(s, e):
            """Phân tích (xem trước, KHÔNG dựng): bảng tường theo bề dày; bấm dòng -> zoom + khoanh màu."""
            hl_clear_now()
            SW = make_SW()
            if SW is None:
                return
            wlog(u"Đang phân tích...")
            A, err = WL.analyze(doc, SW)
            if A is None:
                clear_prev()
                wlog(err)
                lbl_stat_w.Text = err
                forms.alert(err, title=APP_TITLE)
                return
            ws, snapped = WL.preview(doc, SW, A)
            mm = 1.0 / WL.FT
            walls_mm = [(w["p0"][0] * mm, w["p0"][1] * mm, w["p1"][0] * mm, w["p1"][1] * mm,
                         w["th"] * mm) for w in ws]
            wstate["walls"] = walls_mm
            by = {}
            for w in walls_mm:
                tk = int(round(w[4] / 10.0))         # gom bề dày theo bước 10 mm
                a = by.setdefault(tk, [0, 0.0, 0.0])
                a[0] += 1
                a[1] += math.hypot(w[2] - w[0], w[3] - w[1])
                a[2] += w[4]
            g_w.Rows.Clear()
            for tk in sorted(by):
                row = g_w.Rows[g_w.Rows.Add()]
                row.Tag = tk
                avg = by[tk][2] / by[tk][0]
                row.Cells["th"].Value = u"{:.0f}".format(avg)
                row.Cells["n"].Value = str(by[tk][0])
                row.Cells["len"].Value = u"{:.1f}".format(by[tk][1] / 1000.0)
                row.Cells["wt"].Value = WL.type_preview(doc, SW, avg * WL.FT)
            st = A["stats"]
            lbl_stat_w.Text = (u"{} nét → {} tường, {} nhóm bề dày  ·  nối qua cửa {}  ·  căn lưới {}  "
                               u"(bấm dòng để zoom, khoanh đỏ = đang xem, cam = các vị trí còn lại)".format(
                                   A["nsegs"], len(walls_mm), len(by), A["bridged"], snapped))
            info = [lbl_stat_w.Text]
            if st["short_piece"]:
                info.append(u"Bỏ {} đoạn ngắn hơn {:.0f} mm.".format(len(st["short_piece"]), S["w_min"]))
            info.extend(A["notes"])
            wlog(u"\n".join(info))
            UI.log(u"Phân tích tường: " + u" | ".join(info))

        btn_wan.Click += on_wan

        def wall_polys(row):
            tk = int(row.Tag)
            ws = [w for w in wstate["walls"] if int(round(w[4] / 10.0)) == tk]
            ws.sort(key=lambda w: -math.hypot(w[2] - w[0], w[3] - w[1]))
            return [wall_poly(w) for w in ws]
        attach_zoom(g_w, wall_polys,
                    info=lambda msg, i, n: setattr(lbl_stat_w, "Text", msg.format(i, n).replace(
                        u"vị trí", u"tường")),
                    skip_cols=("wt",), margin=2000.0)

        @apiw
        def on_wbuild(s, e):
            hl_clear_now()
            SW = make_SW()
            if SW is None:
                return
            wlog(u"Đang dựng tường...")
            lines = WL.run(doc, SW)[2]
            wlog(u"\n".join(lines))
            lbl_stat_w.Text = lines[0]
            report(APP_TITLE, lines[0], lines[1:])
        btn_wbuild.Click += on_wbuild

        # ======================================================== PAGE 3
        p3 = UI.panel(WF.DockStyle.Fill)
        g3 = UI.make_grid()
        g3.Columns.Add(UI.col_img("img", u"Block", 84))
        g3.Columns.Add(UI.col_text("name", u"Tên block", 180))
        g3.Columns.Add(UI.col_check("go", u"Dựng", 56))
        g3.Columns.Add(UI.col_text("w", u"Rộng vế (mm)\n(sửa được)", 100, False))
        g3.Columns.Add(UI.col_text("len", u"Dài vế (mm)\n(sửa được)", 100, False))
        g3.Columns.Add(UI.col_text("risers", u"Số riser\n(sửa được)", 86, False))
        g3.Columns.Add(UI.col_text("tread", u"Bề rộng bậc\n(mm)", 92))
        g3.Columns.Add(UI.col_text("rh", u"Cao bậc\n(mm)", 80))
        g3.Columns.Add(UI.col_text("src", u"Hướng lên đọc từ", 120))
        g3.Columns.Add(UI.col_check("flip", u"Đảo hướng", 80))
        g3.Columns.Add(UI.col_text("note", u"Ghi chú", 420))
        g3.DataError += _no_throw
        g3.ColumnHeadersHeight = 46
        tb3 = UI.panel(WF.DockStyle.Top, 130, "toolbar")
        btn_sl = UI.btn(u"Chọn layer thang…", 16, 12, 190)
        lbl_sl = UI.lbl(u"(chưa chọn)", 218, 19, "sub")
        tb_sname = UI.txt(150, 56, 150, str(S.get("stair_name", u"")))
        cb_stype = UI.combo(404, 54, 300, sorted(stair_types.keys()))
        if cb_stype.Items.Count:
            cb_stype.SelectedIndex = 0
            for _i, _nm in enumerate(sorted(stair_types.keys())):    # ưu tiên loại đúc liền khối (hỗ trợ Sketch)
                if B.is_mono_name(_nm):
                    cb_stype.SelectedIndex = _i
                    break
        if CARRY.get("stype") in stair_types:
            cb_stype.SelectedItem = CARRY["stype"]
        ck_straight = UI.chk(u"Cho phép dựng Straight Run nếu Create Sketch lỗi", 0, 0,
                             bool(S.get("allow_straight", False)))
        cb_sbase = UI.combo(80, 92, 200, lv_names)
        cb_sbase.SelectedItem = act_lv.Name
        cb_stop = UI.combo(370, 92, 200, lv_names)
        try:
            idx = lv_names.index(act_lv.Name)
            cb_stop.SelectedIndex = min(idx + 1, len(lv_names) - 1)
        except Exception:
            pass
        rows3 = [
            [btn_sl, lbl_sl],
            [UI.lbl(u"Tên block chứa (tuỳ chọn):", 0, 0), tb_sname,
             UI.lbl(u"Loại thang (Sketch cần loại đúc liền khối / Monolithic):", 0, 0), cb_stype],
            [UI.lbl(u"Level đáy", 0, 0), cb_sbase, UI.lbl(u"Level đỉnh", 0, 0), cb_stop, ck_straight],
        ]
        for r in rows3:
            for c in r:
                tb3.Controls.Add(c)
        LAYOUTS.append((tb3, rows3))
        bt3 = UI.panel(WF.DockStyle.Bottom, 64, "bottom")
        btn_san = UI.btn(u"Phân tích", 16, 14, 130)
        lbl_stat3 = UI.lbl(u"Chọn layer thang (hoặc nhập tên block) rồi bấm Phân tích. "
                           u"Hỗ trợ thang 1 vế và nhiều vế (L, U, 3-4 vế).", 160, 21, "sub")
        btn_sbuild = UI.btn(u"Dựng thang (Sketch)", 0, 12, 200, 40, "primary")
        for c in (btn_san, lbl_stat3, btn_sbuild):
            bt3.Controls.Add(c)
        LAYOUTS_B.append((bt3, btn_san, lbl_stat3, btn_sbuild))
        p3.Controls.Add(g3)
        p3.Controls.Add(tb3)
        p3.Controls.Add(bt3)
        sstate = {"layers": [], "recs": []}
        sguess = ("thang", "stair", "step")
        sstate["layers"] = [ly for ly in sc.layers_blocks
                            if any(k in ly.lower() for k in sguess)]
        _cs = [ly for ly in CARRY.get("stair_layers", []) if ly in sc.layers_blocks]
        if _cs:
            sstate["layers"] = _cs

        def slayer_label():
            lbl_sl.Text = (u", ".join(sstate["layers"]) if sstate["layers"] else u"(chưa chọn)")
        slayer_label()

        @safe
        def on_sl(s, e):
            labs = dict((u"{}  ({} block)".format(ly, n), ly) for ly, n in sc.layers_blocks.items())
            pre = [k for k, v in labs.items() if v in sstate["layers"]]
            sel = UI.select_list(sorted(labs.keys()), u"Chọn layer thang", True, pre)
            if sel is not None:
                sstate["layers"] = [labs[k] for k in sel]
                slayer_label()
        btn_sl.Click += on_sl

        @safe
        def on_san(s, e):
            flt = tb_sname.Text.strip().lower()
            if not sstate["layers"] and not flt:
                forms.alert(u"Hãy chọn layer thang hoặc nhập tên block.", title=APP_TITLE)
                return
            S["stair_name"] = tb_sname.Text.strip()
            sstate["busy"] = True
            g3.Rows.Clear()
            sstate["recs"] = []
            n_ok = n_bad = 0
            lset = set(sstate["layers"])
            for ins in sc.insts:
                if sstate["layers"] and not (ins["layers"] & lset):
                    continue
                if flt and flt not in ins["name"].lower():
                    continue
                segs_w = CAD.inst_segs(sc, ins)
                txt_w = CAD.inst_texts(sc, ins)
                r = G.analyze_stair(segs_w, txt_w)
                tr = None
                try:
                    tr = TR.analyze_stair_treads(segs_w, txt_w)
                except Exception:
                    UI.log(traceback.format_exc())
                if (not r["ok"]) or r["multi"]:
                    mr = G.analyze_stair_multi(segs_w, txt_w)
                    if mr["ok"] and len(mr["runs"]) >= 2:
                        rr = mr["runs"]
                        r = {"ok": True, "multi": True, "reason": u"", "runs": rr,
                             "src": mr["src"], "n_text": mr["n_text"],
                             "width": max(x["width"] for x in rr),
                             "length": sum(x["length"] for x in rr),
                             "risers": sum(x["risers"] for x in rr)}
                if tr is not None and tr.get("ok"):
                    # đọc được từng bậc thật trong CAD (kể cả bậc chéo) -> bám đúng hình CAD
                    r = {"ok": True, "multi": False, "reason": u"", "treads": tr["treads"],
                         "src": tr["src"], "n_text": tr["n_text"], "width": tr["width"],
                         "length": tr["length"], "risers": tr["risers"],
                         "winders": tr["winders"], "arrow": tr.get("arrow"),
                         "fb": (r if r.get("ok") else None)}
                elif tr is not None:
                    UI.log(u"Thang '{}': không đọc theo bậc CAD ({})".format(ins["name"],
                                                                             tr.get("reason")))
                ri = g3.Rows.Add()
                row = g3.Rows[ri]
                row.Tag = len(sstate["recs"])
                sstate["recs"].append((ins, r))
                row.Cells["img"].Value = UI.draw_segs(sc.defs[ins["name"]]["segs"], 72)
                row.Cells["name"].Value = ins["name"]
                if not r["ok"]:
                    row.Cells["go"].Value = False
                    row.Cells["note"].Value = u"Không đọc được: " + r["reason"]
                    n_bad += 1
                    continue
                n_ok += 1
                if r.get("treads"):
                    nt = r["n_text"]
                    nts = [u"Bám đúng {} bậc trong CAD (có {} bậc chéo), rộng {:.0f} mm, {} riser; "
                           u"hướng lên đọc từ {}".format(len(r["treads"]), r.get("winders", 0),
                                                         r["width"], r["risers"], r["src"])]
                    if nt > 0 and nt != r["risers"]:
                        nts.append(u"chữ số lớn nhất {} ≠ {} riser - kiểm tra lại".format(
                            nt, r["risers"]))
                    if r["src"] == u"chưa rõ":
                        nts.append(u"CHƯA rõ hướng lên - kiểm tra khung ĐỎ (chân thang) / bấm Đảo hướng")
                    nts.append(u"Rộng/Dài/riser lấy theo CAD nên không sửa tay")
                    row.Cells["go"].Value = True
                    row.Cells["w"].Value = u"{:.0f}".format(r["width"])
                    row.Cells["len"].Value = u"{:.0f}".format(r["length"])
                    row.Cells["risers"].Value = str(r["risers"])
                    row.Cells["src"].Value = r["src"]
                    row.Cells["flip"].Value = False
                    row.Cells["note"].Value = u"; ".join(nts)
                    for _cn in ("w", "len", "risers"):
                        row.Cells[_cn].ReadOnly = True
                    continue
                m = r["risers"]
                nt = r["n_text"]
                risers = m
                notes = []
                if nt > 0:
                    if nt + 1 == m:
                        pass
                    else:
                        risers = nt + 1
                        notes.append(u"chữ số {} ≠ {} đường bậc → lấy theo chữ".format(nt, m - 1))
                if r["src"] == u"chưa rõ":
                    notes.append(u"CHƯA rõ hướng lên - kiểm tra / bấm Đảo hướng")
                if r.get("runs"):
                    risers = r["risers"]
                    notes = [u"{} vế: {} bậc; thứ tự/hướng đọc từ {} - kiểm tra, sai thì bấm Đảo hướng".format(
                        len(r["runs"]), u"+".join(str(x["risers"]) for x in r["runs"]), r["src"])]
                elif r["multi"]:
                    notes.append(u"thang nhiều vế nhưng chưa tách được từng vế")
                row.Cells["go"].Value = bool(r.get("runs")) or not r["multi"]
                row.Cells["w"].Value = u"{:.0f}".format(r["width"])
                row.Cells["len"].Value = u"{:.0f}".format(r["length"])
                row.Cells["risers"].Value = str(risers)
                row.Cells["src"].Value = r["src"]
                row.Cells["flip"].Value = False
                row.Cells["note"].Value = u"; ".join(notes)
            sstate["busy"] = False
            for row in g3.Rows:
                if row.Tag is not None:
                    stair_calc(row)
            lbl_stat3.Text = u"{} block thang đọc được, {} không đọc được".format(n_ok, n_bad)
            UI.log(u"Phân tích thang: " + lbl_stat3.Text)
        btn_san.Click += on_san

        GREEN, BLUE = (0, 170, 60), (0, 110, 255)

        def fnum(v, d=0.0):
            try:
                return float(str(v).replace(",", ".").strip())
            except Exception:
                return d

        def stair_item_from_row(row):
            """Thang sẽ được dựng theo ĐÚNG số liệu đang hiện trên dòng (kể cả khi bạn sửa tay).
            Thang đọc theo từng bậc CAD (có bậc chéo) thì bám đúng hình CAD, chỉ cho Đảo hướng."""
            ins, r = sstate["recs"][int(row.Tag)]
            if not r["ok"]:
                return None
            flip = bool(row.Cells["flip"].Value)
            if r.get("treads"):
                tds = list(r["treads"])
                if flip:
                    tds = list(reversed(tds))
                it = {"name": ins["name"], "treads": tds, "width": r["width"],
                      "length": r["length"], "risers": len(tds) + 1,
                      "winders": r.get("winders", 0)}
                fb = r.get("fb")
                if fb and fb.get("ok"):
                    it["fb"] = old_item(ins, fb, fb["width"], fb["length"], int(fb["risers"]), flip)
                return it
            risers = int(fnum(row.Cells["risers"].Value, 0))
            wid = fnum(row.Cells["w"].Value, r["width"])
            ln = fnum(row.Cells["len"].Value, r["length"])
            return old_item(ins, r, wid, ln, risers, flip)

        def old_item(ins, r, wid, ln, risers, flip):
            """Cách cũ: các vế thẳng (đều bậc) + chiếu nghỉ."""
            if risers < 2 or wid <= 0 or ln <= 0:
                return None
            if r.get("runs"):
                runs = [dict(x, width=wid) for x in r["runs"]]
                if flip:
                    runs = [dict(x, start=x["end"], end=x["start"]) for x in reversed(runs)]
                diff = risers - sum(int(x["risers"]) for x in runs)
                runs[-1]["risers"] = int(runs[-1]["risers"]) + diff
                return {"name": ins["name"], "runs": runs, "width": wid,
                        "length": r["length"], "risers": risers}
            st, en = r["start"], r["end"]
            if flip:
                st, en = en, st
            L0 = math.hypot(en[0] - st[0], en[1] - st[1]) or 1.0
            en = (st[0] + (en[0] - st[0]) / L0 * ln, st[1] + (en[1] - st[1]) / L0 * ln)
            return {"name": ins["name"], "start": st, "end": en, "width": wid, "length": ln,
                    "risers": risers}

        def stair_calc(row):
            """Bề rộng bậc + cao bậc dự kiến (để bạn kiểm tra nhanh có hợp lý không)."""
            try:
                it = stair_item_from_row(row)
                if it is None:
                    row.Cells["tread"].Value = u""
                    row.Cells["rh"].Value = u""
                    return
                runs = it.get("runs") or [it]
                tds = [x["length"] / max(int(x["risers"]) - 1, 1) for x in runs]
                row.Cells["tread"].Value = u"{:.0f}".format(sum(tds) / len(tds))
                base = lv_elev.get(cb_sbase.Text)
                top = lv_elev.get(cb_stop.Text)
                if base is not None and top is not None and top > base:
                    row.Cells["rh"].Value = u"{:.0f}".format((top - base) * MM / it["risers"])
                else:
                    row.Cells["rh"].Value = u""
            except Exception:
                pass

        def stair_overlay(row):
            """Hình thang mà tool SẼ dựng (xanh lá: biên + vạch bậc, xanh dương: đường đi lên)."""
            it = stair_item_from_row(row)
            if it is None:
                return []
            shapes = []
            if it.get("treads"):
                RED = (235, 40, 40)
                for t in it["treads"]:
                    shapes.append((list(t), GREEN, 3))
                geo = TR.tread_geometry(it["treads"])
                if geo:
                    a, b = geo["risers"][0]
                    shapes.append(([a, b], RED, 8))                 # vạch bậc ĐẦU (chân thang)
                    pth = geo["path"]
                    for i in range(len(pth) - 1):
                        shapes.append(([pth[i], pth[i + 1]], BLUE, 6))
                    ex, ey = pth[-1]
                    px, py = pth[-2]
                    L = math.hypot(ex - px, ey - py) or 1.0
                    ux, uy = (ex - px) / L, (ey - py) / L
                    ah = 300.0
                    bx, by = ex - ux * ah, ey - uy * ah
                    shapes.append(([(ex, ey), (bx - uy * ah * 0.5, by + ux * ah * 0.5)], BLUE, 6))
                    shapes.append(([(ex, ey), (bx + uy * ah * 0.5, by - ux * ah * 0.5)], BLUE, 6))
                return shapes
            for r in (it.get("runs") or [it]):
                sx, sy = r["start"]
                ex, ey = r["end"]
                L = math.hypot(ex - sx, ey - sy) or 1.0
                ux, uy = (ex - sx) / L, (ey - sy) / L
                lx, ly = -uy, ux
                hw = r["width"] / 2.0
                shapes.append(([(sx + lx * hw, sy + ly * hw), (ex + lx * hw, ey + ly * hw),
                                (ex - lx * hw, ey - ly * hw), (sx - lx * hw, sy - ly * hw)], GREEN, 7))
                n = max(int(r["risers"]), 2)
                for k in range(1, n - 1):
                    t_ = k / float(n - 1)
                    cx, cy = sx + (ex - sx) * t_, sy + (ey - sy) * t_
                    shapes.append(([(cx + lx * hw, cy + ly * hw), (cx - lx * hw, cy - ly * hw)],
                                   GREEN, 3))
                # đường đi lên + mũi tên
                shapes.append(([(sx, sy), (ex, ey)], BLUE, 6))
                ah = min(300.0, L * 0.12)
                bx, by = ex - ux * ah, ey - uy * ah
                shapes.append(([(ex, ey), (bx + lx * ah * 0.5, by + ly * ah * 0.5)], BLUE, 6))
                shapes.append(([(ex, ey), (bx - lx * ah * 0.5, by - ly * ah * 0.5)], BLUE, 6))
            return shapes

        def stair_changed(s_, e_):
            try:
                if e_.RowIndex < 0 or sstate.get("busy"):
                    return
                if g3.Columns[e_.ColumnIndex].Name not in ("w", "len", "risers", "flip"):
                    return
                row = g3.Rows[e_.RowIndex]
                stair_calc(row)
                if row.Tag is not None and g3.ContainsFocus:
                    ins = sstate["recs"][int(row.Tag)][0]
                    show_polys([rect_poly(inst_box(ins), 200.0)], 0, 2500.0,
                               extra=stair_overlay(row), zoom=False)
            except Exception:
                UI.log(traceback.format_exc())
        g3.CellValueChanged += stair_changed
        g3.CurrentCellDirtyStateChanged += lambda s_, e_: g3.CommitEdit(
            WF.DataGridViewDataErrorContexts.Commit)

        def stair_levels_changed(s_=None, e_=None):
            try:
                for row in g3.Rows:
                    if row.Tag is not None:
                        stair_calc(row)
            except Exception:
                pass
        cb_sbase.SelectedIndexChanged += stair_levels_changed
        cb_stop.SelectedIndexChanged += stair_levels_changed

        attach_zoom(g3, lambda row: [rect_poly(inst_box(sstate["recs"][int(row.Tag)][0]), 200.0)],
                    info=lambda msg, i, n: setattr(
                        lbl_stat3, "Text",
                        u"Khung ĐỎ = block CAD  ·  XANH LÁ = từng bậc tool sẽ dựng  ·  "
                        u"XANH DƯƠNG = chiều đi lên  ·  vạch ĐỎ đậm = chân thang. Sai hướng thì bấm Đảo hướng."),
                    skip_cols=("go", "w", "len", "risers", "flip"), margin=2500.0,
                    extra_fn=stair_overlay)

        @apiw
        def on_sbuild(s, e):
            hl_clear_now()
            base = lv_by.get(cb_sbase.Text)
            top = lv_by.get(cb_stop.Text)
            if base is None or top is None or top.Elevation <= base.Elevation:
                forms.alert(u"Level đỉnh phải cao hơn level đáy.", title=APP_TITLE)
                return
            items = []
            for row in g3.Rows:
                if not bool(row.Cells["go"].Value):
                    continue
                it = stair_item_from_row(row)
                if it is not None:
                    items.append(it)
            if not items:
                forms.alert(u"Không có thang nào được tick 'Dựng'.", title=APP_TITLE)
                return
            stype = stair_types.get(cb_stype.Text)
            UI.save_settings()
            S["allow_straight"] = bool(ck_straight.Checked)
            UI.save_settings()
            ok, fails = B.build_stairs(doc, items, stype, base, top, sketch=True,
                                       all_types=stair_types, allow_straight=S["allow_straight"])
            report(APP_TITLE, u"Đã dựng {} / {} thang (bằng Create Sketch).".format(ok, len(items)),
                   fails)
        btn_sbuild.Click += on_sbuild

        # ======================================================== TAB Sàn (theo Room)
        floor_types = B.get_floor_types(doc)
        p5 = UI.panel(WF.DockStyle.Fill)
        g5 = UI.make_grid()
        g5.RowTemplate.Height = 32
        g5.Columns.Add(UI.col_check("go", u"Tạo sàn", 70))
        g5.Columns.Add(UI.col_text("num", u"Số phòng", 100))
        g5.Columns.Add(UI.col_text("name", u"Tên phòng", 300))
        g5.Columns.Add(UI.col_text("area", u"Diện tích (m²)", 120))
        g5.Columns.Add(UI.col_text("note", u"Ghi chú", 420))
        g5.DataError += _no_throw
        tb5 = UI.panel(WF.DockStyle.Top, 130, "toolbar")
        cb_flevel = UI.combo(0, 0, 200, lv_names)
        cb_flevel.SelectedItem = act_lv.Name
        cb_ftype = UI.combo(0, 0, 320, sorted(floor_types.keys()))
        if cb_ftype.Items.Count:
            cb_ftype.SelectedIndex = 0
            if CARRY.get("ftype") in floor_types:
                cb_ftype.SelectedItem = CARRY["ftype"]
        tb_foff = UI.txt(0, 0, 60, str(int(S.get("floor_off", 0))))
        btn_autoroom = UI.btn(u"Đặt Room tự động cho vùng kín", 0, 0, 260)
        rows5 = [
            [UI.lbl(u"Level", 0, 0), cb_flevel, UI.lbl(u"Loại sàn", 0, 0), cb_ftype,
             UI.lbl(u"Offset cao độ (mm)", 0, 0), tb_foff],
            [btn_autoroom],
        ]
        for r in rows5:
            for c in r:
                tb5.Controls.Add(c)
        LAYOUTS.append((tb5, rows5))
        bt5 = UI.panel(WF.DockStyle.Bottom, 64, "bottom")
        btn_fan = UI.btn(u"Lấy danh sách Room", 16, 14, 180)
        lbl_stat5 = UI.lbl(u"Dựng tường + đặt cửa trước, rồi 'Đặt Room tự động' → 'Lấy danh sách Room' "
                           u"→ Tạo sàn.", 210, 21, "sub")
        btn_fbuild = UI.btn(u"Tạo sàn", 0, 12, 180, 40, "primary")
        for c in (btn_fan, lbl_stat5, btn_fbuild):
            bt5.Controls.Add(c)
        LAYOUTS_B.append((bt5, btn_fan, lbl_stat5, btn_fbuild))
        p5.Controls.Add(g5)
        p5.Controls.Add(tb5)
        p5.Controls.Add(bt5)
        fstate = {"rooms": []}

        @apiw
        def on_autoroom(s, e):
            lv = lv_by.get(cb_flevel.Text, act_lv)
            t = Transaction(doc, u"Đặt Room tự động")
            t.Start()
            try:
                n = B.auto_rooms(doc, lv)
                t.Commit()
            except Exception:
                t.RollBack()
                raise
            forms.alert(u"Đã đặt {} Room mới trên level {}.".format(n, lv.Name), title=APP_TITLE)
            _fan()
        btn_autoroom.Click += on_autoroom

        def _fan():
            lv = lv_by.get(cb_flevel.Text, act_lv)
            rooms = B.get_rooms(doc, lv)
            fstate["rooms"] = rooms
            g5.Rows.Clear()
            for idx, r in enumerate(rooms):
                ri = g5.Rows.Add()
                row = g5.Rows[ri]
                row.Tag = idx
                row.Cells["go"].Value = True
                row.Cells["num"].Value = B.room_number(r)
                row.Cells["name"].Value = B.room_name(r)
                row.Cells["area"].Value = u"{:.2f}".format(r.Area * 0.09290304)
            lbl_stat5.Text = u"{} Room trên level {}".format(len(rooms), lv.Name)
        on_fan = apiw(lambda s, e: _fan())
        btn_fan.Click += on_fan

        zr = {"tag": None}

        def room_sel(s_, e_):
            try:
                if not g5.ContainsFocus:
                    return
                row = g5.CurrentRow
                if row is None or row.Tag is None or row.Tag == zr["tag"]:
                    return
                zr["tag"] = row.Tag
                room = fstate["rooms"][int(row.Tag)]

                def job():
                    bb = room.get_BoundingBox(None)
                    if bb is not None:
                        box = (bb.Min.X * MM, bb.Min.Y * MM, bb.Max.X * MM, bb.Max.Y * MM)
                        HL["ids"] = B.hl_draw(doc, uidoc.ActiveView, HL["ids"],
                                              [(rect_poly(box, 100.0), RED, 9)])
                        B.zoom_rect(uidoc, box[0], box[1], box[2], box[3], 1500.0)
                API.post(job)
            except Exception:
                UI.log(traceback.format_exc())
        g5.SelectionChanged += room_sel

        @apiw
        def on_fbuild(s, e):
            hl_clear_now()
            lv = lv_by.get(cb_flevel.Text, act_lv)
            ft = floor_types.get(cb_ftype.Text)
            if ft is None:
                forms.alert(u"Chưa chọn loại sàn.", title=APP_TITLE)
                return
            sel = [fstate["rooms"][int(row.Tag)] for row in g5.Rows if bool(row.Cells["go"].Value)]
            if not sel:
                forms.alert(u"Không có Room nào được tick. Bấm 'Lấy danh sách Room' trước.",
                            title=APP_TITLE)
                return
            S["floor_off"] = UI.num(tb_foff, 0)
            UI.save_settings()
            t = Transaction(doc, u"Tạo sàn theo Room")
            t.Start()
            try:
                ok, fails = B.build_floors(doc, lv, sel, ft, S["floor_off"])
                t.Commit()
            except Exception:
                t.RollBack()
                raise
            report(APP_TITLE, u"Đã tạo {} sàn.".format(ok), fails)
        btn_fbuild.Click += on_fbuild


        # ======================================================== Reset family
        @apiw
        def on_reset_fam(s, e):
            """Đọc lại TOÀN BỘ family trong project (kể cả family vừa nạp từ tool khác khi form đang mở).
            Giữ nguyên các family đã gán trên các tab; family đã bị xoá khỏi project thì bỏ gán."""
            new = B.get_symbols(doc)
            old = set(symbols.keys())
            added = sorted(k for k in new if k not in old)
            gone = sorted(k for k in old if k not in new)
            commit_maps()
            symbols.clear()
            symbols.update(new)
            UI.clear_previews()
            try:
                UI.prefetch_previews([(k, v[0]) for k, v in symbols.items()
                                      if v[1] in ("door", "window", "level", "wall")], 72, 6.0)
            except Exception:
                UI.log(traceback.format_exc())
            for p in pgs:
                p["fill"]()
                p["filter"]()
            cnt = {}
            for _k, (_s, kd) in symbols.items():
                cnt[kd] = cnt.get(kd, 0) + 1
            sub = u""
            if added:
                sub += u"Mới: " + u"; ".join(added[:12]) + (u" …" if len(added) > 12 else u"")
            if gone:
                sub += (u"\n" if sub else u"") + u"Đã xoá khỏi project: " + u"; ".join(gone[:8])
            forms.alert(u"Đã đọc lại family: {} cửa đi, {} cửa sổ, {} nội thất, {} treo tường "
                        u"(mới {}, mất {}).".format(cnt.get("door", 0), cnt.get("window", 0),
                                                     cnt.get("level", 0),
                                                     cnt.get("wall", 0),
                                                     len(added), len(gone)),
                        title=APP_TITLE, sub_msg=sub or None)

        # ======================================================== chuyển tầng / chạy hàng loạt
        def snapshot():
            """Gom mọi lựa chọn của tầng đang làm (family, layer, loại thang/sàn...) để mang sang tầng sau."""
            try:
                commit_maps()
                save_map(mapping)
            except Exception:
                UI.log(traceback.format_exc())
            CARRY["wall_layers"] = list(wst["layers"])
            CARRY["door_layers"] = list(wst["door_layers"])
            if 0 <= cb_wt.SelectedIndex < len(wt_labels):
                CARRY["wtype"] = wt_labels[cb_wt.SelectedIndex]
            CARRY["stair_layers"] = list(sstate["layers"])
            if cb_stype.Text in stair_types:
                CARRY["stype"] = cb_stype.Text
            if cb_ftype.Text in floor_types:
                CARRY["ftype"] = cb_ftype.Text
            S["stair_name"] = tb_sname.Text.strip()
            S["allow_straight"] = bool(ck_straight.Checked)
            S["floor_off"] = UI.num(tb_foff, 0)
            try:
                wall_snap()
            except Exception:
                UI.log(traceback.format_exc())
            for _p in pgs:
                try:
                    _p["snap"]()
                except Exception:
                    UI.log(traceback.format_exc())

        def run_steps(keys):
            """Chạy tuần tự các bước đã chọn cho tầng này (đã ở API context; hộp thoại gom vào BATCH)."""
            if "wall" in keys:
                on_wbuild.raw(None, None)
            if "door" in keys:
                pg_door["place"](None, None)
            if "item" in keys:
                pg_item["place"](None, None)
            if "stair" in keys:
                on_san(None, None)
                on_sbuild.raw(None, None)
            if "floor" in keys:
                on_autoroom.raw(None, None)
                _fan()
                on_fbuild.raw(None, None)

        return {"sc": sc, "groups": groups, "pgs": pgs, "pg_door": pg_door, "pg_item": pg_item,
                "p_wall": p_wall, "p_door": p_door, "p_item": p_item, "p3": p3, "p5": p5,
                "g_w": g_w, "g3": g3, "g5": g5, "sstate": sstate,
                "HL": HL, "hl_clear": hl_clear_now, "reset": on_reset_fam,
                "snapshot": snapshot, "run_steps": run_steps}


    # ======================================================== ghép form + đổi file CAD
    form.Controls.Add(host)
    form.Controls.Add(header)

    cur = {"tab": 0}

    def show_tab(i):
        cur["tab"] = i
        for k, p in enumerate(pages):
            p.Visible = (k == i)
        for k, b in enumerate(tabs):
            b.Tag = "tab_on" if k == i else "tab"
        UI.style_controls(header)

    for i, b in enumerate(tabs):
        b.Click += (lambda idx: (lambda s, e: show_tab(idx)))(i)

    def apply_theme():
        t = T()
        form.BackColor = t["bg"]
        UI.style_controls(form)
        X = CUR["X"]
        if X is not None:
            for g in (X["g_w"], X["pg_door"]["grid"], X["pg_item"]["grid"], X["g3"], X["g5"]):
                UI.style_grid(g)
            X["pg_door"]["grid"].ColumnHeadersHeight = 44
            X["pg_item"]["grid"].ColumnHeadersHeight = 44
        pic_logo.Image = UI.load_logo(44)
        lbl_title.ForeColor = t["text"]
        btn_theme.Text = u"☀  Giao diện sáng" if STATE["dark"] else u"☾  Giao diện tối"
        if X is not None:
            for _pg in X["pgs"]:
                for row in _pg["grid"].Rows:
                    row.Cells["img"].Value = UI.draw_segs(
                        X["groups"][int(row.Tag)]["defn"]["segs"], 72)
            for row in X["g3"].Rows:
                ins, r = X["sstate"]["recs"][int(row.Tag)]
                row.Cells["img"].Value = UI.draw_segs(X["sc"].defs[ins["name"]]["segs"], 72)
        UI.set_titlebar(form)
        show_tab(cur["tab"])

    def on_theme(s, e):
        STATE["dark"] = not STATE["dark"]
        UI.save_settings()
        apply_theme()
    btn_theme.Click += on_theme
    btn_clrhl.Click += apiw(lambda s, e: CUR["X"]["hl_clear"]() if CUR["X"] else None)
    btn_reset.Click += lambda s, e: CUR["X"]["reset"](s, e) if CUR["X"] else None

    def do_layout(*a):
        for pn, rows in LAYOUTS:
            UI.layout_rows(pn, rows)
        for pn, lc, il, rb in LAYOUTS_B:
            UI.layout_bottom(pn, lc, il, rb)

    def warn_empty(e, sc_):
        forms.alert(u"Không đọc được block nào trong CAD '{}'.\n\n"
                    u"Thường do: block đã bị Explode trong AutoCAD, hoặc CAD link chỉ "
                    u"chứa nét rời. Tab Tường vẫn dùng được.".format(e["label"]),
                    title=APP_TITLE,
                    sub_msg=u"Chẩn đoán: " + u", ".join(
                        u"{}={}".format(k, v) for k, v in sorted(sc_.stats.items())))

    def get_scan(e, warn=True):
        """Quét CAD lần đầu khi cần (có nhớ lại, đổi qua lại giữa các tầng không quét lại)."""
        if e.get("sc") is not None:
            return e["sc"]
        sc_ = CAD.scan(doc, e["obj"], False)     # tự đi xuyên block bọc ngoài
        e["sc"] = sc_
        UI.log(u"Quét CAD '{}': {} block, {} loại, {} layer nét".format(
            e["label"], len(sc_.insts), len(sc_.defs), len(sc_.segs_by_layer)))
        UI.log(u"Chẩn đoán hình học CAD: {}".format(
            u", ".join(u"{}={}".format(k, v) for k, v in sorted(sc_.stats.items()))))
        try:
            _cnt = {}
            for _i in sc_.insts:
                _cnt[_i["name"]] = _cnt.get(_i["name"], 0) + 1
            UI.log(u"Tên block ({} tên khác nhau): {}".format(
                len(_cnt), u"; ".join(u"{}×{} ({} nét)".format(
                    k, v, len(sc_.defs[k]["segs"])) for k, v in sorted(_cnt.items())[:40])))
        except Exception:
            pass
        if not sc_.insts:
            if warn:
                warn_empty(e, sc_)
            else:
                e["need_warn"] = True
        return sc_

    def install(X):
        for p in (X["p_wall"], X["p_door"], X["p_item"], X["p3"], X["p5"]):
            p.Visible = False
            host.Controls.Add(p)
            pages.append(p)
        for _pg in X["pgs"]:
            _pg["fill"]()
        CUR["X"] = X
        apply_theme()
        do_layout()

    def teardown():
        """Dọn các trang của tầng đang làm (đã lưu lựa chọn sang CARRY/mapping) để dựng tầng mới."""
        X = CUR["X"]
        if X is None:
            return
        try:
            X["snapshot"]()
        except Exception:
            UI.log(traceback.format_exc())
        try:
            X["hl_clear"]()
        except Exception:
            UI.log(traceback.format_exc())
        for pn, _rows in LAYOUTS:
            try:
                k = pn.GetHashCode()
                UI._REG.pop(k, None)
                UI._LAST_W.pop(k, None)
            except Exception:
                pass
        for p in list(pages):
            try:
                host.Controls.Remove(p)
                p.Dispose()
            except Exception:
                pass
        pages[:] = []
        LAYOUTS[:] = []
        LAYOUTS_B[:] = []
        CUR["X"] = None

    def activate(idx):
        e = entries[idx]
        form.Cursor = WF.Cursors.WaitCursor
        try:
            sc_ = get_scan(e)
            if e.pop("need_warn", False):
                warn_empty(e, sc_)
            teardown()
            X = build_content(e, sc_, lv_by.get(e["level"], act_lv))
            install(X)
            CUR["idx"] = idx
            lbl_sub.Text = u"{}  ·  tầng {}  ·  {} block ({} loại hình)  ·  {} layer".format(
                e["label"], e["level"], len(sc_.insts), len(X["groups"]),
                len(set(list(sc_.segs_by_layer.keys()) + list(sc_.layers_blocks.keys()))))
        finally:
            form.Cursor = WF.Cursors.Default

    def select_cad_silently(idx):
        was = guard["busy"]
        guard["busy"] = True
        try:
            cb_cad.SelectedIndex = idx
        finally:
            guard["busy"] = was

    @apiw
    def on_cad_changed(s, e):
        """Bước 2: đổi sang file CAD / tầng khác ngay trong form (không đóng/mở lại tool)."""
        if guard["busy"]:
            return
        i = cb_cad.SelectedIndex
        if i < 0 or i == CUR["idx"]:
            return
        guard["busy"] = True
        try:
            activate(i)
        except Exception:
            try:
                select_cad_silently(CUR["idx"])
            except Exception:
                pass
            raise
        finally:
            guard["busy"] = False

    STEP_ITEMS = [u"1 · Tường", u"2 · Cửa đi / Cửa sổ", u"3 · Nội thất", u"4 · Thang",
                  u"5 · Sàn (đặt Room + tạo sàn)"]
    STEP_KEYS = ["wall", "door", "item", "stair", "floor"]

    @apiw
    def on_all(s, e):
        """Chạy hàng loạt: lần lượt từng tầng đã chọn, mỗi tầng chạy các bước đã tick.
        Dùng lại lựa chọn đã làm ở tầng trước (layer, loại tường, family đã gán)."""
        if guard["busy"]:
            return
        order = sorted(range(len(entries)),
                       key=lambda i: (lv_elev.get(entries[i]["level"], 0.0),
                                      entries[i]["label"].lower()))
        labs = [entries[i]["title"] for i in order]
        sel = UI.select_list(labs, u"Chạy tất cả · chọn các tầng / file CAD cần làm", True, labs,
                             720, 560)
        if not sel:
            return
        steps = UI.select_list(STEP_ITEMS, u"Chạy tất cả · chọn các bước cho MỖI tầng", True,
                               STEP_ITEMS[:4], 560, 440)
        if not steps:
            return
        if not UI.alert(u"Chạy {} bước cho {} tầng?\n\nTool dùng lại layer, loại tường, family bạn đã "
                        u"chọn ở tầng đang làm. Nên làm trọn 1 tầng bằng tay trước để các lựa chọn "
                        u"được ghi nhớ. Kết quả từng tầng gom vào bảng tổng kết cuối cùng.".format(
                            len(steps), len(sel)), APP_TITLE,
                        u"Tầng: " + u"; ".join(sel), yes_no=True):
            return
        keys = [STEP_KEYS[STEP_ITEMS.index(x)] for x in steps]
        BATCH["on"] = True
        BATCH["log"] = []
        guard["busy"] = True
        n_done = 0
        try:
            for i in order:
                ent = entries[i]
                if ent["title"] not in sel:
                    continue
                BATCH["floor"] = ent["level"]
                lbl_sub.Text = u"Đang chạy hàng loạt: {} …".format(ent["title"])
                lbl_sub.Refresh()
                try:
                    activate(i)
                    CUR["X"]["run_steps"](keys)
                    n_done += 1
                except Exception:
                    UI.log(traceback.format_exc())
                    BATCH["log"].append((ent["level"], u"LỖI: " + traceback.format_exc()[-300:]))
            if CUR["idx"] >= 0:
                select_cad_silently(CUR["idx"])
        finally:
            BATCH["on"] = False
            guard["busy"] = False
        lines = [u"[{}] {}".format(f_, m_) for f_, m_ in BATCH["log"]]
        for ln in lines:
            UI.log(u"Chạy tất cả: " + ln)
        UI.alert(u"Đã chạy xong {} tầng.".format(n_done), APP_TITLE,
                 u"\n".join(lines[:60]) + (u"\n… (xem Block2Revit.log)" if len(lines) > 60 else u"")
                 or None)

    # ĐỌC BLOCK CỦA TẤT CẢ CÁC TẦNG TRƯỚC (1 lần): sang tầng sau chỉ việc dùng lại
    form.Cursor = WF.Cursors.WaitCursor
    try:
        for i_, e_ in enumerate(entries):
            lbl_sub.Text = u"Đọc block trước: {}/{}  ·  {} …".format(i_ + 1, len(entries), e_["title"])
            lbl_sub.Refresh()
            get_scan(e_, warn=False)
        _fpc = {}
        for i_, e_ in enumerate(entries):
            for _nm, _d in e_["sc"].defs.items():
                if _d.get("segs") and _d.get("fp") != "empty":
                    _fpc.setdefault(_d["fp"], set()).add(i_)
        UI.log(u"Đã đọc block của {} tầng: {} hình block khác nhau, {} hình xuất hiện ở từ 2 tầng "
                u"trở lên (gán family 1 lần ở tầng đầu là các tầng sau tự điền)".format(
                    len(entries), len(_fpc), sum(1 for v in _fpc.values() if len(v) > 1)))
    finally:
        form.Cursor = WF.Cursors.Default
    cb_cad.SelectedIndex = 0
    activate(0)
    cb_cad.SelectedIndexChanged += on_cad_changed
    btn_all.Click += on_all
    form.Shown += do_layout
    form.Shown += lambda s, e: UI.set_titlebar(form)
    form.FormClosing += lambda s, e: UI.save_settings()

    def _closed(s, e):
        try:
            AppDomain.CurrentDomain.SetData(FORM_KEY, None)
        except Exception:
            pass
        X = CUR["X"]
        if X is not None and X["HL"]["ids"]:
            try:
                API.post(X["hl_clear"])      # xoá nét khoanh; giữ ExternalEvent cho tới khi xong
            except Exception:
                pass
        else:
            API.dispose()
    form.FormClosed += _closed

    def _set_owner(s, e):
        """Gắn form làm cửa sổ con của Revit: luôn nổi trên Revit, thu nhỏ cùng Revit."""
        try:
            import ctypes
            h = API.main_hwnd()
            if h:
                f = ctypes.windll.user32.SetWindowLongPtrW
                f.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
                f.restype = ctypes.c_void_p
                f(ctypes.c_void_p(form.Handle.ToInt64()), -8, ctypes.c_void_p(h))
        except Exception:
            UI.log(traceback.format_exc())

    if API.ready():
        form.Shown += _set_owner
        try:
            AppDomain.CurrentDomain.SetData(FORM_KEY, form)
        except Exception:
            pass
        form.Show()          # MODELESS: vừa dùng tool vừa sửa model Revit
    else:
        UI.log(u"Không tạo được ExternalEvent ({}) -> chạy kiểu modal".format(API.error()))
        form.ShowDialog()
        form.Dispose()


# ------------------------------------------------------------------ main
def main():
    # đã có form đang mở -> đưa lên trước, không mở thêm
    try:
        old = AppDomain.CurrentDomain.GetData(FORM_KEY)
        if old is not None and not old.IsDisposed:
            old.WindowState = WF.FormWindowState.Normal
            old.Show()
            old.Activate()
            return
    except Exception:
        pass
    UI.load_settings()
    try:
        FU.set_user_rules(UI.SET.get("layer_rules"))
    except Exception:
        pass
    if not API.init(revit.uidoc.Application):
        UI.log(u"ExternalEvent lỗi: " + API.error())
    levels = B.get_levels(doc)
    lv_names = [l.Name for l in levels]
    infos = CAD.list_cads_info(doc, levels)
    if not infos:
        forms.alert(u"Project không có CAD link/import.", exitscript=True)
    if len(infos) == 1:        # chỉ 1 file: khỏi hỏi, tầng lấy theo level đang mở
        d = infos[0]
        lvn = d["level"] if d["level"] in lv_names else B.active_level(doc).Name
        entries = [{"label": d["label"], "obj": d["obj"], "level": lvn,
                    "title": u"{}  →  {}".format(d["label"], lvn)}]
    else:
        entries = pick_cads(infos, lv_names)       # BƯỚC 1: chọn nhiều file CAD + tầng
        if not entries:
            raise SystemExit
    symbols = B.get_symbols(doc)
    try:
        UI.log(u"Family KHÔNG liệt kê (theo kiểu đặt): {}".format(
            u", ".join(u"{}={}".format(k, v) for k, v in sorted(B.skipped_diag(doc).items()))))
    except Exception:
        pass
    UI.log(u"Bước 1: {} file CAD: {}".format(
        len(entries), u"; ".join(e["title"] for e in entries)))
    run_form(entries, symbols)         # BƯỚC 2: làm từng tầng hoặc tất cả


try:
    main()
except SystemExit:
    pass
except Exception as _ex:
    _tb = traceback.format_exc()
    UI.log(_tb)
    try:
        UI.alert(u"Lỗi: {}".format(_ex), APP_TITLE,
                 u"{}\n\n(đã ghi vào Block2Revit.log)".format(_tb[-900:]))
    except Exception:
        WF.MessageBox.Show(u"Lỗi: {}\n\n{}".format(_ex, _tb[-900:]), APP_TITLE)
