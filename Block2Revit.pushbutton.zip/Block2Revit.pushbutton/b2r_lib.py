# -*- coding: utf-8 -*-
"""Tìm family cho nội thất theo LAYER (thuần Python, không phụ thuộc Revit).

Loại nội thất lấy từ tên layer của block (b2r_furn.cat_from_layers). Module này:
  - scan_folder()      : liệt kê file .rfa trong thư viện (đệ quy, bỏ file backup .0001.rfa)
  - rank()/choose()    : với loại nội thất + kích thước block (dài x ngắn, mm) chọn ứng viên tốt nhất
                         trong số family đã có trong model (đã nạp) và file .rfa trong thư viện.
  - pick_type()        : trong các type của 1 family chọn type có kích thước gần block nhất.
Điểm = điểm TÊN (từ khoá tiếng Việt / Anh, đã bỏ dấu) + 0.5 x điểm KÍCH THƯỚC (số trong tên family/type,
vd '1200mm x 800mm', '1000*500', 'TỦ ÁO : 2700'). Không có số trong tên thì chỉ xét theo tên.
"""
import os
import re
import unicodedata

MIN_SCORE = 0.9          # dưới ngưỡng này: coi như không tìm thấy family đúng loại

# (cụm từ đã bỏ dấu, trọng số)
KW = {
    "bed": [("giuong", 1.0), ("bed", 1.0)],
    "nightstand": [("tab dau giuong", 1.2), ("tap dau giuong", 1.2), ("tu dau giuong", 1.2),
                   ("bedside", 1.2), ("nightstand", 1.2), ("tab", 0.6)],
    "wardrobe": [("tu quan ao", 1.2), ("tu ao", 1.2), ("wardrobe", 1.2), ("closet", 1.1),
                 ("tu", 0.7), ("cabinet", 0.6)],
    "tv": [("ke tv", 1.2), ("ke tivi", 1.2), ("tv", 1.0), ("tivi", 1.0)],
    "sofa": [("sofa", 1.2), ("sopha", 1.2), ("ghe dai", 0.9), ("bo ban ghe", 0.8)],
    "chair": [("armchair", 1.2), ("ghe", 1.0), ("chair", 1.0), ("stool", 0.8)],
    "table": [("ban trang diem", 1.3), ("dressing", 1.0), ("ban an", 1.2), ("ban lam viec", 1.2),
              ("ban", 0.8), ("table", 1.0), ("desk", 0.9)],
    "toilet": [("bon cau", 1.3), ("toilet", 1.3), ("wc", 1.0), ("bidet", 0.8), ("xi bet", 1.0)],
    "sink": [("chau rua", 1.3), ("lavabo", 1.3), ("basin", 1.2), ("sink", 1.2), ("lvb", 1.0),
             ("rua mat", 1.0)],
    "bathtub": [("bon tam", 1.3), ("bathtub", 1.3), ("bath", 0.9)],
    "shower": [("voi hoa sen", 1.3), ("sen tam", 1.3), ("voi sen", 1.1), ("shower", 1.3), ("sen", 0.7)],
    "stove": [("bep nau", 1.3), ("cooktop", 1.2), ("stove", 1.2), ("hob", 1.0), ("bep", 1.1)],
    "fridge": [("tu lanh", 1.3), ("fridge", 1.3), ("refrigerator", 1.3)],
}
# cụm từ làm loại đó KHÔNG đúng (vd 'tủ lạnh' không phải tủ áo)
NEG = {
    "wardrobe": ["tu lanh", "ke tv", "tu tv", "tu bep"],
    "chair": ["sofa", "ghe dai", "ban an", "bo ban"],
    "table": ["ban cong", "ban tho"],
    "stove": ["chau rua"],
    "sink": ["bon tam", "bon cau", "voi hoa sen", "voi sen"],
    "shower": ["bon tam"],
    "toilet": ["chau rua", "lavabo"],
    "bed": ["tab dau giuong", "tu dau giuong", "tap dau giuong", "bedside"],
    "sofa": [],
}


# loại thường co giãn theo block (family kéo được) nên kích thước trong tên ít quan trọng hơn
STRETCH = ("wardrobe", "tv", "sofa", "bed", "stove")


def norm(s):
    s = unicodedata.normalize("NFD", s or u"")
    s = u"".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.replace(u"đ", u"d").replace(u"Đ", u"d").lower()


def _joined(s):
    return u" " + u" ".join(t for t in re.split(r"[^a-z0-9]+", norm(s)) if t) + u" "


def name_score(cat, text):
    """Điểm tên 0..1.3 của chuỗi (tên family + type + thư mục) với loại nội thất."""
    kws = KW.get(cat)
    if not kws:
        return 0.0
    j = _joined(text)
    for ph in NEG.get(cat, ()):
        if (u" " + ph + u" ") in j:
            return 0.0
    best = 0.0
    for ph, w in kws:
        if (u" " + ph + u" ") in j or (len(ph) >= 4 and (u" " + ph) in j):
            best = max(best, w)
    return best


_PAIR = re.compile(r"(\d{3,4})\s*(?:mm)?\s*[x×\*]\s*(\d{3,4})", re.I)
_ONE = re.compile(r"(?<![\d.,])(\d{3,4})(?![\d.,])")


def parse_dims(text):
    """[(a, b)] cặp kích thước (mm, a >= b) và [(n, None)] số đơn trong chuỗi."""
    out = []
    s = text or u""
    for m in _PAIR.finditer(s):
        a, b = int(m.group(1)), int(m.group(2))
        out.append((max(a, b), min(a, b)))
    rest = _PAIR.sub(u" ", s)
    for m in _ONE.finditer(rest):
        n = int(m.group(1))
        if 300 <= n <= 6000:
            out.append((n, None))
    return out


def size_score(text, ab):
    """0..1 độ gần kích thước (None nếu tên không có số hoặc không biết kích thước block)."""
    if not ab or not ab[0]:
        return None
    a, b = max(ab), min(ab)
    ds = parse_dims(text)
    if not ds:
        return None
    best = None
    for p, q in ds:
        if q is not None:
            err = max(abs(p - a) / float(a), abs(q - b) / float(max(b, 1.0)))
        else:
            err = min(abs(p - a) / float(a), abs(p - b) / float(max(b, 1.0)))
        sc = max(0.0, 1.0 - err / 0.6)
        if best is None or sc > best:
            best = sc
    return best


def scan_folder(folder):
    """[(đường dẫn, tên không đuôi, đường dẫn tương đối)] các file .rfa (bỏ file backup *.0001.rfa)."""
    out = []
    if not folder or not os.path.isdir(folder):
        return out
    for root, _d, fns in os.walk(folder):
        for fn in fns:
            low = fn.lower()
            if low.endswith(".rfa") and not re.search(r"\.\d{4}\.rfa$", low):
                p = os.path.join(root, fn)
                out.append((p, os.path.splitext(fn)[0], os.path.relpath(p, folder)))
    out.sort(key=lambda t: t[2].lower())
    return out


def make_candidates(symbols, files, kinds=("level",)):
    """Danh sách ứng viên: family đã có trong model (key = 'Family : Type') + file .rfa chưa nạp.
    Family trong thư viện trùng tên với family đã nạp thì bỏ (dùng bản đã nạp)."""
    cands = []
    loaded_fams = set()
    for key, (sym, kind) in symbols.items():
        if kind not in kinds:
            continue
        fam = key.split(u" : ")[0]
        loaded_fams.add(norm(fam))
        cands.append({"label": key, "text": key, "key": key, "path": None, "loaded": True, "fam": fam})
    for path, stem, rel in files or []:
        if norm(stem) in loaded_fams:
            continue
        cands.append({"label": rel, "text": rel.replace(os.sep, u" ").replace(u"/", u" "),
                      "key": None, "path": path, "loaded": False, "fam": stem})
    return cands


def rank(cat, cands, ab):
    """[(điểm, ứng viên)] giảm dần; chỉ những ứng viên có điểm tên > 0."""
    out = []
    for c in cands:
        ns = name_score(cat, c["text"])
        if ns <= 0:
            continue
        ss = size_score(c["text"], ab)
        sc = ns + (0.5 * ss if ss is not None else 0.0) + (0.03 if c["loaded"] else 0.0)
        if ss is not None and ss < 0.2:        # tên ghi rõ kích thước mà lệch xa block -> hạ điểm
            sc -= (0.15 if cat in STRETCH else 0.4)
        out.append((sc, c))
    out.sort(key=lambda t: -t[0])
    return out


def choose(cat, cands, ab, min_score=MIN_SCORE):
    """(điểm, ứng viên) tốt nhất hoặc None."""
    r = rank(cat, cands, ab)
    if r and r[0][0] >= min_score:
        return r[0]
    return None


def pick_type(type_keys, ab):
    """Trong các key 'Family : Type' của 1 family chọn type gần kích thước block nhất
    (không type nào có số trong tên: lấy type đầu theo thứ tự tên)."""
    keys = sorted(type_keys, key=lambda s: s.lower())
    if not keys:
        return None
    best, bs = keys[0], -1.0
    for k in keys:
        ss = size_score(k.split(u" : ", 1)[-1], ab)
        if ss is None:
            ss = size_score(k, ab)
        if ss is not None and ss > bs:
            best, bs = k, ss
    return best
