# -*- coding: utf-8 -*-
"""Đọc THANG theo đúng từng BẬC trong CAD (thuần Python, mm, không phụ thuộc Revit).

Ý tưởng: coi các nét của block thang là một đồ thị phẳng, tìm các "mặt" kín -> mỗi mặt là
một bậc (chữ nhật / hình thang / tam giác = bậc chéo ở góc). Bỏ đường đi (nét giữa vế) và
mũi tên trước khi tìm mặt. Sau đó sắp bậc theo thứ tự đi lên (chữ số trong CAD hoặc mũi
tên) và suy ra: vạch bậc (riser) = cạnh chung của 2 bậc liên tiếp, biên trái/phải, đường đi.

analyze_stair_treads(segs, texts) -> dict(ok, reason, treads, risers, width, length, winders,
                                            n_text, src, arrow, notes)
tread_geometry(treads)          -> dict(risers, left, right, path, width, length)
"""
import math
from collections import defaultdict

TOL = 6.0            # mm: hai đầu nét cách nhau <= TOL coi là trùng điểm


# ------------------------------------------------------------------ tiện ích hình học
def _len(a, b):
    return math.hypot(b[0] - a[0], b[1] - a[1])


def _mid(a, b):
    return ((a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0)


def _cross(ax, ay, bx, by):
    return ax * by - ay * bx


def _area(poly):
    a = 0.0
    n = len(poly)
    for i in range(n):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % n]
        a += x0 * y1 - x1 * y0
    return a / 2.0


def _centroid(poly):
    a = _area(poly)
    if abs(a) < 1e-9:
        n = float(len(poly))
        return (sum(p[0] for p in poly) / n, sum(p[1] for p in poly) / n)
    cx = cy = 0.0
    n = len(poly)
    for i in range(n):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % n]
        f = x0 * y1 - x1 * y0
        cx += (x0 + x1) * f
        cy += (y0 + y1) * f
    return (cx / (6.0 * a), cy / (6.0 * a))


def _in_poly(poly, x, y, pad=0.0):
    inside = False
    n = len(poly)
    for i in range(n):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % n]
        if (y0 > y) != (y1 > y):
            xi = x0 + (y - y0) * (x1 - x0) / (y1 - y0)
            if x < xi:
                inside = not inside
    if inside or pad <= 0:
        return inside
    for i in range(n):
        if _pt_seg_dist((x, y), poly[i], poly[(i + 1) % n]) <= pad:
            return True
    return False


def _pt_seg_dist(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    if L2 < 1e-12:
        return _len(p, a)
    t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2
    t = 0.0 if t < 0 else (1.0 if t > 1 else t)
    return math.hypot(p[0] - (a[0] + dx * t), p[1] - (a[1] + dy * t))


def _simplify(poly, tol=2.5):
    """Bỏ đỉnh trùng và đỉnh nằm trên đường thẳng (thẳng hàng)."""
    pts = []
    for p in poly:
        if not pts or _len(p, pts[-1]) > 0.5:
            pts.append(p)
    if len(pts) > 1 and _len(pts[0], pts[-1]) <= 0.5:
        pts.pop()
    changed = True
    while changed and len(pts) > 3:
        changed = False
        for i in range(len(pts)):
            a, b, c = pts[i - 1], pts[i], pts[(i + 1) % len(pts)]
            if _pt_seg_dist(b, a, c) <= tol:
                pts.pop(i)
                changed = True
                break
    return pts


def _is_convex(poly, tol=3.0):
    n = len(poly)
    if n < 3:
        return False
    sgn = 0
    for i in range(n):
        a, b, c = poly[i], poly[(i + 1) % n], poly[(i + 2) % n]
        cr = _cross(b[0] - a[0], b[1] - a[1], c[0] - b[0], c[1] - b[1])
        d = _pt_seg_dist(b, a, c)
        if abs(cr) < 1e-9 or d <= tol:
            continue
        s = 1 if cr > 0 else -1
        if sgn == 0:
            sgn = s
        elif s != sgn:
            return False
    return True


# ------------------------------------------------------------------ nét: nối thẳng hàng
def _chains(segs):
    """Gộp các nét thẳng hàng, chạm/chồng nhau thành 'đường dài'. Trả [dict(a,b,idx)]."""
    n = len(segs)
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    dirs = []
    for s in segs:
        L = _len((s[0], s[1]), (s[2], s[3])) or 1.0
        dirs.append(((s[2] - s[0]) / L, (s[3] - s[1]) / L, L))
    for i in range(n):
        ai = (segs[i][0], segs[i][1])
        ux, uy, Li = dirs[i]
        for j in range(i + 1, n):
            vx, vy, Lj = dirs[j]
            if abs(_cross(ux, uy, vx, vy)) > 0.01:
                continue
            bj0 = (segs[j][0], segs[j][1])
            bj1 = (segs[j][2], segs[j][3])
            if abs(_cross(ux, uy, bj0[0] - ai[0], bj0[1] - ai[1])) > 3.0 or \
                    abs(_cross(ux, uy, bj1[0] - ai[0], bj1[1] - ai[1])) > 3.0:
                continue
            t0 = (bj0[0] - ai[0]) * ux + (bj0[1] - ai[1]) * uy
            t1 = (bj1[0] - ai[0]) * ux + (bj1[1] - ai[1]) * uy
            lo, hi = min(t0, t1), max(t0, t1)
            if lo <= Li + TOL and hi >= -TOL:
                parent[find(i)] = find(j)
    groups = defaultdict(list)
    for i in range(n):
        groups[find(i)].append(i)
    out = []
    for idx in groups.values():
        r = max(idx, key=lambda k: dirs[k][2])
        ux, uy, _ = dirs[r]
        ox, oy = segs[r][0], segs[r][1]
        ts = []
        for k in idx:
            for (px, py) in ((segs[k][0], segs[k][1]), (segs[k][2], segs[k][3])):
                ts.append((px - ox) * ux + (py - oy) * uy)
        lo, hi = min(ts), max(ts)
        out.append({"a": (ox + ux * lo, oy + uy * lo), "b": (ox + ux * hi, oy + uy * hi),
                    "idx": idx, "u": (ux, uy), "L": hi - lo})
    return out


def _seg_x(p0, p1, q0, q1):
    """Giao điểm 2 đoạn: (t, s, x, y) với t,s theo từng đoạn (0..1) hoặc None."""
    rx, ry = p1[0] - p0[0], p1[1] - p0[1]
    sx, sy = q1[0] - q0[0], q1[1] - q0[1]
    den = _cross(rx, ry, sx, sy)
    if abs(den) < 1e-9:
        return None
    qx, qy = q0[0] - p0[0], q0[1] - p0[1]
    t = _cross(qx, qy, sx, sy) / den
    s = _cross(qx, qy, rx, ry) / den
    return (t, s, p0[0] + rx * t, p0[1] + ry * t)


# ------------------------------------------------------------------ bỏ đường đi + mũi tên
def _strip_walkline(segs):
    """Bỏ 'đường đi' (nét dọc giữa vế cắt qua >= 3 vạch bậc, mỗi vạch cắt gần giữa) và
    mũi tên ở đầu đường đi. Trả (segs còn lại, mũi tên (x,y) hoặc None, số nét bỏ)."""
    ch = _chains(segs)
    walk = []
    for c in ch:
        if c["L"] < 400.0:
            continue
        lens = []
        for d in ch:
            if d is c or d["L"] < 150.0:
                continue
            if abs(_cross(c["u"][0], c["u"][1], d["u"][0], d["u"][1])) < 0.3:
                continue
            h = _seg_x(c["a"], c["b"], d["a"], d["b"])
            if h is None:
                continue
            t, s, _x, _y = h
            tp = TOL / max(c["L"], 1.0)
            sp = TOL / max(d["L"], 1.0)
            if tp < t < 1 - tp and sp < s < 1 - sp and 0.15 <= s <= 0.85:
                lens.append(d["L"])
        # đường đi thật: bị >= 3 vạch bậc CÙNG CỠ (dài gần bằng nhau) cắt xuyên qua gần giữa
        lens.sort()
        top = 0
        for i0 in range(len(lens)):
            k = 0
            for v in lens[i0:]:
                if v <= lens[i0] * 1.12:
                    k += 1
            top = max(top, k)
        if top >= 3:
            walk.append(c)
    if not walk:
        return list(segs), None, 0
    remove = set()
    arrow = None
    for c in walk:
        remove.update(c["idx"])
    # mũi tên: 2 nét xiên đối xứng chụm tại đầu đường đi, cùng phía thân đường đi
    for c in walk:
        ux, uy = c["u"]
        for (E, other, sg) in ((c["b"], c["a"], 1.0), (c["a"], c["b"], -1.0)):
            bx, by = other[0] - E[0], other[1] - E[1]
            bl = math.hypot(bx, by) or 1.0
            bx, by = bx / bl, by / bl                  # hướng từ đầu E vào thân
            cand = []
            for i, s in enumerate(segs):
                if i in remove:
                    continue
                for (p, q) in (((s[0], s[1]), (s[2], s[3])), ((s[2], s[3]), (s[0], s[1]))):
                    if _len(p, E) > TOL * 1.5:
                        continue
                    vx, vy = q[0] - p[0], q[1] - p[1]
                    Lq = math.hypot(vx, vy)
                    if Lq < 1.0:
                        continue
                    vx, vy = vx / Lq, vy / Lq
                    cr = _cross(bx, by, vx, vy)
                    dt = bx * vx + by * vy
                    if dt > 0.3 and 0.3 <= abs(cr) <= 0.95:
                        cand.append((i, cr, Lq))
            pos = [k for k in cand if k[1] > 0]
            neg = [k for k in cand if k[1] < 0]
            if pos and neg:
                for a_ in pos:
                    for b_ in neg:
                        if abs(a_[2] - b_[2]) <= 0.2 * max(a_[2], b_[2]):
                            remove.add(a_[0])
                            remove.add(b_[0])
                            arrow = E
                            break
    keep = [s for i, s in enumerate(segs) if i not in remove]
    return keep, arrow, len(remove)


# ------------------------------------------------------------------ đồ thị phẳng -> các mặt
class _Pts(object):
    def __init__(self, tol=TOL):
        self.tol = tol
        self.xy = []
        self.grid = defaultdict(list)

    def get(self, x, y):
        cx, cy = int(math.floor(x / self.tol)), int(math.floor(y / self.tol))
        best = None
        for ix in (cx - 1, cx, cx + 1):
            for iy in (cy - 1, cy, cy + 1):
                for k in self.grid.get((ix, iy), ()):
                    d = math.hypot(self.xy[k][0] - x, self.xy[k][1] - y)
                    if d <= self.tol and (best is None or d < best[0]):
                        best = (d, k)
        if best is not None:
            return best[1]
        self.xy.append((x, y))
        k = len(self.xy) - 1
        self.grid[(cx, cy)].append(k)
        return k


def _faces(segs):
    """Các mặt kín (đa giác, ngược chiều kim đồng hồ) của đồ thị phẳng dựng từ segs."""
    P = _Pts()
    for s in segs:
        P.get(s[0], s[1])
        P.get(s[2], s[3])
    nseg = len(segs)
    cuts = [[] for _ in range(nseg)]        # [(t, node)]
    for i, s in enumerate(segs):
        a, b = (s[0], s[1]), (s[2], s[3])
        La = _len(a, b)
        if La < 1.0:
            continue
        ux, uy = (b[0] - a[0]) / La, (b[1] - a[1]) / La
        cuts[i].append((0.0, P.get(*a)))
        cuts[i].append((La, P.get(*b)))
        # điểm (đầu nét khác) nằm trên thân nét này
        for k, (px, py) in enumerate(list(P.xy)):
            t = (px - a[0]) * ux + (py - a[1]) * uy
            if t <= TOL or t >= La - TOL:
                continue
            if abs(_cross(ux, uy, px - a[0], py - a[1])) <= TOL:
                cuts[i].append((t, k))
    # giao cắt X
    for i in range(nseg):
        a, b = (segs[i][0], segs[i][1]), (segs[i][2], segs[i][3])
        La = _len(a, b)
        if La < 1.0:
            continue
        for j in range(i + 1, nseg):
            c, d = (segs[j][0], segs[j][1]), (segs[j][2], segs[j][3])
            Lc = _len(c, d)
            if Lc < 1.0:
                continue
            h = _seg_x(a, b, c, d)
            if h is None:
                continue
            t, s, x, y = h
            if TOL / La < t < 1 - TOL / La and TOL / Lc < s < 1 - TOL / Lc:
                k = P.get(x, y)
                cuts[i].append((t * La, k))
                cuts[j].append((s * Lc, k))
    edges = set()
    for i in range(nseg):
        lst = sorted(cuts[i])
        for (t0, n0), (t1, n1) in zip(lst, lst[1:]):
            if n0 != n1:
                edges.add((min(n0, n1), max(n0, n1)))
    adj = defaultdict(set)
    for u, v in edges:
        adj[u].add(v)
        adj[v].add(u)
    # cắt cụt các nét thừa (đầu cụt)
    changed = True
    while changed:
        changed = False
        for u in list(adj.keys()):
            if len(adj[u]) <= 1:
                for v in list(adj[u]):
                    adj[v].discard(u)
                del adj[u]
                changed = True
    xy = P.xy
    order = {}
    for u, nb in adj.items():
        order[u] = sorted(nb, key=lambda w: math.atan2(xy[w][1] - xy[u][1], xy[w][0] - xy[u][0]))
    seen = set()
    faces = []
    for u in order:
        for v in order[u]:
            if (u, v) in seen:
                continue
            loop = []
            a, b = u, v
            guard = 0
            while (a, b) not in seen and guard < 5000:
                seen.add((a, b))
                loop.append(a)
                lst = order[b]
                idx = lst.index(a)
                c = lst[(idx - 1) % len(lst)]
                a, b = b, c
                guard += 1
            if len(loop) >= 3 and len(set(loop)) == len(loop):
                poly = [xy[k] for k in loop]
                if _area(poly) > 1.0:
                    faces.append(poly)
    return faces


# ------------------------------------------------------------------ thứ tự bậc
def _shared_edge(pa, pb):
    """Đoạn chung (p, q) giữa hai đa giác (cạnh thẳng hàng, chồng nhau) hoặc None."""
    best = None
    na, nb = len(pa), len(pb)
    for i in range(na):
        a0, a1 = pa[i], pa[(i + 1) % na]
        La = _len(a0, a1)
        if La < 1.0:
            continue
        ux, uy = (a1[0] - a0[0]) / La, (a1[1] - a0[1]) / La
        for j in range(nb):
            b0, b1 = pb[j], pb[(j + 1) % nb]
            if abs(_cross(ux, uy, b0[0] - a0[0], b0[1] - a0[1])) > TOL or \
                    abs(_cross(ux, uy, b1[0] - a0[0], b1[1] - a0[1])) > TOL:
                continue
            t0 = (b0[0] - a0[0]) * ux + (b0[1] - a0[1]) * uy
            t1 = (b1[0] - a0[0]) * ux + (b1[1] - a0[1]) * uy
            lo, hi = max(0.0, min(t0, t1)), min(La, max(t0, t1))
            if hi - lo > 30.0 and (best is None or hi - lo > best[0]):
                best = (hi - lo, (a0[0] + ux * lo, a0[1] + uy * lo),
                        (a0[0] + ux * hi, a0[1] + uy * hi))
    return None if best is None else (best[1], best[2])


def _hamilton_paths(n, nbr, cents, limit=60, budget=200000):
    """Các đường đi qua đủ n bậc (mỗi bậc 1 lần) theo đồ thị kề; ưu tiên đi thẳng/êm."""
    ends = [i for i in range(n) if len(nbr[i]) <= 1] or list(range(n))
    out = []
    steps = [0]

    def turn(a, b, c):
        v1 = (cents[b][0] - cents[a][0], cents[b][1] - cents[a][1])
        v2 = (cents[c][0] - cents[b][0], cents[c][1] - cents[b][1])
        l1 = math.hypot(*v1) or 1.0
        l2 = math.hypot(*v2) or 1.0
        return -(v1[0] * v2[0] + v1[1] * v2[1]) / (l1 * l2)

    def dfs(path, used):
        if len(out) >= limit or steps[0] > budget:
            return
        steps[0] += 1
        if len(path) == n:
            out.append(list(path))
            return
        cur = path[-1]
        cand = [k for k in nbr[cur] if k not in used]
        if len(path) >= 2:
            cand.sort(key=lambda k: turn(path[-2], cur, k))
        for k in cand:
            used.add(k)
            path.append(k)
            dfs(path, used)
            path.pop()
            used.discard(k)
    for s in ends:
        dfs([s], {s})
        if len(out) >= limit:
            break
    return out


def _label_dir(order, labels):
    """+1 nếu chữ số tăng dọc thứ tự, -1 nếu giảm, 0 nếu không đơn điệu / thiếu chữ."""
    seq = [labels[k] for k in order if labels.get(k) is not None]
    if len(seq) < 2:
        return 0
    if all(b >= a for a, b in zip(seq, seq[1:])):
        return 1
    if all(b <= a for a, b in zip(seq, seq[1:])):
        return -1
    return 2


def analyze_stair_treads(segs, texts=None):
    """segs: [(x0,y0,x1,y1)] mm (toạ độ thế giới); texts: [(chuỗi, x, y)]."""
    res = {"ok": False, "reason": u"", "notes": []}
    S = [(float(r[0]), float(r[1]), float(r[2]), float(r[3])) for r in segs
         if math.hypot(r[2] - r[0], r[3] - r[1]) >= 5.0]
    if len(S) < 8:
        res["reason"] = u"block có quá ít nét"
        return res
    if len(S) > 1500:
        res["reason"] = u"block quá nhiều nét ({})".format(len(S))
        return res
    arrow = None
    cand_sets = []
    S2, arrow, nrm = _strip_walkline(S)
    cand_sets.append((S2, nrm))
    if nrm:
        cand_sets.append((S, 0))            # phương án dự phòng: không bỏ nét giữa vế
    best = None
    for (SS, removed) in cand_sets:
        faces = [_simplify(f) for f in _faces(SS)]
        faces = [f for f in faces if 3 <= len(f) <= 6 and _is_convex(f)]
        if len(faces) < 3:
            continue
        areas = sorted(_area(f) for f in faces)
        ref = areas[len(areas) // 2]
        treads = [f for f in faces if 0.2 * ref <= _area(f) <= 8.0 * ref and _area(f) >= 5000.0]
        if len(treads) < 3:
            continue
        # chiếu nghỉ (mặt rất sâu) KHÔNG có riser -> không đưa vào cách dựng 1 vế liền này
        ta = sorted(_area(f) for f in treads)
        med = ta[len(ta) // 2]
        if ta[-1] > 3.0 * med:
            res["reason"] = u"có chiếu nghỉ (mặt quá sâu) → dùng cách tách vế"
            res["landing"] = True
            return res
        n = len(treads)
        nbr = [set() for _ in range(n)]
        for i in range(n):
            for j in range(i + 1, n):
                if _shared_edge(treads[i], treads[j]) is not None:
                    nbr[i].add(j)
                    nbr[j].add(i)
        cents = [_centroid(t) for t in treads]
        paths = _hamilton_paths(n, nbr, cents)
        if paths:
            best = (SS, removed, treads, nbr, cents, paths)
            break
    if best is None:
        res["reason"] = u"không tách được các bậc kín từ nét CAD"
        return res
    SS, removed, treads, nbr, cents, paths = best
    n = len(treads)
    labels = {}
    nums = []
    for tt in (texts or []):
        s2 = tt[0].strip()
        if s2.isdigit() and len(s2) <= 3:
            nums.append((int(s2), tt[1], tt[2]))
    res["n_text"] = max([v for v, _, _ in nums]) if nums else 0
    for (v, x, y) in nums:
        for k, t in enumerate(treads):
            if _in_poly(t, x, y):
                labels[k] = v if labels.get(k) is None else min(labels[k], v)
                break
    order = None
    src = u"chưa rõ"
    for p in paths:                         # ưu tiên đường đi có chữ số đơn điệu
        d = _label_dir(p, labels)
        if d == 1:
            order, src = p, u"chữ số"
            break
        if d == -1:
            order, src = list(reversed(p)), u"chữ số"
            break
    if order is None:
        order = paths[0]
        if arrow is not None:
            d0 = _len(cents[order[0]], arrow)
            d1 = _len(cents[order[-1]], arrow)
            if d0 < d1:
                order = list(reversed(order))
            src = u"mũi tên"
    res["order_by_label"] = (src == u"chữ số")
    polys = [treads[k] for k in order]
    # số bậc đọc được: bậc có chữ số lớn nhất thường là bậc cuối; đối chiếu để báo
    miss = n - len(set(range(n)) & set(order))
    geo = tread_geometry(polys)
    if geo is None:
        res["reason"] = u"không dựng được vạch bậc/biên từ các bậc đã tách"
        return res
    n_wind = 0
    for t in polys:
        if len(t) != 4:
            n_wind += 1
            continue
        d1 = (t[1][0] - t[0][0], t[1][1] - t[0][1])
        d2 = (t[2][0] - t[1][0], t[2][1] - t[1][1])
        d3 = (t[3][0] - t[2][0], t[3][1] - t[2][1])
        d4 = (t[0][0] - t[3][0], t[0][1] - t[3][1])
        l1, l2 = math.hypot(*d1) or 1.0, math.hypot(*d2) or 1.0
        l3, l4 = math.hypot(*d3) or 1.0, math.hypot(*d4) or 1.0
        par13 = abs(_cross(d1[0] / l1, d1[1] / l1, d3[0] / l3, d3[1] / l3))
        par24 = abs(_cross(d2[0] / l2, d2[1] / l2, d4[0] / l4, d4[1] / l4))
        right = abs((d1[0] * d2[0] + d1[1] * d2[1]) / (l1 * l2))
        if not (par13 < 0.03 and par24 < 0.03 and right < 0.03):
            n_wind += 1
    if removed:
        res["notes"].append(u"đã bỏ {} nét đường đi/mũi tên".format(removed))
    res.update({"ok": True, "treads": polys, "risers": n + 1, "src": src, "arrow": arrow,
                "width": geo["width"], "length": geo["length"], "winders": n_wind,
                "missing": miss})
    return res


# ------------------------------------------------------------------ vạch bậc / biên / đường đi
def _edges(poly):
    n = len(poly)
    return [(poly[i], poly[(i + 1) % n]) for i in range(n)]


def _subtract(edge, covers):
    """Phần của cạnh edge KHÔNG nằm trong các đoạn covers (thẳng hàng). -> [(p, q)]"""
    a, b = edge
    La = _len(a, b)
    if La < 1.0:
        return []
    ux, uy = (b[0] - a[0]) / La, (b[1] - a[1]) / La
    cut = []
    for (c0, c1) in covers:
        if abs(_cross(ux, uy, c0[0] - a[0], c0[1] - a[1])) > TOL * 1.5 or \
                abs(_cross(ux, uy, c1[0] - a[0], c1[1] - a[1])) > TOL * 1.5:
            continue
        t0 = (c0[0] - a[0]) * ux + (c0[1] - a[1]) * uy
        t1 = (c1[0] - a[0]) * ux + (c1[1] - a[1]) * uy
        lo, hi = max(0.0, min(t0, t1)), min(La, max(t0, t1))
        if hi - lo > 1.0:
            cut.append((lo, hi))
    cut.sort()
    out = []
    pos = 0.0
    for lo, hi in cut:
        if lo - pos > TOL:
            out.append((pos, lo))
        pos = max(pos, hi)
    if La - pos > TOL:
        out.append((pos, La))
    return [((a[0] + ux * p, a[1] + uy * p), (a[0] + ux * q, a[1] + uy * q)) for p, q in out]


def _far_parallel_edge(poly, riser):
    """Cạnh của bậc gần song song với riser và xa riser nhất (mép bên kia của bậc)."""
    r0, r1 = riser
    Lr = _len(r0, r1) or 1.0
    ux, uy = (r1[0] - r0[0]) / Lr, (r1[1] - r0[1]) / Lr
    mid = _mid(r0, r1)
    best = None
    fallback = None
    for (p, q) in _edges(poly):
        Le = _len(p, q)
        if Le < 1.0:
            continue
        ex, ey = (q[0] - p[0]) / Le, (q[1] - p[1]) / Le
        m = _mid(p, q)
        dist = abs(_cross(ux, uy, m[0] - mid[0], m[1] - mid[1]))
        if fallback is None or dist > fallback[0]:
            fallback = (dist, (p, q))
        if abs(_cross(ux, uy, ex, ey)) <= 0.35 and (best is None or dist > best[0]):
            best = (dist, (p, q))
    pick = best or fallback
    return pick[1] if pick else None


def tread_geometry(treads):
    """treads: đa giác theo thứ tự đi lên -> dict(risers, left, right, path, width, length)
    risers: n+1 đoạn ((x0,y0),(x1,y1)); left/right: danh sách điểm biên từ đầu tới cuối;
    path: đường đi (điểm giữa các vạch bậc). Trả None nếu không suy ra được."""
    n = len(treads)
    if n < 2:
        return None
    inner = []
    for i in range(n - 1):
        e = _shared_edge(treads[i], treads[i + 1])
        if e is None:
            return None
        inner.append(e)
    r0 = _far_parallel_edge(treads[0], inner[0])
    rn = _far_parallel_edge(treads[-1], inner[-1])
    if r0 is None or rn is None:
        return None
    risers = [r0] + inner + [rn]
    mids = [_mid(*r) for r in risers]

    def direction(i):
        a = mids[max(i - 1, 0)]
        b = mids[min(i + 1, len(mids) - 1)]
        return (b[0] - a[0], b[1] - a[1])

    def side_pts(i):
        r0_, r1_ = risers[i]
        dx, dy = direction(i)
        m = mids[i]
        c0 = _cross(dx, dy, r0_[0] - m[0], r0_[1] - m[1])
        return (r0_, r1_) if c0 > 0 else (r1_, r0_)          # (trái, phải)
    L_pts = []
    R_pts = []

    def push(lst, p):
        if not lst or _len(lst[-1], p) > 1.0:
            lst.append(p)
    lp, rp = side_pts(0)
    push(L_pts, lp)
    push(R_pts, rp)
    for i in range(n):
        d = (mids[i + 1][0] - mids[i][0], mids[i + 1][1] - mids[i][1])
        c = _mid(mids[i], mids[i + 1])
        pieces = []
        for e in _edges(treads[i]):
            pieces.extend(_subtract(e, [risers[i], risers[i + 1]]))
        lefts, rights = [], []
        for (p, q) in pieces:
            m = _mid(p, q)
            cr = _cross(d[0], d[1], m[0] - c[0], m[1] - c[1])
            (lefts if cr > 0 else rights).append((p, q))
        for lst, pcs, endp in ((L_pts, lefts, side_pts(i + 1)[0]),
                               (R_pts, rights, side_pts(i + 1)[1])):
            cur = lst[-1]
            pool = list(pcs)
            while pool:
                k = min(range(len(pool)),
                        key=lambda z: min(_len(cur, pool[z][0]), _len(cur, pool[z][1])))
                p, q = pool.pop(k)
                if _len(cur, q) < _len(cur, p):
                    p, q = q, p
                push(lst, p)
                push(lst, q)
                cur = q
            push(lst, endp)

    def thin(pts):
        out = []
        for p in pts:
            out.append(p)
            while len(out) >= 3 and _pt_seg_dist(out[-2], out[-3], out[-1]) <= 2.0:
                out.pop(-2)
        return out
    L_pts, R_pts = thin(L_pts), thin(R_pts)
    path = thin(list(mids))
    width = sorted(_len(*r) for r in risers[1:-1] or risers)
    width = width[len(width) // 2]
    length = sum(_len(path[i], path[i + 1]) for i in range(len(path) - 1))
    return {"risers": risers, "left": L_pts, "right": R_pts, "path": path,
            "width": width, "length": length}
