# -*- coding: utf-8 -*-
"""Bố cục thẻ family (thuần Python, không phụ thuộc WinForms để dễ kiểm thử).

groups : [(tiêu đề hoặc None, [k, k, ...])]  - k là vị trí trong danh sách đang hiển thị
trả về : dict(rects={k: (x, y, w, h)}, heads=[(y, h, tiêu đề)], content, cols, tw, th, step)
"""
import math

# cỡ ô: tw = bề rộng mong muốn, th = chiều cao ô
DENS = {
    "S": {"tw": 120, "th": 124},
    "M": {"tw": 156, "th": 164},
    "L": {"tw": 204, "th": 212},
}
DENS_ORDER = ("S", "M", "L")
HEAD_H = 30
GROUP_GAP = 14


def compute_layout(groups, cw, mode="grid", dens="M", pad=14, gap=10, list_h=60,
                   head_h=HEAD_H):
    if mode == "grid":
        d = DENS.get(dens) or DENS["M"]
        cols = max(1, int((cw - 2 * pad + gap) // (d["tw"] + gap)))
        tw = max(60, int((cw - 2 * pad - gap * (cols - 1)) // cols))
        th = d["th"]
    else:
        cols = 1
        tw = max(100, int(cw - 2 * pad))
        th = list_h
    rects = {}
    heads = []
    y = pad
    y_end = pad
    for title, ks in groups:
        if not ks:
            continue
        if title is not None:
            heads.append((y, head_h, title))
            y += head_h + 4
        for i, k in enumerate(ks):
            r, c = divmod(i, cols)
            rects[k] = (pad + c * (tw + gap), y + r * (th + gap), tw, th)
        rows = int(math.ceil(len(ks) / float(cols)))
        y_end = y + rows * (th + gap) - gap
        y = y_end + GROUP_GAP
    content = y_end + pad
    return {"rects": rects, "heads": heads, "content": content, "cols": cols,
            "tw": tw, "th": th, "step": th + gap}


def hit(rects, x, y):
    """Vị trí k của thẻ chứa điểm (x, y) trong toạ độ nội dung, hoặc -1."""
    for k, (rx, ry, rw, rh) in rects.items():
        if rx <= x <= rx + rw and ry <= y <= ry + rh:
            return k
    return -1


def nav_vertical(rects, k, direction):
    """Từ thẻ k đi lên (direction<0) / xuống (direction>0): chọn hàng gần nhất,
    trong hàng đó chọn thẻ có tâm gần nhất theo chiều ngang. Không có -> giữ k."""
    if k not in rects:
        return k
    x, y, w, h = rects[k]
    cx = x + w / 2.0
    best = None
    for j, (rx, ry, rw, rh) in rects.items():
        if direction > 0 and ry <= y + 1:
            continue
        if direction < 0 and ry >= y - 1:
            continue
        key = (abs(ry - y), abs(rx + rw / 2.0 - cx))
        if best is None or key < best[0]:
            best = (key, j)
    return best[1] if best else k


def group_positions(fams, group_on):
    """fams: danh sách tên family theo thứ tự hiển thị. Trả [(tiêu đề, [k...])]
    (nhóm theo family, giữ thứ tự xuất hiện đầu tiên) hoặc 1 nhóm không tiêu đề."""
    if not group_on:
        return [(None, list(range(len(fams))))]
    order = []
    by = {}
    for k, f in enumerate(fams):
        if f not in by:
            by[f] = []
            order.append(f)
        by[f].append(k)
    return [(u"{}  ·  {} type".format(f, len(by[f])), by[f]) for f in order]
