# -*- coding: utf-8 -*-
"""Hiểu NỘI THẤT trong block CAD (thuần Python, đơn vị mm, không phụ thuộc Revit).

  - cat_from_layers(): loại nội thất lấy từ TÊN LAYER (không còn đoán theo tên block / hình / kích thước).
  - body_segs()     : lấy "thân" block (bỏ cung mở cánh + tay cánh, bỏ nét rời xa như dim, ghi chú).
  - analyze_front() : tìm MẶT TRƯỚC của block: lưng sát tường nào (tường Revit hoặc nét tường CAD),
                      đầu giường (gối), két bồn cầu, phía cánh tủ...  Trả hướng mặt trước (vector đơn vị).
  - resolve_scene() : tab đầu giường theo hướng giường gần nhất, ghế quay về bàn gần nhất.
  - consensus()     : block cùng hình: chỗ nào không có bằng chứng thì theo hướng của các block giống.
  - signature()/similar(): chữ ký hình học (không phụ thuộc xoay/lật, chịu sai lệch nhỏ) để nhận
                      block "gần giống" giữa các tầng / các file CAD.
"""
import math
import re
import unicodedata
import b2r_geom as G

# ------------------------------------------------------------------ loại nội thất (THEO LAYER)
# Không còn đoán loại theo tên block / chữ / kích thước: loại nội thất lấy từ TÊN LAYER của block
# (người dùng đã chia layer sẵn: A-NT-GIUONG, A-WC-BON-CAU, ...). Có thể thêm/sửa luật trong
# settings.json (khoá "layer_rules": {"loại": ["cụm từ layer", ...]}).
CATS = [
    ("bed", u"Giường"),
    ("nightstand", u"Tab đầu giường"),
    ("wardrobe", u"Tủ / tủ áo"),
    ("tv", u"Kệ TV"),
    ("sofa", u"Sofa"),
    ("chair", u"Ghế"),
    ("table", u"Bàn"),
    ("toilet", u"Bồn cầu"),
    ("sink", u"Lavabo / chậu"),
    ("bathtub", u"Bồn tắm"),
    ("shower", u"Sen tắm"),
    ("stove", u"Bếp nấu"),
    ("fridge", u"Tủ lạnh"),
    ("accessory", u"Phụ kiện (không tự đặt)"),
    ("other", u"Khác"),
]
CAT_LABEL = dict(CATS)
LABEL_CAT = dict((v, k) for k, v in CATS)
CAT_LABELS = [v for _k, v in CATS]


def norm(s):
    s = unicodedata.normalize("NFD", s or u"")
    s = u"".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.replace(u"đ", u"d").replace(u"Đ", u"d").lower()


def tokens(s):
    return [t for t in re.split(r"[^a-z0-9]+", norm(s)) if t]


# (loại, [cụm từ trong tên layer đã bỏ dấu, cách nhau bằng khoảng trắng]) - luật đứng trước thắng.
# Cụm cụ thể (tab đầu giường, tủ lạnh, chậu rửa bếp) phải đứng TRƯỚC cụm chung (giường, tủ, bếp).
LAYER_RULES = [
    ("other", [u"ban cong", u"can ho"]),
    ("accessory", [u"phu kien"]),
    ("nightstand", [u"tab dau giuong", u"tap dau giuong", u"tu dau giuong", u"tdg"]),
    ("bed", [u"giuong"]),
    ("fridge", [u"tu lanh"]),
    ("wardrobe", [u"tu quan ao", u"tu ao", u"tu giay", u"tu bep", u"tu ruou", u"tu trang tri", u"tu kinh", u"tu"]),
    ("tv", [u"ke tv", u"ke tivi", u"tv", u"tivi"]),
    ("sofa", [u"sofa", u"sopha"]),
    ("toilet", [u"bon cau", u"xi bet", u"bidet", u"toilet"]),
    ("bathtub", [u"bon tam", u"bathtub"]),
    ("shower", [u"sen tam", u"phong tam dung", u"shower"]),
    ("sink", [u"chau rua", u"lavabo", u"bon rua", u"lvb", u"basin"]),
    ("stove", [u"bep nau", u"bep ga", u"bep tu", u"bep tu", u"bep"]),
    ("table", [u"ban trang diem", u"ban an", u"ban lam viec", u"ban tra", u"ban tho", u"ban hoc", u"ban"]),
    ("chair", [u"ghe lam viec", u"ghe don", u"ghe an", u"ghe", u"chair"]),
]
_USER_RULES = []


def set_user_rules(d):
    """d: {loại: [cụm từ layer]} từ settings.json - đứng TRƯỚC luật mặc định."""
    global _USER_RULES
    out = []
    for cat, phr in (d or {}).items():
        if cat in CAT_LABEL:
            out.append((cat, [norm(x).strip() for x in (phr or []) if x and x.strip()]))
    _USER_RULES = out


def cat_from_layers(layers):
    """(loại, độ tin cậy, lý do) theo TÊN LAYER của block. Layer '0' / không khớp luật -> ('other', 0, '')."""
    joined = []
    for ly in layers or []:
        t = u" ".join(tokens(ly))
        if t:
            joined.append((ly, u" " + t + u" "))
    for rules in (_USER_RULES, LAYER_RULES):
        for cat, phrases in rules:
            for ly, j in joined:
                for ph in phrases:
                    if ph and (u" " + ph + u" ") in j:
                        return cat, 1.0, u"theo layer '{}'".format(ly)
    return "other", 0.0, u""


# ------------------------------------------------------------------ thân block
def _seg_dist(p, q):
    def pt_seg(px, py, x0, y0, x1, y1):
        dx, dy = x1 - x0, y1 - y0
        L2 = dx * dx + dy * dy
        if L2 < 1e-9:
            return math.hypot(px - x0, py - y0)
        t = max(0.0, min(1.0, ((px - x0) * dx + (py - y0) * dy) / L2))
        return math.hypot(px - (x0 + t * dx), py - (y0 + t * dy))

    def ccw(ax, ay, bx, by, cx, cy):
        return (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)
    d1 = ccw(p[0], p[1], p[2], p[3], q[0], q[1])
    d2 = ccw(p[0], p[1], p[2], p[3], q[2], q[3])
    d3 = ccw(q[0], q[1], q[2], q[3], p[0], p[1])
    d4 = ccw(q[0], q[1], q[2], q[3], p[2], p[3])
    if ((d1 > 0) != (d2 > 0)) and ((d3 > 0) != (d4 > 0)):
        return 0.0
    return min(pt_seg(p[0], p[1], q[0], q[1], q[2], q[3]),
               pt_seg(p[2], p[3], q[0], q[1], q[2], q[3]),
               pt_seg(q[0], q[1], p[0], p[1], p[2], p[3]),
               pt_seg(q[2], q[3], p[0], p[1], p[2], p[3]))


def body_segs(segs, mask=None, swing=None, join=40.0):
    """Thân block: bỏ cung mở cánh (mask) + tay cánh nối tâm cung, bỏ cụm nét rời xa thân."""
    swing = swing or []
    keep = []
    for i, s in enumerate(segs):
        if mask is not None and i < len(mask) and mask[i]:
            continue
        L = math.hypot(s[2] - s[0], s[3] - s[1])
        if L < 1.0:
            continue
        leaf = False
        for (cx, cy, r) in swing:
            for (px, py, qx, qy) in ((s[0], s[1], s[2], s[3]), (s[2], s[3], s[0], s[1])):
                if math.hypot(px - cx, py - cy) < 25.0 and abs(L - r) <= max(25.0, 0.1 * r):
                    leaf = True
        if not leaf:
            keep.append(s)
    if len(keep) < 3:
        keep = [s for s in segs if math.hypot(s[2] - s[0], s[3] - s[1]) >= 1.0]
    n = len(keep)
    if n < 2 or n > 700:
        return keep
    boxes = [(min(s[0], s[2]) - join, min(s[1], s[3]) - join,
              max(s[0], s[2]) + join, max(s[1], s[3]) + join) for s in keep]
    par = list(range(n))

    def find(x):
        while par[x] != x:
            par[x] = par[par[x]]
            x = par[x]
        return x
    for i in range(n):
        bi = boxes[i]
        for j in range(i + 1, n):
            bj = boxes[j]
            if bi[2] < bj[0] or bj[2] < bi[0] or bi[3] < bj[1] or bj[3] < bi[1]:
                continue
            if _seg_dist(keep[i], keep[j]) <= join:
                ri, rj = find(i), find(j)
                if ri != rj:
                    par[ri] = rj
    cl = {}
    for i in range(n):
        cl.setdefault(find(i), []).append(i)
    if len(cl) == 1:
        return keep

    def bbox_of(ids):
        xs = [keep[i][0] for i in ids] + [keep[i][2] for i in ids]
        ys = [keep[i][1] for i in ids] + [keep[i][3] for i in ids]
        return (min(xs), min(ys), max(xs), max(ys))
    main = max(cl.values(), key=lambda ids: sum(math.hypot(keep[i][2] - keep[i][0],
                                                            keep[i][3] - keep[i][1]) for i in ids))
    mb = bbox_of(main)
    pad = 60.0
    out = list(main)
    for ids in cl.values():
        if ids is main:
            continue
        b = bbox_of(ids)
        if not (b[2] < mb[0] - pad or mb[2] + pad < b[0] or b[3] < mb[1] - pad or mb[3] + pad < b[1]):
            out.extend(ids)
    return [keep[i] for i in sorted(out)]


def body_rect(segs):
    """(cx, cy, a, b, th) với a >= b và th = hướng trục dài. None nếu không đủ nét."""
    pts = []
    for s in segs:
        pts.append((s[0], s[1]))
        pts.append((s[2], s[3]))
    r = G.min_area_rect(pts)
    if not r:
        return None
    cx, cy, a, b, th = r
    if a < b:
        th += math.pi / 2.0
        a, b = b, a
    return (cx, cy, a, b, th)


# ------------------------------------------------------------------ tìm MẶT TRƯỚC
BACK_ON_END = {"bed": True, "toilet": True, "wardrobe": False, "tv": False, "sofa": False,
               "sink": False, "bathtub": False, "stove": False, "fridge": None, "shower": None,
               "nightstand": None, "chair": None, "table": None, "other": None, "accessory": None}


# chỉ các loại có "mặt trước" rõ ràng mới được tool tự xoay theo mặt trước
FACE_CATS = ("bed", "nightstand", "wardrobe", "tv", "sofa", "toilet", "sink", "chair",
             "bathtub", "stove", "fridge", "shower")


def faces_from_walls(walls):
    """walls: [(wall, x0,y0,x1,y1, nửa dày, phạt)] của b2r_build.host_walls -> các MẶT tường."""
    out = []
    for w in walls or []:
        x0, y0, x1, y1, hw = w[1], w[2], w[3], w[4], w[5]
        L = math.hypot(x1 - x0, y1 - y0)
        if L < 1.0:
            continue
        nx, ny = -(y1 - y0) / L, (x1 - x0) / L
        for sgn in (1.0, -1.0):
            out.append((x0 + nx * hw * sgn, y0 + ny * hw * sgn, x1 + nx * hw * sgn, y1 + ny * hw * sgn))
    return out


def _wall_gap(c, n, h, e, L, faces):
    """Khoảng hở (mm) từ cạnh (pháp tuyến ngoài n, nửa kích thước h, hướng cạnh e, dài L) tới mặt tường
    song song gần nhất nằm phía ngoài cạnh; None nếu không có."""
    mid = (c[0] + n[0] * h, c[1] + n[1] * h)
    best = None
    for (x0, y0, x1, y1) in faces:
        dx, dy = x1 - x0, y1 - y0
        l = math.hypot(dx, dy)
        if l < 200.0:
            continue
        if abs((dx * e[0] + dy * e[1]) / l) < 0.978:       # lệch hơn ~12° so với cạnh
            continue
        g = (x0 - mid[0]) * n[0] + (y0 - mid[1]) * n[1]
        if g < -90.0 or g > 320.0:
            continue
        t0 = (x0 - mid[0]) * e[0] + (y0 - mid[1]) * e[1]
        t1 = (x1 - mid[0]) * e[0] + (y1 - mid[1]) * e[1]
        ov = min(max(t0, t1), L / 2.0) - max(min(t0, t1), -L / 2.0)
        if ov < min(0.3 * L, 300.0):
            continue
        d = abs(g) if g >= 0 else abs(g) + 10.0
        if best is None or d < best:
            best = d
    return best


def _wall_score(gap):
    if gap is None:
        return 0.0
    if gap <= 60.0:
        return 0.95
    if gap <= 120.0:
        return 0.85
    if gap <= 200.0:
        return 0.7
    return 0.5


def _frame_rect(segs, th):
    """Hộp bao của các nét theo hệ trục xoay th: (cx, cy, a, b, th) với a >= b."""
    c, s_ = math.cos(th), math.sin(th)
    us, vs = [], []
    for sg in segs:
        for (x, y) in ((sg[0], sg[1]), (sg[2], sg[3])):
            us.append(x * c + y * s_)
            vs.append(-x * s_ + y * c)
    if not us:
        return None
    u0, u1, v0, v1 = min(us), max(us), min(vs), max(vs)
    cu, cv = (u0 + u1) / 2.0, (v0 + v1) / 2.0
    cx, cy = cu * c - cv * s_, cu * s_ + cv * c
    a, b = u1 - u0, v1 - v0
    if a < b:
        th += math.pi / 2.0
        a, b = b, a
    return (cx, cy, a, b, th)


def wall_aligned_rect(segs, faces, rect):
    """Hộp bao theo hình (min_area_rect) bị xoay tuỳ ý với vật bầu dục / tròn (bồn cầu, ghế...). Nếu có mặt tường
    sát hộp (cách <= 350 mm) thì căn lại hộp theo HƯỚNG TƯỜNG đó: mặt tường song song với cạnh hộp -> đo
    được khoảng hở / cạnh lưng đúng. Không có tường sát: giữ nguyên hộp ban đầu."""
    if not faces:
        return rect
    cx, cy, a, b, th = rect
    reach = max(a, b) / 2.0 + 350.0
    best = None
    for (x0, y0, x1, y1) in faces:
        dx, dy = x1 - x0, y1 - y0
        l = math.hypot(dx, dy)
        if l < 200.0:
            continue
        # khoảng cách tâm hộp -> đoạn tường
        t = max(0.0, min(1.0, ((cx - x0) * dx + (cy - y0) * dy) / (l * l)))
        d = math.hypot(cx - (x0 + t * dx), cy - (y0 + t * dy))
        if d > reach:
            continue
        if best is None or d < best[0]:
            best = (d, math.atan2(dy, dx))
    if best is None:
        return rect
    wa = best[1]
    diff = (wa - th) % (math.pi / 2.0)
    diff = min(diff, math.pi / 2.0 - diff)
    if diff < math.radians(4.0):
        return rect
    r2 = _frame_rect(segs, wa)
    return r2 or rect


def analyze_front(cat, segs, arcs, swing, faces):
    """segs: nét THÂN block (thế giới); arcs: [(x, y)] điểm giữa các cung KHÔNG phải cung mở cánh;
    swing: [(x, y)] điểm giữa các cung mở cánh; faces: [(x0,y0,x1,y1)] mặt tường.
    Trả dict(rect, face, conf, how, ef, ep, cat) hoặc None (không đọc được hình).
    face = hướng nhìn ra của mặt trước (vector đơn vị) hoặc None nếu chưa biết."""
    r = body_rect(segs)
    if r is None:
        return None
    r = wall_aligned_rect(segs, faces, r)
    cx, cy, a, b, th = r
    u = (math.cos(th), math.sin(th))
    v = (-math.sin(th), math.cos(th))
    sides = [("+u", u, a / 2.0, v, b, True), ("-u", (-u[0], -u[1]), a / 2.0, v, b, True),
             ("+v", v, b / 2.0, u, a, False), ("-v", (-v[0], -v[1]), b / 2.0, u, a, False)]
    square = a / max(b, 1.0) < 1.2
    prior = BACK_ON_END.get(cat)
    score = {}
    why = {}
    for nm, n, h, e, L, is_end in sides:
        s = 0.0
        w = _wall_score(_wall_gap((cx, cy), n, h, e, L, faces))
        if w:
            s += w
            why[nm] = u"lưng sát tường"
        if prior is not None and (is_end == prior or square):
            s += 0.12
        score[nm] = s
    cue = _detail_cue(cat, segs, arcs, swing, (cx, cy, a, b, th), u, v)
    for nm, (val, txt) in cue.items():
        if val > 0:
            score[nm] += 0.7 * val
            why[nm] = (why[nm] + u" + " if nm in why else u"") + txt
    order = sorted(score.items(), key=lambda kv: -kv[1])
    top, second = order[0], order[1]
    conf = min(1.0, top[1])
    if top[1] - second[1] < 0.08:
        conf *= 0.6
    back = [s_ for s_ in sides if s_[0] == top[0]][0]
    out = {"rect": (cx, cy, a, b, th), "cat": cat, "conf": conf, "how": why.get(top[0], u""),
           "face": None, "back": None, "ef": None, "ep": None}
    if conf >= 0.5 and cat in FACE_CATS and cat != "chair":
        n = back[1]
        out["back"] = n
        out["face"] = (-n[0], -n[1])
        along_u = back[5]          # cạnh lưng nằm ở đầu trục dài -> mặt trước chạy theo trục dài
        out["ef"], out["ep"] = (a, b) if along_u else (b, a)
    return out


def _detail_cue(cat, segs, arcs, swing, rect, u, v):
    """{cạnh: (điểm 0..1 'đây là LƯNG', ghi chú)} theo chi tiết bên trong block."""
    cx, cy, a, b, _th = rect
    res = {}
    if cat == "bed":
        # đầu giường: đầu có nhiều nét hơn (gối, tựa đầu)
        dens = {"+u": 0.0, "-u": 0.0}
        for s in segs:
            mx, my = (s[0] + s[2]) / 2.0, (s[1] + s[3]) / 2.0
            t = (mx - cx) * u[0] + (my - cy) * u[1]
            L = math.hypot(s[2] - s[0], s[3] - s[1])
            if t > a * 0.22:
                dens["+u"] += L
            elif t < -a * 0.22:
                dens["-u"] += L
        hi, lo = ("+u", "-u") if dens["+u"] >= dens["-u"] else ("-u", "+u")
        ratio = dens[hi] / max(dens[lo], 1.0)
        if ratio >= 1.35 and dens[hi] > 0:
            res[hi] = (min(1.0, 0.5 + 0.3 * (ratio - 1.35)), u"đầu giường (gối)")
    elif cat in ("toilet",):
        if arcs:
            t = sum((p[0] - cx) * u[0] + (p[1] - cy) * u[1] for p in arcs) / len(arcs)
            if abs(t) >= 0.08 * a:
                res["-u" if t > 0 else "+u"] = (0.65, u"két ở đầu đối diện bồn")
    elif cat in ("wardrobe", "tv"):
        if swing:
            t = sum((p[0] - cx) * v[0] + (p[1] - cy) * v[1] for p in swing) / len(swing)
            if abs(t) >= 0.15 * b:
                res["-v" if t > 0 else "+v"] = (0.65, u"cánh mở về phía trước")
    return res


# ------------------------------------------------------------------ cả tầng
def _snap_axis(vec, rect):
    """Trục (±u, ±v) của rect gần vec nhất."""
    th = rect[4]
    cands = [(math.cos(th), math.sin(th)), (-math.cos(th), -math.sin(th)),
             (-math.sin(th), math.cos(th)), (math.sin(th), -math.cos(th))]
    return max(cands, key=lambda c: c[0] * vec[0] + c[1] * vec[1])


def _axes_ef(face, rect):
    cx, cy, a, b, th = rect
    along_u = abs(face[0] * math.cos(th) + face[1] * math.sin(th)) > 0.7
    return (a, b) if along_u else (b, a)


def resolve_scene(infos):
    """infos: list dict (kết quả analyze_front + 'cat'). Sửa tại chỗ:
    tab đầu giường theo hướng giường gần nhất; ghế (chưa có hướng) quay về bàn gần nhất."""
    beds = [i for i in infos if i and i["cat"] == "bed" and i["face"]]
    tables = [i for i in infos if i and i["cat"] == "table"]
    for it in infos:
        if not it:
            continue
        r = it["rect"]
        if it["cat"] == "nightstand" and beds and it["conf"] < 0.85:
            near = None
            for bd in beds:
                br = bd["rect"]
                d = math.hypot(r[0] - br[0], r[1] - br[1]) - (br[2] + br[3]) / 4.0 - (r[2] + r[3]) / 4.0
                if near is None or d < near[0]:
                    near = (d, bd)
            if near and near[0] <= 900.0:
                f = _snap_axis(near[1]["face"], r)
                it["face"], it["conf"], it["how"] = f, 0.8, u"theo hướng giường gần nhất"
                it["back"] = (-f[0], -f[1])
                it["ef"], it["ep"] = _axes_ef(f, r)
        elif it["cat"] == "chair" and not it["face"] and tables:
            near = None
            for tb in tables:
                tr = tb["rect"]
                d = math.hypot(r[0] - tr[0], r[1] - tr[1])
                if near is None or d < near[0]:
                    near = (d, tr)
            if near and near[0] <= 1300.0:
                vx, vy = near[1][0] - r[0], near[1][1] - r[1]
                f = _snap_axis((vx, vy), r)
                it["face"], it["conf"], it["how"] = f, 0.6, u"quay về bàn gần nhất"
                it["back"] = (-f[0], -f[1])
                it["ef"], it["ep"] = _axes_ef(f, r)
    return infos


def consensus(items):
    """items: list (info, tf) cùng 1 nhóm block giống hình; tf = (ox, oy, bx_x, bx_y, by_x, by_y).
    Block thiếu bằng chứng lấy hướng (theo toạ độ CỤC BỘ của block) từ các block giống đã có hướng."""
    votes = []
    for info, tf in items:
        if not info or not info["face"] or info["conf"] < 0.6:
            continue
        det = tf[2] * tf[5] - tf[3] * tf[4]
        if abs(det) < 1e-9:
            continue
        fx, fy = info["face"]
        lx = (tf[5] * fx - tf[4] * fy) / det
        ly = (-tf[3] * fx + tf[2] * fy) / det
        L = math.hypot(lx, ly) or 1.0
        votes.append((lx / L, ly / L, info["conf"]))
    if not votes:
        return items
    best, bw = None, 0.0
    for vx, vy, _w in votes:
        w = sum(c for (x, y, c) in votes if x * vx + y * vy > 0.93)
        if w > bw:
            best, bw = (vx, vy), w
    if best is None or bw < 0.6:
        return items
    for info, tf in items:
        if not info or info["face"] or info["conf"] >= 0.6:
            continue
        wx = tf[2] * best[0] + tf[4] * best[1]
        wy = tf[3] * best[0] + tf[5] * best[1]
        L = math.hypot(wx, wy) or 1.0
        f = _snap_axis((wx / L, wy / L), info["rect"])
        info["face"], info["conf"], info["how"] = f, 0.55, u"theo các block cùng hình"
        info["back"] = (-f[0], -f[1])
        info["ef"], info["ep"] = _axes_ef(f, info["rect"])
    return items


# ------------------------------------------------------------------ chữ ký hình (block gần giống)
SIG_N = 20
_W = SIG_N + 2
_VAR_CACHE = {}


def signature(segs, n=SIG_N):
    """Chữ ký không phụ thuộc xoay/lật: {'d': [dài, ngắn], 'n': n, 'm': mask hex}. None nếu quá ít nét."""
    r = body_rect(segs)
    if r is None or max(r[2], r[3]) < 80.0:
        return None
    cx, cy, a, b, th = r
    c, s_ = math.cos(th), math.sin(th)
    cells = set()
    step = max(4.0, min(a, b) / (n * 2.0))
    total = 0
    for sg in segs:
        L = math.hypot(sg[2] - sg[0], sg[3] - sg[1])
        k = max(2, min(240, int(L / step) + 1))
        for q in range(k):
            t = q / float(k - 1)
            x = sg[0] + (sg[2] - sg[0]) * t - cx
            y = sg[1] + (sg[3] - sg[1]) * t - cy
            uu = (x * c + y * s_) / a + 0.5
            vv = (-x * s_ + y * c) / b + 0.5
            i = min(n - 1, max(0, int(uu * n)))
            j = min(n - 1, max(0, int(vv * n)))
            cells.add((i, j))
        total += k
        if total > 30000:
            break
    if len(cells) < 4:
        return None
    mask = 0
    for (i, j) in cells:
        mask |= 1 << ((j + 1) * _W + (i + 1))
    return {"d": [int(round(a)), int(round(b))], "n": n, "m": format(mask, "x")}


def _cells_of(mask):
    out = []
    x = mask
    while x:
        low = x & -x
        idx = low.bit_length() - 1
        out.append((idx % _W - 1, idx // _W - 1))
        x ^= low
    return out


def _variants(mhex, square, n=SIG_N):
    key = (mhex, square)
    if key in _VAR_CACHE:
        return _VAR_CACHE[key]
    cells = _cells_of(int(mhex, 16))
    out = []
    fl = [(False, False), (True, False), (False, True), (True, True)]
    for tr in ((False, True) if square else (False,)):
        for fu, fv in fl:
            m = 0
            for (i, j) in cells:
                ii, jj = (j, i) if tr else (i, j)
                if fu:
                    ii = n - 1 - ii
                if fv:
                    jj = n - 1 - jj
                m |= 1 << ((jj + 1) * _W + (ii + 1))
            out.append(m)
    _VAR_CACHE[key] = out
    return out


def _dil(m):
    return m | (m << 1) | (m >> 1) | (m << _W) | (m >> _W) | (m << (_W + 1)) | (m >> (_W + 1)) | \
        (m << (_W - 1)) | (m >> (_W - 1))


def _pop(x):
    return bin(x).count("1")


def similar(A, B):
    """Độ giống 0..1 giữa 2 chữ ký (0 nếu kích thước khác quá nhiều)."""
    if not A or not B or A.get("n") != B.get("n"):
        return 0.0
    a1, b1 = A["d"]
    a2, b2 = B["d"]
    ta = max(35.0, 0.07 * max(a1, a2))
    tb = max(35.0, 0.07 * max(b1, b2))
    square = (max(a1, b1) / float(max(min(a1, b1), 1)) < 1.2 and
              max(a2, b2) / float(max(min(a2, b2), 1)) < 1.2)
    ok = abs(a1 - a2) <= ta and abs(b1 - b2) <= tb
    if not ok and square:
        ok = abs(a1 - b2) <= ta and abs(b1 - a2) <= tb
    if not ok:
        return 0.0
    mb = int(B["m"], 16)
    nb = _pop(mb)
    db = _dil(mb)
    best = 0.0
    for va in _variants(A["m"], square, A["n"]):
        na = _pop(va)
        if not na or not nb:
            continue
        s = (_pop(va & db) / float(na) + _pop(mb & _dil(va)) / float(nb)) / 2.0
        if s > best:
            best = s
    return best
