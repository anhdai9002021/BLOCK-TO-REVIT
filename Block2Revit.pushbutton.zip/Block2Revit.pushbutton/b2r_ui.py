# -*- coding: utf-8 -*-
"""Giao diện dùng chung: theme sáng/tối, font, control tự vẽ, hộp thoại, tìm kiếm thông minh."""
import os
import re
import json
import unicodedata
import clr

clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")
import System
from System.Reflection import BindingFlags
import System.Windows.Forms as WF
from System.Drawing import (Bitmap, Graphics, Pen, Color, Size, Point, Font,
                            ColorTranslator, Rectangle, SolidBrush)
from System.Drawing.Drawing2D import SmoothingMode, GraphicsPath

HERE = os.path.dirname(os.path.abspath(__file__))
SETTINGS_FILE = os.path.join(HERE, "settings.json")
LOG_FILE = os.path.join(HERE, "Block2Revit.log")


def _c(h):
    return ColorTranslator.FromHtml(h)


THEMES = {
    "light": {
        "bg": _c("#F3F5F9"), "panel": _c("#FFFFFF"), "input": _c("#FFFFFF"),
        "text": _c("#1E2733"), "sub": _c("#667085"), "border": _c("#D9DFE8"),
        "accent": _c("#2563EB"), "accent_hover": _c("#1D4FD0"), "accent_soft": _c("#E3ECFE"),
        "btn": _c("#FFFFFF"), "btn_hover": _c("#EEF2F8"),
        "grid_line": _c("#E6EAF0"), "head": _c("#EEF2F7"), "alt": _c("#F8FAFC"),
        "sel": _c("#DCE8FF"), "sel_text": _c("#0F2347"),
        "prev_bg": _c("#FFFFFF"), "prev_fg": _c("#1F4E8C"),
        "tab_on": _c("#2563EB"), "ok": _c("#15803D"), "warn": _c("#B45309"),
        "card": _c("#FFFFFF"), "card_hover": _c("#F1F5FD"), "shadow": _c("#E1E6EE"),
    },
    "dark": {
        "bg": _c("#14171E"), "panel": _c("#1C2029"), "input": _c("#262C39"),
        "text": _c("#EDF1F7"), "sub": _c("#9AA5B8"), "border": _c("#323A4A"),
        "accent": _c("#4C8DFF"), "accent_hover": _c("#6BA0FF"), "accent_soft": _c("#243A63"),
        "btn": _c("#262C39"), "btn_hover": _c("#323A4D"),
        "grid_line": _c("#2B3240"), "head": _c("#232936"), "alt": _c("#1A1E27"),
        "sel": _c("#2B4A80"), "sel_text": _c("#FFFFFF"),
        "prev_bg": _c("#262C39"), "prev_fg": _c("#8FC1FF"),
        "tab_on": _c("#4C8DFF"), "ok": _c("#4ADE9A"), "warn": _c("#F0B04A"),
        "card": _c("#222834"), "card_hover": _c("#2B3344"), "shadow": _c("#10131A"),
    },
}
STATE = {"dark": False}
SET = {}

# ---- font: Segoe UI (chữ rõ, hợp Windows/Revit)
FONT_BODY = "Segoe UI"
FONT_BOLD = "Segoe UI Semibold"
_FONTS = {}


def font(size=9.5, bold=False):
    k = (size, bold)
    f = _FONTS.get(k)
    if f is None:
        f = Font(FONT_BOLD if bold else FONT_BODY, float(size))
        _FONTS[k] = f
    return f


def T():
    return THEMES["dark" if STATE["dark"] else "light"]


def revit_is_dark():
    try:
        from Autodesk.Revit.UI import UIThemeManager, UITheme
        return UIThemeManager.CurrentTheme == UITheme.Dark
    except Exception:
        return False


def load_settings():
    global SET
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            SET = json.load(f)
    except Exception:
        SET = {}
    STATE["dark"] = SET["dark"] if "dark" in SET else revit_is_dark()
    return SET


def save_settings():
    SET["dark"] = STATE["dark"]
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(SET, f, ensure_ascii=False, indent=1)
    except Exception:
        pass


def log(msg):
    try:
        import datetime
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(u"[{}] {}\n".format(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def set_titlebar(form):
    try:
        import ctypes
        val = ctypes.c_int(1 if STATE["dark"] else 0)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(
            ctypes.c_void_p(form.Handle.ToInt64()), 20, ctypes.byref(val), 4)
    except Exception:
        pass


def load_logo(size):
    fn = "icon.dark.png" if STATE["dark"] else "icon.png"
    try:
        return Bitmap(Bitmap(os.path.join(HERE, fn)), Size(size, size))
    except Exception:
        return None



# ------------------------------------------------------------------ tìm kiếm thông minh
def norm(s):
    """Chữ thường, bỏ dấu tiếng Việt: 'Cửa Đi' -> 'cua di'."""
    s = unicodedata.normalize("NFD", u"{}".format(s or u"").replace(u"đ", u"d").replace(u"Đ", u"D"))
    return u"".join(ch for ch in s if unicodedata.category(ch) != "Mn").lower()


def smart_score(query, text):
    """Điểm khớp (0 = không khớp). Mỗi từ trong query phải khớp: bằng hệt > đầu chuỗi >
    đầu từ > nằm trong > các ký tự theo thứ tự. Không phân biệt hoa/thường và dấu."""
    toks = norm(query).split()
    if not toks:
        return 1.0
    t = norm(text)
    words = [w for w in re.split(r"[^a-z0-9]+", t) if w]
    total = 0.0
    for tok in toks:
        if t == tok:
            sc = 100.0
        elif t.startswith(tok):
            sc = 80.0
        elif any(w == tok for w in words):
            sc = 70.0
        elif any(w.startswith(tok) for w in words):
            sc = 60.0
        elif tok in t:
            sc = 40.0
        else:
            i = 0
            for ch in t:
                if i < len(tok) and ch == tok[i]:
                    i += 1
            sc = 15.0 if (i == len(tok) and len(tok) >= 2) else 0.0
        if sc == 0.0:
            return 0.0
        total += sc
    return total - min(len(t), 200) * 0.05


def smart_filter(items, query, key=None):
    """Lọc + xếp hạng items theo query (giữ nguyên thứ tự gốc khi query trống)."""
    if not norm(query).strip():
        return list(items)
    out = []
    for i, it in enumerate(items):
        sc = smart_score(query, key(it) if key else it)
        if sc > 0:
            out.append((-sc, i, it))
    out.sort(key=lambda x: (x[0], x[1]))
    return [x[2] for x in out]


# ------------------------------------------------------------------ style
_DONE = set()


def _once(c, tag):
    k = (tag, c.GetHashCode())
    if k in _DONE:
        return False
    _DONE.add(k)
    return True


def round_path(x, y, w, h, r):
    p = GraphicsPath()
    d = r * 2
    p.AddArc(x, y, d, d, 180, 90)
    p.AddArc(x + w - d, y, d, d, 270, 90)
    p.AddArc(x + w - d, y + h - d, d, d, 0, 90)
    p.AddArc(x, y + h - d, d, d, 90, 90)
    p.CloseFigure()
    return p


def dark_scroll(ctrl):
    """Thanh cuộn tối khi ở chế độ tối (Windows 10+)."""
    try:
        import ctypes
        name = u"DarkMode_Explorer" if STATE["dark"] else u"Explorer"
        ctypes.windll.uxtheme.SetWindowTheme(ctypes.c_void_p(ctrl.Handle.ToInt64()), name, None)
    except Exception:
        pass


def set_placeholder(tb, text):
    try:
        import ctypes
        ctypes.windll.user32.SendMessageW(ctypes.c_void_p(tb.Handle.ToInt64()), 0x1501, 1, text)
    except Exception:
        pass


def _draw_combo_item(s, e):
    try:
        t = T()
        idx = e.Index
        st = int(e.State)
        face = (st & int(WF.DrawItemState.ComboBoxEdit)) != 0
        sel = (st & int(WF.DrawItemState.Selected)) != 0 and not face
        if idx >= 0 and idx < s.Items.Count:
            text = s.GetItemText(s.Items[idx])
        else:
            text = str(s.Text or u"")
        br = SolidBrush(t["sel"] if sel else t["input"])
        e.Graphics.FillRectangle(br, e.Bounds)
        br.Dispose()
        b = e.Bounds
        rc = Rectangle(b.X + 8, b.Y, max(10, b.Width - 12), b.Height)
        WF.TextRenderer.DrawText(
            e.Graphics, text, s.Font, rc, t["sel_text"] if sel else t["text"],
            WF.TextFormatFlags.VerticalCenter | WF.TextFormatFlags.EndEllipsis
            | WF.TextFormatFlags.Left | WF.TextFormatFlags.NoPrefix)
    except Exception:
        pass


def _fit_dropdown(s, e=None):
    try:
        w = s.Width
        for it in s.Items:
            w = max(w, WF.TextRenderer.MeasureText(s.GetItemText(it), s.Font).Width + 36)
        s.DropDownWidth = min(w, 700)
    except Exception:
        pass


def style_combo(c):
    """Combobox tự vẽ: chữ luôn rõ ở cả nền sáng/tối, danh sách xổ ra đúng màu."""
    t = T()
    c.FlatStyle = WF.FlatStyle.Flat
    c.BackColor = t["input"]
    c.ForeColor = t["text"]
    c.DrawMode = WF.DrawMode.OwnerDrawFixed
    c.ItemHeight = 24
    if _once(c, "combo"):
        c.DrawItem += _draw_combo_item
        c.DropDown += _fit_dropdown


def _tab_paint(s, e):
    try:
        if str(s.Tag) == "tab_on":
            br = SolidBrush(T()["accent"])
            e.Graphics.FillRectangle(br, 0, s.Height - 3, s.Width, 3)
            br.Dispose()
    except Exception:
        pass


def style_controls(parent):
    t = T()
    for c in parent.Controls:
        tag = str(c.Tag)
        if isinstance(c, WF.Button):
            c.FlatStyle = WF.FlatStyle.Flat
            c.Cursor = WF.Cursors.Hand
            c.UseVisualStyleBackColor = False
            c.FlatAppearance.BorderSize = 1
            c.Font = font(9.5, tag in ("primary", "tab_on", "tab", "chip_on"))
            if tag == "primary":
                c.BackColor = t["accent"]
                c.ForeColor = Color.White
                c.FlatAppearance.BorderColor = t["accent"]
                c.FlatAppearance.MouseOverBackColor = t["accent_hover"]
                c.FlatAppearance.MouseDownBackColor = t["accent_hover"]
            elif tag in ("tab_on", "tab"):
                c.Font = font(10, True)
                c.BackColor = t["panel"]
                c.ForeColor = t["text"] if tag == "tab_on" else t["sub"]
                c.FlatAppearance.BorderSize = 0
                c.FlatAppearance.BorderColor = t["panel"]
                c.FlatAppearance.MouseOverBackColor = t["btn_hover"]
                c.FlatAppearance.MouseDownBackColor = t["btn_hover"]
                if _once(c, "tabpaint"):
                    c.Paint += _tab_paint
            elif tag == "chip_on":
                c.BackColor = t["accent_soft"]
                c.ForeColor = t["accent"]
                c.FlatAppearance.BorderColor = t["accent"]
                c.FlatAppearance.MouseOverBackColor = t["accent_soft"]
            elif tag == "danger":
                c.BackColor = t["btn"]
                c.ForeColor = t["warn"]
                c.FlatAppearance.BorderColor = t["border"]
                c.FlatAppearance.MouseOverBackColor = t["btn_hover"]
            else:
                c.BackColor = t["btn"]
                c.ForeColor = t["text"]
                c.FlatAppearance.BorderColor = t["border"]
                c.FlatAppearance.MouseOverBackColor = t["btn_hover"]
                c.FlatAppearance.MouseDownBackColor = t["btn_hover"]
        elif isinstance(c, WF.TextBox):
            c.Font = font(9.5)
            c.BackColor = t["input"]
            c.ForeColor = t["text"]
            c.BorderStyle = WF.BorderStyle.FixedSingle
        elif isinstance(c, WF.ComboBox):
            c.Font = font(9.5)
            style_combo(c)
        elif isinstance(c, WF.PictureBox):
            c.BackColor = t["panel"]
        elif isinstance(c, (WF.Label, WF.CheckBox)):
            c.BackColor = Color.Transparent
            c.Font = font(9.5, tag == "h2") if tag != "title" else font(15, True)
            c.ForeColor = t["sub"] if tag == "sub" else (
                t["ok"] if tag == "ok" else (t["warn"] if tag == "warn" else t["text"]))
            if isinstance(c, WF.CheckBox):
                c.FlatStyle = WF.FlatStyle.Standard
        elif isinstance(c, (WF.ListBox,)):
            c.BackColor = t["panel"]
            c.ForeColor = t["text"]
            c.Font = font(9.5)
        elif isinstance(c, WF.Panel):
            if tag == "line":
                c.BackColor = t["border"]
            elif tag in ("header", "bottom", "toolbar", "card"):
                c.BackColor = t["panel"]
            else:
                c.BackColor = t["bg"]
        style_controls(c)


def style_grid(grid):
    t = T()
    grid.Font = font(9.5)
    grid.BackgroundColor = t["bg"]
    grid.GridColor = t["grid_line"]
    grid.BorderStyle = getattr(WF.BorderStyle, "None")
    grid.CellBorderStyle = WF.DataGridViewCellBorderStyle.SingleHorizontal
    grid.EnableHeadersVisualStyles = False
    grid.ColumnHeadersBorderStyle = getattr(WF.DataGridViewHeaderBorderStyle, "None")
    grid.ColumnHeadersHeight = 36
    grid.ColumnHeadersHeightSizeMode = \
        WF.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
    h = grid.ColumnHeadersDefaultCellStyle
    h.BackColor = t["head"]
    h.ForeColor = t["sub"]
    h.SelectionBackColor = t["head"]
    h.SelectionForeColor = t["sub"]
    h.Font = font(9, True)
    h.Padding = WF.Padding(8, 0, 8, 0)
    h.Alignment = WF.DataGridViewContentAlignment.MiddleLeft
    d = grid.DefaultCellStyle
    d.BackColor = t["panel"]
    d.ForeColor = t["text"]
    d.SelectionBackColor = t["sel"]
    d.SelectionForeColor = t["sel_text"]
    d.Padding = WF.Padding(8, 3, 8, 3)
    d.Font = font(9.5)
    d.Alignment = WF.DataGridViewContentAlignment.MiddleLeft
    a = grid.AlternatingRowsDefaultCellStyle
    a.BackColor = t["alt"]
    a.ForeColor = t["text"]
    a.SelectionBackColor = t["sel"]
    a.SelectionForeColor = t["sel_text"]
    if _once(grid, "gridedit"):
        grid.EditingControlShowing += _grid_edit_show
    dark_scroll(grid)


def _grid_edit_show(s, e):
    """Ô nhập / combobox trong bảng: ép màu + tự vẽ để chữ luôn thấy rõ."""
    try:
        t = T()
        c = e.Control
        if isinstance(c, WF.ComboBox):
            c.Font = font(9.5)
            style_combo(c)
            _fit_dropdown(c)
        elif isinstance(c, WF.TextBox):
            c.BackColor = t["input"]
            c.ForeColor = t["text"]
            c.Font = font(9.5)
    except Exception:
        pass


# ------------------------------------------------------------------ control nhanh
def lbl(text, x, y, tag=None):
    c = WF.Label()
    c.Text = text
    c.Location = Point(x, y)
    c.AutoSize = True
    if tag:
        c.Tag = tag
    return c


def txt(x, y, w, text=u""):
    c = WF.TextBox()
    c.Location = Point(x, y)
    c.Width = w
    c.Text = text
    return c


def btn(text, x, y, w, h=30, tag=None, anchor=None):
    c = WF.Button()
    c.Text = text
    c.Location = Point(x, y)
    c.Size = Size(w, h)
    if tag:
        c.Tag = tag
    if anchor is not None:
        c.Anchor = anchor
    return c


def pin_right(parent, ctrl, margin=16):
    """Canh nút sát mép phải của parent (tự cập nhật khi parent đổi kích thước)."""
    ctrl.Anchor = WF.AnchorStyles.Top | WF.AnchorStyles.Left

    def _fix(s=None, e=None):
        try:
            ctrl.Left = max(0, parent.ClientSize.Width - margin - ctrl.Width)
        except Exception:
            pass
    parent.SizeChanged += _fix
    parent.VisibleChanged += _fix
    _fix()
    return _fix


_LAST_W = {}
_REG = {}


def layout_rows(panel, rows, left=16, top=10, row_h=38, gap=14, right=16):
    """Xếp control theo hàng và TỰ XUỐNG DÒNG khi khung hẹp (kéo nhỏ khung vẫn thấy đủ).
    Nhãn luôn đi liền control đứng sau nó."""
    def doit(force=False):
        W = panel.ClientSize.Width
        if W < 120:
            W = 1000
        if (not force) and _LAST_W.get(panel.GetHashCode()) == W:
            return
        _LAST_W[panel.GetHashCode()] = W
        y = top
        for row in (_REG.get(panel.GetHashCode()) or [rows])[0]:
            if not row:
                continue
            units, cur = [], []
            for c in row:
                cur.append(c)
                if not isinstance(c, WF.Label):
                    units.append(cur)
                    cur = []
            if cur:
                units.append(cur)
            x = left
            ly = y
            for u in units:
                w = 0
                for c in u:
                    if isinstance(c, (WF.Label, WF.CheckBox)):
                        c.AutoSize = True
                        w += c.PreferredSize.Width + 6
                    else:
                        w += c.Width + 6
                if x + w > W - right and x > left:
                    x = left
                    ly += row_h
                for c in u:
                    if isinstance(c, (WF.Label, WF.CheckBox)):
                        cw = c.PreferredSize.Width
                    else:
                        cw = c.Width
                    c.Left = x
                    c.Top = ly + max(0, (row_h - 8 - c.Height) // 2) + 2
                    x += cw + 6
                x += gap
            y = ly + row_h
        panel.Height = y + 6
    key = panel.GetHashCode()
    if key in _REG:                  # đã đăng ký: chỉ tính lại, không gắn thêm handler
        _REG[key][0] = rows
        doit(True)
        return doit
    _REG[key] = [rows]
    doit(True)
    panel.SizeChanged += lambda s, e: doit(False)
    panel.VisibleChanged += lambda s, e: doit(True)
    return doit


def layout_bottom(panel, left_ctrl, info_lbl, right_btn, right_margin=20):
    """Thanh dưới: nút trái, dòng trạng thái ở giữa (cắt bớt bằng ... nếu dài), nút chính bên phải."""
    info_lbl.AutoSize = False
    info_lbl.AutoEllipsis = True
    info_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft

    def _fix(s=None, e=None):
        try:
            H = panel.ClientSize.Height
            left_ctrl.Top = (H - left_ctrl.Height) // 2
            right_btn.Top = (H - right_btn.Height) // 2
            right_btn.Left = max(0, panel.ClientSize.Width - right_margin - right_btn.Width)
            info_lbl.Left = left_ctrl.Right + 16
            info_lbl.Height = 24
            info_lbl.Top = (H - info_lbl.Height) // 2
            info_lbl.Width = max(60, right_btn.Left - 16 - info_lbl.Left)
        except Exception:
            pass
    panel.SizeChanged += _fix
    panel.VisibleChanged += _fix
    _fix()
    return _fix


def combo(x, y, w, items=None):
    c = WF.ComboBox()
    c.Location = Point(x, y)
    c.Width = w
    c.DropDownStyle = WF.ComboBoxStyle.DropDownList
    for i in (items or []):
        c.Items.Add(i)
    return c


def chk(text, x, y, checked=False):
    c = WF.CheckBox()
    c.Text = text
    c.Location = Point(x, y)
    c.AutoSize = True
    c.Checked = checked
    return c


def panel(dock, height=None, tag=None):
    p = WF.Panel()
    p.Dock = dock
    if height:
        p.Height = height
    if tag:
        p.Tag = tag
    return p


def num(textbox, default):
    try:
        return float(str(textbox.Text).replace(",", ".").strip())
    except Exception:
        return float(default)


def make_grid():
    g = WF.DataGridView()
    g.Dock = WF.DockStyle.Fill
    g.AllowUserToAddRows = False
    g.AllowUserToDeleteRows = False
    g.AllowUserToResizeRows = False
    g.RowHeadersVisible = False
    g.SelectionMode = WF.DataGridViewSelectionMode.FullRowSelect
    g.MultiSelect = True
    g.EditMode = WF.DataGridViewEditMode.EditOnEnter
    g.RowTemplate.Height = 80
    g.AutoSizeColumnsMode = getattr(WF.DataGridViewAutoSizeColumnsMode, "None")
    g.ShowCellToolTips = True
    try:        # chống nhấp nháy khi cuộn / vẽ lại
        pi = g.GetType().GetProperty("DoubleBuffered",
                                     BindingFlags.NonPublic | BindingFlags.Instance)
        pi.SetValue(g, True, None)
    except Exception:
        pass
    return g


def col_text(name, header, w, readonly=True):
    c = WF.DataGridViewTextBoxColumn()
    c.Name = name
    c.HeaderText = header
    c.Width = w
    c.ReadOnly = readonly
    return c


def col_img(name, header, w):
    c = WF.DataGridViewImageColumn()
    c.Name = name
    c.HeaderText = header
    c.Width = w
    c.ImageLayout = WF.DataGridViewImageCellLayout.Zoom
    return c


def col_combo(name, header, w, items):
    c = WF.DataGridViewComboBoxColumn()
    c.Name = name
    c.HeaderText = header
    c.Width = w
    c.FlatStyle = WF.FlatStyle.Flat
    c.DisplayStyle = WF.DataGridViewComboBoxDisplayStyle.ComboBox
    for i in items:
        c.Items.Add(i)
    return c


def col_check(name, header, w):
    c = WF.DataGridViewCheckBoxColumn()
    c.Name = name
    c.HeaderText = header
    c.Width = w
    return c


# ------------------------------------------------------------------ hình block
def draw_segs(segs, size=72):
    t = T()
    bmp = Bitmap(size, size)
    gr = Graphics.FromImage(bmp)
    gr.Clear(t["prev_bg"])
    gr.SmoothingMode = SmoothingMode.AntiAlias
    if segs:
        minx = min(min(s[0], s[2]) for s in segs)
        maxx = max(max(s[0], s[2]) for s in segs)
        miny = min(min(s[1], s[3]) for s in segs)
        maxy = max(max(s[1], s[3]) for s in segs)
        w = max(maxx - minx, 1e-9)
        h = max(maxy - miny, 1e-9)
        k = (size - 12) / max(w, h)
        ox = (size - w * k) / 2.0
        oy = (size - h * k) / 2.0
        pen = Pen(t["prev_fg"], 1.2)
        for (x0, y0, x1, y1) in segs:
            gr.DrawLine(pen, float(ox + (x0 - minx) * k), float(size - (oy + (y0 - miny) * k)),
                        float(ox + (x1 - minx) * k), float(size - (oy + (y1 - miny) * k)))
        pen.Dispose()
    gr.Dispose()
    return bmp


_fam_img = {}
CTX = {"api": False}      # True khi đang chạy trong API context (ExternalEvent)


def clear_previews():
    """Xoá toàn bộ ảnh xem trước family đã cache (dùng khi Reset family)."""
    _fam_img.clear()


def fam_preview_cached(key, size=72):
    """Chỉ lấy ảnh đã có sẵn - an toàn khi gọi ngoài API context (form modeless)."""
    return _fam_img.get((key, size))


def fam_preview(key, sym, size=72):
    """Ảnh xem trước family. Chỉ tính mới khi gọi trong API context; ngoài ra trả ảnh đã cache."""
    ck = (key, size)
    b = _fam_img.get(ck)
    if b is not None:
        return b
    if sym is None or not CTX["api"]:
        return None
    try:
        b = sym.GetPreviewImage(Size(size, size))
    except Exception:
        b = None
    if b is not None:
        _fam_img[ck] = b
    return b


def prefetch_previews(items, size=72, budget_s=6.0):
    """items: [(key, symbol)] - tạo trước ảnh xem trước trong thời gian giới hạn."""
    import time
    t0 = time.time()
    n = 0
    old = CTX["api"]
    CTX["api"] = True            # gọi trong API context của lệnh (trước khi hiện form)
    try:
        for key, sym in items:
            if time.time() - t0 > budget_s:
                break
            if (key, size) not in _fam_img:
                fam_preview(key, sym, size)
                n += 1
    finally:
        CTX["api"] = old
    return n


# ------------------------------------------------------------------ hộp thoại
def work_area():
    try:
        wa = WF.Screen.PrimaryScreen.WorkingArea
        return wa.Width, wa.Height
    except Exception:
        return 1366, 768


def new_dialog(title, w, h, resizable=False):
    """Form hộp thoại đã gắn theme."""
    f = WF.Form()
    f.Text = title
    f.Font = font(9.5)
    f.Size = Size(w, h)
    f.StartPosition = WF.FormStartPosition.CenterScreen
    f.TopMost = True
    f.ShowIcon = False
    f.ShowInTaskbar = False
    f.MinimizeBox = False
    f.MaximizeBox = bool(resizable)
    f.FormBorderStyle = WF.FormBorderStyle.Sizable if resizable else WF.FormBorderStyle.FixedDialog
    f.BackColor = T()["bg"]
    f.Shown += lambda s, e: set_titlebar(f)
    return f


def alert(msg, title=u"Block → Revit", sub=None, yes_no=False):
    """Hộp thoại thông báo theo theme (thay MessageBox). yes_no -> trả True/False."""
    t = T()
    sw, sh = work_area()
    W = 560
    f = new_dialog(title, W, 220)
    head = panel(WF.DockStyle.Top, 4, "line")
    mark = WF.Label()
    mark.Text = u"?" if yes_no else u"i"
    mark.Font = font(16, True)
    mark.ForeColor = Color.White
    mark.BackColor = t["accent"] if yes_no else t["ok"]
    mark.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    mark.SetBounds(20, 22, 40, 40)
    body = WF.Label()
    body.Font = font(10.5)
    body.ForeColor = t["text"]
    body.BackColor = Color.Transparent
    body.Text = msg
    body.AutoSize = False
    tw = W - 100
    mh = WF.TextRenderer.MeasureText(msg, body.Font, Size(tw, 2000),
                                     WF.TextFormatFlags.WordBreak).Height
    body.SetBounds(76, 22, tw, max(40, mh + 6))
    y = 22 + max(40, mh + 6) + 10
    box = None
    if sub:
        box = WF.TextBox()
        box.Multiline = True
        box.ReadOnly = True
        box.ScrollBars = WF.ScrollBars.Vertical
        box.Font = font(9)
        box.BackColor = t["input"]
        box.ForeColor = t["text"]
        box.BorderStyle = WF.BorderStyle.FixedSingle
        box.Text = sub.replace(u"\r\n", u"\n").replace(u"\n", u"\r\n")
        sh_ = min(240, max(60, 20 * (sub.count(u"\n") + 2)))
        box.SetBounds(20, y, W - 56, sh_)
        y += sh_ + 12
    bt = 44
    f.ClientSize = Size(W - 16, y + bt + 14)
    ok = btn(u"Có" if yes_no else u"Đóng", 0, y, 96, 32, "primary")
    ok.DialogResult = WF.DialogResult.Yes if yes_no else WF.DialogResult.OK
    f.Controls.Add(head)
    for c in (mark, body):
        f.Controls.Add(c)
    if box is not None:
        f.Controls.Add(box)
    f.Controls.Add(ok)
    f.AcceptButton = ok
    if yes_no:
        no = btn(u"Không", 0, y, 96, 32)
        no.DialogResult = WF.DialogResult.No
        f.Controls.Add(no)
        f.CancelButton = no
        no.Left = f.ClientSize.Width - 20 - no.Width
        ok.Left = no.Left - 10 - ok.Width
    else:
        ok.Left = f.ClientSize.Width - 20 - ok.Width
        f.CancelButton = ok
    style_controls(f)
    res = f.ShowDialog()
    f.Dispose()
    if yes_no:
        return res == WF.DialogResult.Yes
    return True


def select_list(items, title=u"", multi=False, preselect=None, w=620, h=680):
    """Hộp thoại chọn trong danh sách CÓ TÌM KIẾM THÔNG MINH (gõ vài chữ là lọc, không dấu cũng được).
    multi=True -> list; multi=False -> 1 chuỗi; Hủy -> None."""
    items = list(items)
    checked = set(preselect or [])
    sw, sh = work_area()
    f = new_dialog(title, min(w, sw - 60), min(h, sh - 80), True)
    f.MinimumSize = Size(420, 360)
    t = T()
    top = panel(WF.DockStyle.Top, 52, "toolbar")
    tb = txt(16, 12, 300)
    tb.Anchor = WF.AnchorStyles.Top | WF.AnchorStyles.Left | WF.AnchorStyles.Right
    lb_n = lbl(u"", 0, 17, "sub")
    top.Controls.Add(tb)
    top.Controls.Add(lb_n)

    def _tb_w(s=None, e=None):
        tb.Width = max(120, top.ClientSize.Width - 32 - 110)
        lb_n.Left = tb.Right + 10
    top.SizeChanged += _tb_w
    lb = WF.CheckedListBox() if multi else WF.ListBox()
    lb.Dock = WF.DockStyle.Fill
    lb.BorderStyle = getattr(WF.BorderStyle, "None")
    lb.Font = font(10)
    if multi:
        lb.CheckOnClick = True
    else:
        lb.DrawMode = WF.DrawMode.OwnerDrawFixed
        lb.ItemHeight = 28

        def _di(s, e):
            try:
                if e.Index < 0:
                    return
                sel = (int(e.State) & int(WF.DrawItemState.Selected)) != 0
                br = SolidBrush(t["sel"] if sel else t["panel"])
                e.Graphics.FillRectangle(br, e.Bounds)
                br.Dispose()
                b = e.Bounds
                WF.TextRenderer.DrawText(
                    e.Graphics, str(s.Items[e.Index]), s.Font,
                    Rectangle(b.X + 10, b.Y, b.Width - 14, b.Height),
                    t["sel_text"] if sel else t["text"],
                    WF.TextFormatFlags.VerticalCenter | WF.TextFormatFlags.EndEllipsis
                    | WF.TextFormatFlags.NoPrefix)
            except Exception:
                pass
        lb.DrawItem += _di
    busy = {"v": False}
    shown = []

    def refill(s=None, e=None):
        busy["v"] = True
        try:
            lb.BeginUpdate()
            lb.Items.Clear()
            shown[:] = smart_filter(items, tb.Text)
            for i, it in enumerate(shown):
                lb.Items.Add(it)
                if multi and it in checked:
                    lb.SetItemChecked(i, True)
            if (not multi) and lb.Items.Count > 0:
                lb.SelectedIndex = 0
            lb.EndUpdate()
        finally:
            busy["v"] = False
        lb_n.Text = u"{} / {} mục".format(len(shown), len(items))
        if multi:
            lb_n.Text += u"  ·  đã chọn {}".format(len(checked))
    tb.TextChanged += refill
    if multi:
        def _chk(s, e):
            if busy["v"]:
                return
            it = shown[e.Index]
            if e.NewValue == WF.CheckState.Checked:
                checked.add(it)
            else:
                checked.discard(it)
            lb_n.Text = u"{} / {} mục  ·  đã chọn {}".format(len(shown), len(items), len(checked))
        lb.ItemCheck += _chk

    def _key(s, e):
        if (not multi) and e.KeyCode in (WF.Keys.Down, WF.Keys.Up):
            n = lb.Items.Count
            if n:
                i = lb.SelectedIndex + (1 if e.KeyCode == WF.Keys.Down else -1)
                lb.SelectedIndex = max(0, min(n - 1, i))
            e.Handled = True
    tb.KeyDown += _key
    bottom = panel(WF.DockStyle.Bottom, 60, "bottom")
    ok = btn(u"Chọn", 0, 14, 104, 34, "primary")
    ok.DialogResult = WF.DialogResult.OK
    cancel = btn(u"Hủy", 0, 14, 104, 34)
    cancel.DialogResult = WF.DialogResult.Cancel
    bottom.Controls.Add(ok)
    bottom.Controls.Add(cancel)
    pin_right(bottom, cancel, 16)
    pin_right(bottom, ok, 130)
    if multi:
        def _all(v):
            for it in shown:
                (checked.add if v else checked.discard)(it)
            refill()
        b_all = btn(u"Chọn hết (đang lọc)", 16, 14, 150, 34)
        b_none = btn(u"Bỏ hết", 172, 14, 90, 34)
        b_all.Click += lambda s, e: _all(True)
        b_none.Click += lambda s, e: _all(False)
        bottom.Controls.Add(b_all)
        bottom.Controls.Add(b_none)
    else:
        def _dbl(s, e):
            if lb.SelectedItem is not None:
                f.DialogResult = WF.DialogResult.OK
                f.Close()
        lb.DoubleClick += _dbl
    f.Controls.Add(lb)
    f.Controls.Add(top)
    f.Controls.Add(bottom)
    f.AcceptButton = ok
    f.CancelButton = cancel
    lb.BackColor = t["panel"]
    lb.ForeColor = t["text"]
    style_controls(f)
    set_placeholder(tb, u"Gõ để tìm (không cần dấu)…")
    refill()
    _tb_w()
    f.Shown += lambda s, e: (tb.Focus(), set_placeholder(tb, u"Gõ để tìm (không cần dấu)…"))
    res = f.ShowDialog()
    out = None
    if res == WF.DialogResult.OK:
        if multi:
            out = [it for it in items if it in checked]
        elif lb.SelectedItem is not None:
            out = str(lb.SelectedItem)
    f.Dispose()
    return out
