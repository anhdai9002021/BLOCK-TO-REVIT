# -*- coding: utf-8 -*-
"""Tạo đối tượng trong Revit: family theo level, cửa đi/cửa sổ (tự tạo type theo
chiều dài block), thang, sàn theo Room."""
import os
import math
import b2r_treads as TR
from System.Collections.Generic import List
from Autodesk.Revit.DB import (
    FilteredElementCollector, FamilySymbol, Level, Wall,
    Transaction, Line, XYZ, ElementTransformUtils, FamilyPlacementType,
    BuiltInParameter, StorageType, FloorType, Floor, CurveLoop, BuiltInCategory,
    SpatialElementBoundaryOptions, SpatialElementBoundaryLocation,
    SubTransaction, Curve, Arc, Solid, GeometryInstance, Options, ViewDetailLevel,
    OverrideGraphicSettings, Color as RColor
)
from Autodesk.Revit.DB.Structure import StructuralType
import Autodesk.Revit.DB as _DB
try:
    import Autodesk.Revit.DB.Architecture as _ARCH
except Exception:
    _ARCH = None


def _pick(name):
    """Tìm class API thang ở cả Autodesk.Revit.DB.Architecture lẫn Autodesk.Revit.DB
    (vị trí khác nhau giữa các phiên bản Revit/pythonnet)."""
    for m in (_ARCH, _DB):
        if m is None:
            continue
        try:
            v = getattr(m, name)
            if v is not None:
                return v
        except Exception:
            pass
    return None


StairsType = _pick("StairsType")
StairsRun = _pick("StairsRun")
StairsRunJustification = _pick("StairsRunJustification")
StairsEditScope = _pick("StairsEditScope")
StairsLanding = _pick("StairsLanding")
STAIRS_MISSING = [n for n, v in (("StairsType", StairsType), ("StairsRun", StairsRun),
                                 ("StairsRunJustification", StairsRunJustification),
                                 ("StairsEditScope", StairsEditScope)) if v is None]
HAS_STAIRS = not STAIRS_MISSING
_PRE = {}


def get_stair_pre():
    """Đối tượng IFailuresPreprocessor để StairsEditScope.Commit (bắt buộc khác null).
    Thử 2 cách: (1) lớp Python implement interface, (2) tự sinh lớp .NET bằng Reflection.Emit.
    Trả (obj, lỗi)."""
    if "obj" in _PRE:
        return _PRE["obj"], _PRE["err"]
    obj, errs = None, []
    try:
        from Autodesk.Revit.DB import IFailuresPreprocessor, FailureProcessingResult

        class _StairPre(IFailuresPreprocessor):
            __namespace__ = "Block2RevitStair%d" % int(__import__("time").time() * 1000)

            def PreprocessFailures(self, failuresAccessor):
                try:
                    failuresAccessor.DeleteAllWarnings()
                except Exception:
                    pass
                return FailureProcessingResult.Continue
        obj = _StairPre()
    except Exception as ex:
        errs.append(u"python-interface: {}".format(ex))
        obj = None
    if obj is None:
        try:
            import clr
            import System
            from System.Reflection import AssemblyName, MethodAttributes, TypeAttributes
            from System.Reflection.Emit import AssemblyBuilder, AssemblyBuilderAccess, OpCodes
            from Autodesk.Revit.DB import IFailuresPreprocessor, FailureProcessingResult, FailuresAccessor
            t_if = clr.GetClrType(IFailuresPreprocessor)
            asm = AssemblyBuilder.DefineDynamicAssembly(AssemblyName("B2RDyn"),
                                                        AssemblyBuilderAccess.Run)
            mod = asm.DefineDynamicModule("B2RDyn")
            tb = mod.DefineType("B2RPre", TypeAttributes.Public, clr.GetClrType(System.Object),
                                System.Array[System.Type]([t_if]))
            mb = tb.DefineMethod(
                "PreprocessFailures",
                MethodAttributes.Public | MethodAttributes.Virtual | MethodAttributes.HideBySig
                | MethodAttributes.NewSlot | MethodAttributes.Final,
                clr.GetClrType(FailureProcessingResult),
                System.Array[System.Type]([clr.GetClrType(FailuresAccessor)]))
            il = mb.GetILGenerator()
            il.Emit(OpCodes.Ldc_I4_0)      # FailureProcessingResult.Continue
            il.Emit(OpCodes.Ret)
            tb.DefineMethodOverride(mb, t_if.GetMethod("PreprocessFailures"))
            obj = System.Activator.CreateInstance(tb.CreateType())
        except Exception as ex:
            errs.append(u"reflection-emit: {}".format(ex))
            obj = None
    _PRE["obj"] = obj
    _PRE["err"] = u"; ".join(errs)
    return obj, _PRE["err"]


import b2r_cad as CAD
import b2r_geom as G

MM = 304.8


def name_of(el):
    return CAD.name_of(el)


def _bip(name):
    return getattr(BuiltInParameter, name, None)


# ------------------------------------------------------------------ liệt kê
def get_levels(doc):
    return sorted(FilteredElementCollector(doc).OfClass(Level),
                  key=lambda l: l.Elevation)


def active_level(doc):
    try:
        lv = doc.ActiveView.GenLevel
        if lv is not None:
            return lv
    except Exception:
        pass
    return get_levels(doc)[0]


def is_struct_column(sym):
    """Family thuộc category Structural Columns (so theo Id, theo BuiltInCategory, rồi theo tên
    category - tiếng Anh/Việt) - không phụ thuộc kiểu đặt của family."""
    try:
        cat = sym.Category
    except Exception:
        return False
    if cat is None:
        return False
    try:
        if CAD.eid_int(cat.Id) == int(BuiltInCategory.OST_StructuralColumns):
            return True
    except Exception:
        pass
    try:
        if str(cat.BuiltInCategory) == "OST_StructuralColumns":
            return True
    except Exception:
        pass
    try:
        nm = (cat.Name or u"").lower()
        return (u"structural column" in nm) or (u"cột kết cấu" in nm) or (u"cot ket cau" in nm)
    except Exception:
        return False


def _kind_of(sym):
    if is_struct_column(sym):
        return None              # cột kết cấu: tool không đặt
    try:
        pt = sym.Family.FamilyPlacementType
    except Exception:
        return None
    if pt == FamilyPlacementType.OneLevelBased:
        return "level"
    if pt == FamilyPlacementType.OneLevelBasedHosted:
        try:
            bic = str(sym.Category.BuiltInCategory)
        except Exception:
            bic = u""
        if bic == "OST_Doors":
            return "door"
        if bic == "OST_Windows":
            return "window"
        return "wall"            # gắn tường kiểu khác (TV treo tường, đèn tường, tranh...)
    if pt == FamilyPlacementType.WorkPlaneBased:
        return "wall"            # face-based: gắn lên mặt tường
    return None


def get_symbols(doc):
    """{ 'Family : Type': (symbol, kind) } kind = level | door | window | wall"""
    d = {}
    for s in FilteredElementCollector(doc).OfClass(FamilySymbol):
        k = _kind_of(s)
        if k:
            d[u"{} : {}".format(s.FamilyName, name_of(s))] = (s, k)
    return d


def skipped_diag(doc):
    """Chẩn đoán: {kiểu đặt: số type} của các family tool KHÔNG liệt kê (để biết vì sao không thấy)."""
    cnt = {}
    for s in FilteredElementCollector(doc).OfClass(FamilySymbol):
        if _kind_of(s):
            continue
        try:
            pt = str(s.Family.FamilyPlacementType)
        except Exception:
            pt = u"?"
        cnt[pt] = cnt.get(pt, 0) + 1
    return cnt


def get_stair_types(doc):
    d = {}
    if not HAS_STAIRS:
        return d
    for s in FilteredElementCollector(doc).OfClass(StairsType):
        d[name_of(s)] = s
    return d


# ------------------------------------------------------------------ tham số
def _find_param(el, bips, names):
    for b in bips:
        if b is None:
            continue
        try:
            p = el.get_Parameter(b)
            if p is not None and (not p.IsReadOnly) and p.StorageType == StorageType.Double:
                return p
        except Exception:
            pass
    for n in names:
        try:
            p = el.LookupParameter(n)
            if p is not None and (not p.IsReadOnly) and p.StorageType == StorageType.Double:
                return p
        except Exception:
            pass
    return None


_W = ([_bip("DOOR_WIDTH"), _bip("WINDOW_WIDTH"), _bip("FAMILY_WIDTH_PARAM")],
      [u"Width", u"Rộng", u"Chiều rộng", u"Rong"])
_H = ([_bip("DOOR_HEIGHT"), _bip("WINDOW_HEIGHT"), _bip("FAMILY_HEIGHT_PARAM")],
      [u"Height", u"Cao", u"Chiều cao"])


def _set_len(el, spec, mm):
    p = _find_param(el, spec[0], spec[1])
    if p is None:
        return False
    try:
        p.Set(mm / MM)
        return True
    except Exception:
        return False


def _get_len(el, spec):
    p = None
    for b in spec[0]:
        if b is None:
            continue
        try:
            p = el.get_Parameter(b)
            if p is not None:
                break
        except Exception:
            p = None
    if p is None:
        for n in spec[1]:
            try:
                p = el.LookupParameter(n)
                if p is not None:
                    break
            except Exception:
                p = None
    try:
        return p.AsDouble() * MM if p is not None else None
    except Exception:
        return None


def _activate(doc, sym):
    try:
        if not sym.IsActive:
            sym.Activate()
            doc.Regenerate()
    except Exception:
        pass


def get_or_make_type(doc, base, w_mm, h_mm, cache, log):
    """Type mới của cùng family với rộng x cao đã cho (dùng lại nếu đã có)."""
    ck = (CAD.eid_int(base.Id), int(w_mm), int(h_mm))
    if ck in cache:
        return cache[ck]
    cw = _get_len(base, _W)
    ch = _get_len(base, _H)
    if cw is not None and ch is not None and abs(cw - w_mm) < 0.5 and abs(ch - h_mm) < 0.5:
        cache[ck] = base
        return base
    nm = u"{}_{}x{}".format(name_of(base), int(w_mm), int(h_mm))
    sym = None
    try:
        for sid in base.Family.GetFamilySymbolIds():
            s = doc.GetElement(sid)
            if name_of(s) == nm:
                sym = s
                break
    except Exception:
        sym = None
    if sym is None:
        sym = doc.GetElement(base.Duplicate(nm).Id)
        okw = _set_len(sym, _W, w_mm)
        okh = _set_len(sym, _H, h_mm)
        if not okw:
            log(u"Không tìm thấy parameter Rộng/Width (type) của {}".format(name_of(base)))
        if not okh:
            log(u"Không tìm thấy parameter Cao/Height (type) của {}".format(name_of(base)))
    _activate(doc, sym)
    cache[ck] = sym
    return sym


# ------------------------------------------------------------------ đặt family theo level
def _bbox_xy(inst):
    """(cx, cy, dx, dy) mm của hộp bao (mặt bằng) của instance, hoặc None."""
    try:
        bb = inst.get_BoundingBox(None)
    except Exception:
        bb = None
    if bb is None:
        return None
    return ((bb.Max.X + bb.Min.X) / 2.0 * MM, (bb.Max.Y + bb.Min.Y) / 2.0 * MM,
            (bb.Max.X - bb.Min.X) * MM, (bb.Max.Y - bb.Min.Y) * MM)


def _plan_points(inst, limit=140):
    """Lấy mẫu điểm (x,y mm) trên cạnh hình học 3D của instance (hình chiếu mặt bằng)."""
    pts = []
    opts = Options()
    opts.DetailLevel = ViewDetailLevel.Fine
    try:
        opts.ComputeReferences = False
    except Exception:
        pass

    def add_curve(c):
        try:
            L = c.Length * MM
            n = max(2, min(12, int(L / 150.0) + 1))
            for i in range(n):
                p = c.Evaluate(i / float(n - 1), True)
                pts.append((p.X * MM, p.Y * MM))
        except Exception:
            pass

    def walk(ge):
        for g in ge:
            if isinstance(g, GeometryInstance):
                walk(g.GetInstanceGeometry())
            elif isinstance(g, Solid):
                try:
                    if g.Edges.Size == 0:
                        continue
                    for e in g.Edges:
                        add_curve(e.AsCurve())
                except Exception:
                    pass
            elif isinstance(g, Curve):
                add_curve(g)
    try:
        walk(inst.get_Geometry(opts))
    except Exception:
        return []
    if len(pts) > limit:
        step = len(pts) / float(limit)
        pts = [pts[int(i * step)] for i in range(limit)]
    return pts


def _cad_points(segs, limit=140):
    pts = []
    for (x0, y0, x1, y1) in segs:
        L = math.hypot(x1 - x0, y1 - y0)
        n = max(2, min(12, int(L / 150.0) + 1))
        for i in range(n):
            t = i / float(n - 1)
            pts.append((x0 + (x1 - x0) * t, y0 + (y1 - y0) * t))
    if len(pts) > limit:
        step = len(pts) / float(limit)
        pts = [pts[int(i * step)] for i in range(limit)]
    return pts


def _chamfer(P, Q):
    def one(A, B):
        s_ = 0.0
        for (ax, ay) in A:
            m = 1e30
            for (bx, by) in B:
                d = (ax - bx) * (ax - bx) + (ay - by) * (ay - by)
                if d < m:
                    m = d
            s_ += math.sqrt(m)
        return s_ / len(A)
    return one(P, Q) + one(Q, P)


def _best_orient(fam_pts, cad_pts, origin, face, ang, allow_mirror, rot_off=0.0,
                 ks=(0, 1, 2, 3)):
    """Chọn (mirror, k) với k*90° sao cho hình family khớp nhất với hình block CAD.
    fam_pts: điểm family ở tư thế gốc (chưa xoay/chưa lật). Trả (mirror, k, điểm, điểm_gốc)."""
    ox, oy = origin
    fx, fy = face
    fl = math.hypot(fx, fy) or 1.0
    fx, fy = fx / fl, fy / fl
    rel = [(x - ox, y - oy) for (x, y) in fam_pts]
    cxs = [p[0] for p in cad_pts]
    cys = [p[1] for p in cad_pts]
    ccx, ccy = (min(cxs) + max(cxs)) / 2.0 - ox, (min(cys) + max(cys)) / 2.0 - oy
    best = None
    base_score = None
    for mir in ((False, True) if allow_mirror else (False,)):
        P0 = rel
        if mir:
            P0 = [(2.0 * (x * fx + y * fy) * fx - x, 2.0 * (x * fx + y * fy) * fy - y)
                  for (x, y) in rel]
        for k in ks:
            phi = ang + rot_off + k * math.pi / 2.0
            c, s_ = math.cos(phi), math.sin(phi)
            P = [(x * c - y * s_, x * s_ + y * c) for (x, y) in P0]
            px = [p[0] for p in P]
            py = [p[1] for p in P]
            dx = ccx - (min(px) + max(px)) / 2.0
            dy = ccy - (min(py) + max(py)) / 2.0
            Pm = [(x + dx + ox, y + dy + oy) for (x, y) in P]
            sc_ = _chamfer(cad_pts, Pm)
            if not mir and base_score is None:
                base_score = sc_
            pen = 1.0 + (0.06 if k else 0.0) + (0.10 if mir else 0.0)
            key = sc_ * pen
            if best is None or key < best[0]:
                best = (key, mir, k, sc_)
    return best[1], best[2], best[3], base_score


ORIENT_WARN = []        # cảnh báo hướng đặt nội thất (script.py đọc sau khi đặt xong rồi xoá)


def _orient_table(fam_pts, cad_pts, origin, face, ang, allow_mirror):
    """{(lật?, k): điểm khớp hình} (nhỏ = khớp hơn) cho 4 hướng k*90° x có/không lật tay quanh trục mặt trước.
    fam_pts: điểm family ở tư thế gốc (chưa xoay/chưa lật) tại `origin`; ang: góc xoay cơ sở (rad)."""
    ox, oy = origin
    fx, fy = face
    fl = math.hypot(fx, fy) or 1.0
    fx, fy = fx / fl, fy / fl
    rel = [(x - ox, y - oy) for (x, y) in fam_pts]
    cxs = [q[0] for q in cad_pts]
    cys = [q[1] for q in cad_pts]
    ccx, ccy = (min(cxs) + max(cxs)) / 2.0 - ox, (min(cys) + max(cys)) / 2.0 - oy
    out = {}
    for mir in ((False, True) if allow_mirror else (False,)):
        P0 = rel
        if mir:
            P0 = [(2.0 * (x * fx + y * fy) * fx - x, 2.0 * (x * fx + y * fy) * fy - y)
                  for (x, y) in rel]
        for k in (0, 1, 2, 3):
            phi = ang + k * math.pi / 2.0
            c, s_ = math.cos(phi), math.sin(phi)
            P = [(x * c - y * s_, x * s_ + y * c) for (x, y) in P0]
            px = [q[0] for q in P]
            py = [q[1] for q in P]
            dx = ccx - (min(px) + max(px)) / 2.0
            dy = ccy - (min(py) + max(py)) / 2.0
            Pm = [(x + dx + ox, y + dy + oy) for (x, y) in P]
            out[(mir, k)] = _chamfer(cad_pts, Pm)
    return out


# ------------------------------------------------------------------ kéo kích thước theo block
# Family nội thất / treo tường có tham số kích thước (INSTANCE hoặc TYPE, tên gì cũng được) thì kéo
# bằng đúng hình block. Không dựa vào tên: mọi parameter kiểu Length ghi được đều được ĐO THỬ
# (đổi +100 mm rồi xem KÍCH THƯỚC hình học 3D của instance đổi bao nhiêu theo từng trục family);
# parameter nào làm đổi kích thước thì dùng, parameter chỉ làm dời vị trí (offset/elevation) tự bị loại.
#  - instance parameter: chỉnh thẳng trên instance
#  - type parameter: nhân đôi type thành "<Type>_B2R_<kích thước>" (dùng lại nếu đã có) rồi gán cho instance
import re as _re

_DIM_TOK = set([u"width", u"length", u"depth", u"breadth", u"diameter", u"dia", u"rộng", u"rong",
                u"dài", u"dai", u"sâu", u"sau", u"ngang", u"dọc", u"doc", u"đường", u"kính",
                u"w", u"l", u"d", u"b", u"len", u"wid", u"dk", u"size", u"kích", u"thước"])
_SKIP_TOK = set([u"offset", u"elevation", u"elev", u"sill", u"head", u"độ", u"angle", u"góc",
                 u"goc", u"slope", u"rotation", u"xoay"])
_H_TOK = set([u"height", u"cao", u"h", u"chiều", u"ht"])
_AXES = (("x", 0), ("y", 1), ("z", 2))


def _tokens(name):
    return [t for t in _re.split(r"[\W_]+", (name or u"").lower(), flags=_re.UNICODE) if t]


def _is_length_param(p):
    try:
        from Autodesk.Revit.DB import SpecTypeId
        return bool(p.Definition.GetDataType().Equals(SpecTypeId.Length))
    except Exception:
        pass
    try:
        from Autodesk.Revit.DB import ParameterType
        return p.Definition.ParameterType == ParameterType.Length
    except Exception:
        return False


def _writable_length(plist, skip_names=()):
    out = []
    for p in plist:
        try:
            nm = p.Definition.Name
            if nm in skip_names or p.IsReadOnly or p.StorageType != StorageType.Double:
                continue
            if not _is_length_param(p):
                continue
            if any(t in _SKIP_TOK for t in _tokens(nm)):
                continue
            out.append((nm, p))
        except Exception:
            pass
    return out


def _inst_length_params(inst, sym):
    """Instance parameter kiểu chiều dài, ghi được (loại các parameter thuộc TYPE)."""
    try:
        type_names = set(p.Definition.Name for p in sym.Parameters)
    except Exception:
        type_names = set()
    try:
        plist = list(inst.Parameters)
    except Exception:
        plist = []
    return _writable_length(plist, type_names)


def _type_length_params(sym):
    try:
        plist = list(sym.Parameters)
    except Exception:
        plist = []
    return _writable_length(plist)


def _local_extent(inst):
    """(dx, dy, dz) mm: kích thước hình học 3D (chỉ Solid) của instance trong hệ toạ độ CỦA FAMILY
    - không phụ thuộc instance đang xoay/lật/gắn tường theo hướng nào. None nếu không đọc được."""
    try:
        inv = inst.GetTransform().Inverse
    except Exception:
        inv = None
    opts = Options()
    opts.DetailLevel = ViewDetailLevel.Fine
    try:
        opts.ComputeReferences = False
    except Exception:
        pass
    lo = [1e18, 1e18, 1e18]
    hi = [-1e18, -1e18, -1e18]
    cnt = [0]

    def add(p):
        if inv is not None:
            p = inv.OfPoint(p)
        v = (p.X, p.Y, p.Z)
        for i in range(3):
            if v[i] < lo[i]:
                lo[i] = v[i]
            if v[i] > hi[i]:
                hi[i] = v[i]
        cnt[0] += 1

    def add_curve(c):
        try:
            if isinstance(c, Line):
                add(c.GetEndPoint(0))
                add(c.GetEndPoint(1))
            else:
                for p in c.Tessellate():
                    add(p)
        except Exception:
            pass

    def walk(ge):
        for g in ge:
            if isinstance(g, GeometryInstance):
                walk(g.GetInstanceGeometry())
            elif isinstance(g, Solid):
                try:
                    if g.Edges.Size == 0:
                        continue
                    for e in g.Edges:
                        add_curve(e.AsCurve())
                except Exception:
                    pass
    try:
        walk(inst.get_Geometry(opts))
    except Exception:
        return None
    if cnt[0] == 0:
        return None
    return tuple((hi[i] - lo[i]) * MM for i in range(3))


def _size3(inst):
    e = _local_extent(inst)
    if e is not None:
        return e
    b = _bbox_xy(inst)
    return (b[2], b[3], None) if b is not None else None


def _ctl_param(inst, scope, nm):
    try:
        if scope == "type":
            return inst.Symbol.LookupParameter(nm)
        return inst.LookupParameter(nm)
    except Exception:
        return None


def _probe_controls(doc, inst, sym, cache):
    """{'x': (scope, tên, hệ số), 'y': ..., 'z': ..., 'xy': ...}: parameter nào điều khiển kích thước
    theo trục nào của family (hệ số = mm kích thước đổi khi parameter đổi 1 mm). {} nếu không có.
    Phải gọi khi instance đang mang đúng type `sym`. Kết quả nhớ theo từng family type."""
    key = ("dimc", CAD.eid_int(sym.Id))
    if key in cache:
        return cache[key]
    cache[key] = {}
    cands = [("inst", nm) for nm, _p in _inst_length_params(inst, sym)]
    cands += [("type", nm) for nm, _p in _type_length_params(sym)]
    cands = cands[:48]
    if not cands:
        return cache[key]
    doc.Regenerate()
    s0 = _size3(inst)
    if s0 is None:
        return cache[key]
    rows = []
    for scope, nm in cands:
        p = _ctl_param(inst, scope, nm)
        if p is None:
            continue
        try:
            orig = p.AsDouble()
        except Exception:
            continue
        g = [0.0, 0.0, 0.0]
        try:
            p.Set(orig + 100.0 / MM)
            doc.Regenerate()
            s1 = _size3(inst)
            if s1 is not None:
                for i in range(3):
                    if s0[i] is not None and s1[i] is not None:
                        g[i] = (s1[i] - s0[i]) / 100.0
        except Exception:
            pass
        try:
            p.Set(orig)
            doc.Regenerate()
        except Exception:
            pass
        if max(abs(v) for v in g) >= 0.2:
            rows.append((scope, nm, g))

    def tok_ok(nm, axis):
        return any(t in (_H_TOK if axis == "z" else _DIM_TOK) for t in _tokens(nm))

    res = {}
    used = set()
    for axis, i in _AXES:
        best = None
        for scope, nm, g in rows:
            if nm in used or abs(g[i]) < 0.2:
                continue
            if max(abs(g[j]) for j in range(3) if j != i) > 0.5 * abs(g[i]):
                continue                      # ảnh hưởng nhiều trục: để dành cho 'xy'
            score = abs(abs(g[i]) - 1.0) * 2.0 + (0.0 if tok_ok(nm, axis) else 0.5) + \
                (0.1 if scope == "type" else 0.0)
            if best is None or score < best[0]:
                best = (score, scope, nm, g[i])
        if best is not None:
            res[axis] = (best[1], best[2], best[3])
            used.add(best[2])
    if "x" not in res and "y" not in res:
        best = None
        for scope, nm, g in rows:
            if nm in used:
                continue
            gx, gy = abs(g[0]), abs(g[1])
            if gx >= 0.2 and gy >= 0.2 and min(gx, gy) >= 0.6 * max(gx, gy) and abs(g[2]) < 0.5 * max(gx, gy):
                sc_ = abs((gx + gy) / 2.0 - 1.0)
                if best is None or sc_ < best[0]:
                    best = (sc_, scope, nm, (gx + gy) / 2.0)
        if best is not None:
            res["xy"] = (best[1], best[2], best[3])
    cache[key] = res
    return res


def _apply_targets(doc, inst, dmap, targets):
    """Đặt KÍCH THƯỚC hình học (hệ toạ độ family) về targets {'x','y','z'} (mm; None = giữ).
    Đo lại và chỉnh tối đa 3 lượt cho sát."""
    for _pass in range(3):
        doc.Regenerate()
        cur = _size3(inst)
        if cur is None:
            return
        todo = []
        for axis, i in _AXES:
            if dmap.get(axis) and targets.get(axis) is not None and cur[i] is not None:
                todo.append((dmap[axis], targets[axis], cur[i]))
        if dmap.get("xy") and not dmap.get("x") and not dmap.get("y") and \
                targets.get("x") is not None and targets.get("y") is not None:
            todo.append((dmap["xy"], (targets["x"] + targets["y"]) / 2.0, (cur[0] + cur[1]) / 2.0))
        moved = False
        for (scope, nm, g), tgt, c in todo:
            if abs(tgt - c) < 1.0 or abs(g) < 0.05:
                continue
            p = _ctl_param(inst, scope, nm)
            if p is None or p.IsReadOnly:
                continue
            try:
                v = p.AsDouble() * MM + (tgt - c) / g
                p.Set(max(v, 20.0) / MM)
                moved = True
            except Exception:
                pass
        if not moved:
            break
    doc.Regenerate()


def _apply_dims(doc, inst, dmap, tx, ty, tz=None):
    _apply_targets(doc, inst, dmap, {"x": tx, "y": ty, "z": tz})


def _has_type_ctl(dmap):
    return any(v[0] == "type" for v in dmap.values())


def _find_symbol(doc, fam, name):
    try:
        for sid in fam.GetFamilySymbolIds():
            s = doc.GetElement(sid)
            if name_of(s) == name:
                return s
    except Exception:
        pass
    return None


def _begin_work_type(doc, inst):
    """Nhân đôi type hiện tại thành type tạm riêng cho instance (để đổi type parameter mà không
    đụng type gốc đang dùng chỗ khác)."""
    base = inst.Symbol
    nm = u"{}__b2r_tmp".format(name_of(base))
    tmp = _find_symbol(doc, base.Family, nm)
    if tmp is None:
        tmp = doc.GetElement(base.Duplicate(nm).Id)
    _activate(doc, tmp)
    inst.ChangeTypeId(tmp.Id)
    doc.Regenerate()
    return tmp


def _end_work_type(doc, inst, sym, tmp, dmap):
    """Đặt tên type tạm theo kích thước; đã có type đúng kích thước thì dùng lại và xoá type tạm."""
    vals = []
    for ax in ("x", "y", "z", "xy"):
        c = dmap.get(ax)
        if c and c[0] == "type":
            p = tmp.LookupParameter(c[1])
            if p is not None:
                vals.append(str(int(round(p.AsDouble() * MM))))
    if not vals:
        return
    nm = u"{}_B2R_{}".format(name_of(sym), u"x".join(vals))
    found = _find_symbol(doc, sym.Family, nm)
    if found is not None and CAD.eid_int(found.Id) != CAD.eid_int(tmp.Id):
        _activate(doc, found)
        inst.ChangeTypeId(found.Id)
        doc.Delete(tmp.Id)
    else:
        tmp.Name = nm
    doc.Regenerate()


def _run_with_type(doc, inst, sym, dmap, fn):
    """Chạy fn(dmap) - nếu có type parameter thì làm việc trên type tạm rồi chốt tên theo kích thước."""
    if _has_type_ctl(dmap):
        tmp = None
        try:
            tmp = _begin_work_type(doc, inst)
        except Exception:
            dmap = dict((k, v) for k, v in dmap.items() if v[0] == "inst")
        try:
            return fn(dmap)
        finally:
            if tmp is not None:
                try:
                    _end_work_type(doc, inst, sym, tmp, dmap)
                except Exception:
                    pass
    return fn(dmap)


def _set_inst_height(doc, inst, sym, h_mm):
    """Dự phòng: đặt instance parameter chiều cao (Height / Cao / Chiều cao) nếu family có."""
    for nm, p in _inst_length_params(inst, sym):
        toks = _tokens(nm)
        if any(t in (u"height", u"cao", u"h") for t in toks):
            try:
                p.Set(float(h_mm) / MM)
                return True
            except Exception:
                pass
    return False


def _enforce_z(doc, inst, z_abs_ft):
    """Ép cao độ THỰC của điểm đặt instance = z_abs (feet, toạ độ tuyệt đối của project), bất kể Revit
    hiểu Z lúc tạo là tuyệt đối hay là offset so với level (lỗi 'nhảy lên 4000' ở tầng 2)."""
    try:
        doc.Regenerate()
        cur = inst.Location.Point.Z
        d = z_abs_ft - cur
        if abs(d) > 0.2 / MM:
            ElementTransformUtils.MoveElement(doc, inst.Id, XYZ(0.0, 0.0, d))
        return True
    except Exception:
        return False


def _fit_dims_core(doc, inst, dmap, segs, cad_pts, rec, ang, mirror, can_hand, sym, cache, rot_off,
                   h_mm=None):
    """Kéo kích thước family theo hình block + chọn hướng. Trả {'mir','total','zdone'} hoặc None.
    Block được bao bằng hình chữ nhật nhỏ nhất (a x b theo góc phi); family xoay k*90° so với phi:
    k chẵn -> trục X family = a, k lẻ -> trục X family = b. Cao (trục Z) lấy từ h_mm."""
    pts = []
    for (x0, y0, x1, y1) in segs:
        pts.append((x0, y0))
        pts.append((x1, y1))
    zdone = bool(dmap.get("z") and h_mm)
    dk = ("delta", rec["name"], bool(mirror))
    if rot_off:
        phi = ang                                  # người dùng tự xoay: bám trục block
    else:
        if dk in cache:
            delta = cache[dk]
        else:
            r = G.min_area_rect(pts)
            delta = G.wrap90((r[4] if r else ang) - ang)
            cache[dk] = delta
        phi = ang + delta
    ex, ey = math.cos(phi), math.sin(phi)
    us = [x * ex + y * ey for (x, y) in pts]
    vs = [-x * ey + y * ex for (x, y) in pts]
    a, b = max(us) - min(us), max(vs) - min(vs)
    if a < 20.0 or b < 20.0:
        return None
    if rot_off:
        odd = int(round(rot_off / 90.0)) % 2 != 0
        tx, ty = (b, a) if odd else (a, b)
        _apply_dims(doc, inst, dmap, tx, ty, h_mm)
        return {"mir": bool(mirror), "total": ang + math.radians(rot_off), "zdone": zdone}
    fk = ("fit", rec["name"], bool(mirror), CAD.eid_int(sym.Id))
    if fk in cache:
        mir, k, st = cache[fk]
    else:
        try:
            f = inst.FacingOrientation
            face = (f.X, f.Y)
        except Exception:
            face = (0.0, 1.0)
        best = None
        for st_, (tx, ty), ks in (("A", (a, b), (0, 2)), ("B", (b, a), (1, 3))):
            _apply_dims(doc, inst, dmap, tx, ty)
            fp = _plan_points(inst)
            if len(fp) < 4 or len(cad_pts) < 4:
                continue
            m_, k_, s_, _b = _best_orient(fp, cad_pts, (rec["tf"][0], rec["tf"][1]), face, phi,
                                          can_hand, 0.0, ks)
            if best is None or s_ < best[0]:
                best = (s_, m_, k_, st_)
        if best is None:
            return None
        _s, mir, k, st = best
        cache[fk] = (mir, k, st)
    tx, ty = (a, b) if st == "A" else (b, a)
    _apply_dims(doc, inst, dmap, tx, ty, h_mm)
    return {"mir": mir, "total": phi + k * math.pi / 2.0, "zdone": zdone}


def _fit_dims(doc, inst, dmap, segs, cad_pts, rec, ang, mirror, can_hand, sym, cache, rot_off,
              h_mm=None):
    return _run_with_type(doc, inst, sym, dmap,
                          lambda dm: _fit_dims_core(doc, inst, dm, segs, cad_pts, rec, ang, mirror,
                                                    can_hand, sym, cache, rot_off, h_mm))


def _solid_uv_extent(inst, ux, uy):
    """(umin, umax, vmin, vmax) mm của CHỈ hình khối (Solid) của instance theo hệ trục u=(ux,uy), v=(-uy,ux).
    Không tính nét symbolic / vùng clearance nên tâm đo được là tâm thật của đồ vật."""
    vx, vy = -uy, ux
    opts = Options()
    opts.DetailLevel = ViewDetailLevel.Fine
    try:
        opts.ComputeReferences = False
    except Exception:
        pass
    lo = [1e18, 1e18]
    hi = [-1e18, -1e18]
    cnt = [0]

    def add(p):
        x, y = p.X * MM, p.Y * MM
        a = x * ux + y * uy
        b = x * vx + y * vy
        if a < lo[0]:
            lo[0] = a
        if a > hi[0]:
            hi[0] = a
        if b < lo[1]:
            lo[1] = b
        if b > hi[1]:
            hi[1] = b
        cnt[0] += 1

    def add_curve(c):
        try:
            if isinstance(c, Line):
                add(c.GetEndPoint(0))
                add(c.GetEndPoint(1))
            else:
                for p in c.Tessellate():
                    add(p)
        except Exception:
            pass

    def walk(ge):
        for g in ge:
            if isinstance(g, GeometryInstance):
                walk(g.GetInstanceGeometry())
            elif isinstance(g, Solid):
                try:
                    if g.Edges.Size == 0:
                        continue
                    for e in g.Edges:
                        add_curve(e.AsCurve())
                except Exception:
                    pass
    try:
        walk(inst.get_Geometry(opts))
    except Exception:
        return None
    if cnt[0] == 0:
        return None
    return (lo[0], hi[0], lo[1], hi[1])


def _place_front(doc, level, sym, z_mm, front, rot_off, fit, h_mm, cache):
    """Đặt family THEO MẶT TRƯỚC: xoay để mặt trước (FacingOrientation) của family trùng hướng mặt trước
    của block (front['face']), kéo kích thước theo block (nếu family kéo được), rồi dời tâm hình khối
    family trùng tâm thân block. Family không kéo được thì giữ nguyên cỡ, đặt ở tim block."""
    cx, cy, _a, _b, th = front["rect"]
    d = front["face"]
    z_abs = level.Elevation + z_mm / MM
    pt = XYZ(cx / MM, cy / MM, z_abs)
    _activate(doc, sym)
    inst = doc.Create.NewFamilyInstance(pt, sym, level, StructuralType.NonStructural)
    doc.Regenerate()
    f0 = inst.FacingOrientation
    fx0, fy0 = f0.X, f0.Y
    if math.hypot(fx0, fy0) < 1e-6:
        raise ValueError(u"family không có hướng mặt trước (FacingOrientation)")
    try:
        can_hand = bool(inst.CanFlipHand)
    except Exception:
        can_hand = False

    # --- kéo kích thước: chiều SÂU (dọc mặt trước) và chiều RỘNG (vuông góc) lấy từ thân block
    zdone = False
    if fit and front.get("ef") and front.get("ep"):
        dmap = _probe_controls(doc, inst, sym, cache)
        if dmap and (dmap.get("x") or dmap.get("y") or dmap.get("xy")):
            ef, ep = float(front["ef"]), float(front["ep"])
            if abs(fy0) >= abs(fx0):          # mặt trước chạy theo trục Y của family
                tx, ty = ep, ef
            else:
                tx, ty = ef, ep
            _run_with_type(doc, inst, sym, dmap,
                           lambda dm: _apply_dims(doc, inst, dm, tx, ty, h_mm))
            zdone = bool(dmap.get("z") and h_mm)
    if h_mm and not zdone:
        try:
            _set_inst_height(doc, inst, sym, h_mm)
        except Exception:
            pass

    th_rot = math.atan2(d[1], d[0]) - math.atan2(fy0, fx0) + math.radians(rot_off or 0.0)

    # --- KIỂM CHÉO hướng bằng HÌNH: thử 4 hướng x (lật / không lật) rồi so với hình block CAD.
    #     Mặt trước (tường / chi tiết) là căn cứ chính; chỉ đổi khi hình family khớp block tốt hơn RÕ RỆT
    #     (family vẽ lệch quy ước mặt trước, hoặc block bị lật gương). Vật đối xứng: điểm các hướng gần bằng nhau
    #     -> giữ hướng theo mặt trước.
    mir = False
    k_sel = 0
    cad_pts = None
    try:
        cad_pts = _cad_points(front.get("body") or [])
    except Exception:
        cad_pts = None
    note = u"không đủ hình để kiểm chéo"
    if cad_pts and len(cad_pts) >= 4:
        try:
            doc.Regenerate()
            fam_pts = _plan_points(inst)
            if len(fam_pts) >= 4:
                tab = _orient_table(fam_pts, cad_pts, (cx, cy), (fx0, fy0), th_rot, can_hand)
                s_front = tab[(False, 0)]
                (bm, bk), s_best = min(tab.items(), key=lambda kv: kv[1])
                need = 0.5 if float(front.get("conf", 0.0)) >= 0.85 else 0.7
                if (bm, bk) != (False, 0) and s_best < need * s_front and (s_front - s_best) > 8.0:
                    mir, k_sel = bm, bk
                    note = u"ĐỔI theo hình: lật={} xoay thêm {}° (điểm {:.0f} so với {:.0f} theo mặt trước)".format(
                        u"có" if bm else u"không", bk * 90, s_best, s_front)
                else:
                    note = u"giữ theo mặt trước (điểm hình {:.0f}, tốt nhất {:.0f})".format(s_front, s_best)
                    if s_front > 120.0 and s_front <= s_best * 1.05:
                        ORIENT_WARN.append(u"{}: hình family khác block nhiều (điểm {:.0f}) - kiểm tra lại hướng".format(
                            getattr(sym, "FamilyName", u"?"), s_front))
        except Exception as ex:
            note = u"kiểm chéo lỗi: {}".format(ex)
            mir, k_sel = False, 0
    th_rot += k_sel * math.pi / 2.0
    if mir:
        inst.flipHand()
    if abs(th_rot) > 1e-9:
        axis = Line.CreateBound(pt, XYZ(pt.X, pt.Y, pt.Z + 1.0))
        ElementTransformUtils.RotateElement(doc, inst.Id, axis, th_rot)
    doc.Regenerate()
    try:
        fo = inst.FacingOrientation
        want = math.atan2(d[1], d[0]) + k_sel * math.pi / 2.0 + math.radians(rot_off or 0.0)
        got = math.atan2(fo.Y, fo.X)
        dev = abs((got - want + math.pi) % (2 * math.pi) - math.pi)
        _ui_log(u"[HƯỚNG] mặt trước CAD=({:.2f},{:.2f}) | family mặt trước sau đặt=({:.2f},{:.2f}) lệch={:.1f}° | {}".format(
            d[0], d[1], fo.X, fo.Y, math.degrees(dev), note))
        if math.degrees(dev) > 5.0:
            ORIENT_WARN.append(u"{}: hướng mặt trước family lệch {:.0f}° so với CAD".format(
                getattr(sym, "FamilyName", u"?"), math.degrees(dev)))
    except Exception:
        pass

    # --- căn tâm hình khối family vào tâm thân block (trong hệ trục của block)
    ux, uy = math.cos(th), math.sin(th)
    ext = _solid_uv_extent(inst, ux, uy)
    if ext is not None:
        fu, fv = (ext[0] + ext[1]) / 2.0, (ext[2] + ext[3]) / 2.0
        tu, tv = cx * ux + cy * uy, -cx * uy + cy * ux
        dx = (tu - fu) * ux + (tv - fv) * (-uy)
        dy = (tu - fu) * uy + (tv - fv) * ux
        if math.hypot(dx, dy) > 1.0:
            ElementTransformUtils.MoveElement(doc, inst.Id, XYZ(dx / MM, dy / MM, 0.0))
    _enforce_z(doc, inst, z_abs)
    return inst


def place_level_based(doc, level, sym, rec, z_mm, sc=None, rot_off=0.0, align=True, cache=None,
                      fit=False, h_mm=None, front=None):
    """Đặt family theo level. Hướng được chọn bằng cách SO KHỚP HÌNH: thử 4 hướng (0/90/180/270)
    x có/không lật gương, chọn phương án mà hình family khớp hình block nhất (kết quả được
    nhớ theo từng block+family nên các block giống nhau không phải tính lại).
    rot_off != 0: người dùng tự chỉnh -> không tự đoán, chỉ xoay đúng góc block + rot_off.
    fit=True: family có INSTANCE parameter kích thước (Width/Length/Depth...) thì kéo bằng block,
    không có thì giữ nguyên. h_mm: nếu có thì đặt instance parameter chiều cao (nếu family có).
    Cuối cùng dời tâm family trùng tâm hình block."""
    if cache is None:
        cache = {}
    # --- cách MỚI: biết mặt trước của block (lưng sát tường / đầu giường / két / cánh tủ...) -> xoay theo đó.
    #     Lỗi ở bước nào thì huỷ toàn bộ (SubTransaction) và rơi về cách so khớp hình cũ bên dưới.
    if front and front.get("face") and (align or fit):
        st = SubTransaction(doc)
        st.Start()
        try:
            inst = _place_front(doc, level, sym, z_mm, front, rot_off, fit, h_mm, cache)
            st.Commit()
            return inst
        except Exception as ex:
            try:
                st.RollBack()
            except Exception:
                pass
            _ui_log(u"Đặt theo mặt trước lỗi ({}) -> dùng cách khớp hình cũ".format(ex))
            rot_off = 0.0        # lỗi: bỏ độ lệch mặt trước, để cách khớp hình cũ tự chọn hướng
    ang, mirror = CAD.inst_rot(rec["tf"])
    rot_off_r = math.radians(rot_off or 0.0)
    z_abs = level.Elevation + z_mm / MM
    pt = XYZ(rec["tf"][0] / MM, rec["tf"][1] / MM, z_abs)
    _activate(doc, sym)
    inst = doc.Create.NewFamilyInstance(pt, sym, level, StructuralType.NonStructural)
    axis = Line.CreateBound(pt, XYZ(pt.X, pt.Y, pt.Z + 1.0))

    segs = None
    cad_pts = None
    if (align or fit) and sc is not None:
        try:
            segs = CAD.inst_segs(sc, rec)
            cad_pts = _cad_points(segs) if segs else None
        except Exception:
            segs = None
            cad_pts = None

    can_hand = False
    try:
        can_hand = bool(inst.CanFlipHand)
    except Exception:
        can_hand = False

    # --- kéo kích thước theo block (chỉ khi family có instance parameter kích thước)
    fit_res = None
    if fit and segs and cad_pts:
        try:
            dmap = _probe_controls(doc, inst, sym, cache)
            if dmap:
                fit_res = _fit_dims(doc, inst, dmap, segs, cad_pts, rec, ang, mirror, can_hand,
                                    sym, cache, rot_off, h_mm)
        except Exception:
            fit_res = None
    if h_mm and not (fit_res and fit_res.get("zdone")):
        try:
            _set_inst_height(doc, inst, sym, h_mm)
        except Exception:
            pass

    decided = None
    if fit_res is not None:
        do_mirror = fit_res["mir"]
        total = fit_res["total"]
    else:
        ckey = (rec["name"], bool(mirror), CAD.eid_int(sym.Id))
        if cache is not None and ckey in cache and not rot_off:
            decided = cache[ckey]
        elif align and cad_pts and not rot_off:
            try:
                doc.Regenerate()
                fam_pts = _plan_points(inst)
                if len(fam_pts) >= 4 and len(cad_pts) >= 4:
                    try:
                        f = inst.FacingOrientation
                        face = (f.X, f.Y)
                    except Exception:
                        face = (0.0, 1.0)
                    m_, k_, sc_, base_ = _best_orient(
                        fam_pts, cad_pts, (rec["tf"][0], rec["tf"][1]), face, ang, can_hand)
                    decided = (m_, k_)
                    if cache is not None:
                        cache[ckey] = decided
            except Exception:
                decided = None
        if decided is not None:
            do_mirror, k = decided
            total = ang + k * math.pi / 2.0
        else:
            do_mirror, k = bool(mirror), 0
            total = ang + rot_off_r
    if do_mirror and can_hand:
        try:
            inst.flipHand()
        except Exception:
            pass
    if abs(total) > 1e-9:
        ElementTransformUtils.RotateElement(doc, inst.Id, axis, total)
    _ui_log(u"[HƯỚNG] chưa biết mặt trước -> khớp hình/xoay theo block: lật={} góc={:.0f}°".format(
        u"có" if (do_mirror and can_hand) else u"không", math.degrees(total)))

    if align and segs:
        try:
            xs = [q[0] for q in segs] + [q[2] for q in segs]
            ys = [q[1] for q in segs] + [q[3] for q in segs]
            bw, bh = max(xs) - min(xs), max(ys) - min(ys)
            bcx, bcy = (max(xs) + min(xs)) / 2.0, (max(ys) + min(ys)) / 2.0
            doc.Regenerate()
            fb = _bbox_xy(inst)
            if fb is not None:
                # không có hình học để so khớp -> chỉ sửa lệch 90° khi hộp bao ngược rõ rệt
                if decided is None and fit_res is None and not rot_off and \
                        max(bw, bh) > 1.15 * max(min(bw, bh), 1.0):
                    s0 = abs(fb[2] - bw) + abs(fb[3] - bh)
                    s1 = abs(fb[2] - bh) + abs(fb[3] - bw)
                    if s1 + 20.0 < s0:
                        ElementTransformUtils.RotateElement(doc, inst.Id, axis, math.pi / 2.0)
                        doc.Regenerate()
                        fb = _bbox_xy(inst) or fb
                ddx, ddy = bcx - fb[0], bcy - fb[1]
                if abs(ddx) > 1.0 or abs(ddy) > 1.0:
                    ElementTransformUtils.MoveElement(doc, inst.Id, XYZ(ddx / MM, ddy / MM, 0.0))
        except Exception:
            pass
    _enforce_z(doc, inst, z_abs)      # cao độ thực = level + Z offset (không cộng thêm cao độ level)
    return inst


# ------------------------------------------------------------------ family treo tường / face-based
def _new_on_wall_face(doc, sym, wall, loc, ref_dir, want_n):
    """Family face-based (WorkPlaneBased): gắn lên MẶT tường phía want_n (nx, ny)."""
    try:
        wo = wall.Orientation
        ext = (wo.X * want_n[0] + wo.Y * want_n[1]) > 0
    except Exception:
        ext = True
    layer = _DB.ShellLayerType.Exterior if ext else _DB.ShellLayerType.Interior
    refs = _DB.HostObjectUtils.GetSideFaces(wall, layer)
    if refs is None or refs.Count == 0:
        raise ValueError(u"tường không có mặt để gắn")
    return doc.Create.NewFamilyInstance(refs[0], loc, ref_dir, sym)


def _fit_wall(doc, inst, sym, u, n, along, depth, h_mm, cache):
    """Kéo kích thước family treo tường theo block: rộng = dọc tường, sâu = vuông góc tường,
    cao = h_mm. Trục family nào ứng với hướng nào lấy từ transform của instance (không đoán)."""
    dmap = _probe_controls(doc, inst, sym, cache)
    if not dmap:
        if h_mm:
            _set_inst_height(doc, inst, sym, h_mm)
        return False
    tf = inst.GetTransform()
    basis = [tf.BasisX, tf.BasisY, tf.BasisZ]
    sem = {}
    for (axis, i) in _AXES:
        b = basis[i]
        d = {"al": abs(b.X * u[0] + b.Y * u[1]), "dp": abs(b.X * n[0] + b.Y * n[1]), "ht": abs(b.Z)}
        sem[axis] = max(d, key=lambda k: d[k])
    want = {"al": along if along >= 20.0 else None,
            "dp": depth if depth >= 20.0 else None,
            "ht": h_mm if h_mm else None}
    targets = dict((ax, want[sem[ax]]) for ax in ("x", "y", "z"))
    _run_with_type(doc, inst, sym, dmap, lambda dm: _apply_targets(doc, inst, dm, targets))
    if h_mm and not dmap.get("z"):
        _set_inst_height(doc, inst, sym, h_mm)
    return True


def place_wall_mounted(doc, level, sym, rec, z_mm, sc, walls, radius, cache, fit=True, h_mm=None):
    """Đặt family TREO TƯỜNG (gắn tường: OneLevelBasedHosted, hoặc face-based: WorkPlaneBased) tại block:
    tìm tường gần nhất, đặt lên mặt tường phía có block, quay mặt ra phía block, cao độ = level + z_mm,
    rồi kéo kích thước (rộng/sâu/cao) theo block nếu family có tham số. Lỗi thì raise ValueError."""
    segs = CAD.inst_segs(sc, rec) or []
    if segs:
        xs = [s[0] for s in segs] + [s[2] for s in segs]
        ys = [s[1] for s in segs] + [s[3] for s in segs]
        cx, cy = (min(xs) + max(xs)) / 2.0, (min(ys) + max(ys)) / 2.0
    else:
        cx, cy = rec["tf"][0], rec["tf"][1]
    ox, oy = rec["tf"][0], rec["tf"][1]
    rmax = max(float(radius or 600.0) * 3.0, 1500.0)
    cands = _wall_candidates(walls, cx, cy, ox, oy, rmax)
    if not cands:
        raise ValueError(u"không có tường nào trong {:.0f} mm quanh block".format(rmax))
    try:
        face_based = (sym.Family.FamilyPlacementType == FamilyPlacementType.WorkPlaneBased)
    except Exception:
        face_based = False
    _activate(doc, sym)
    z_abs = level.Elevation + z_mm / MM
    pts = [(s[0], s[1]) for s in segs] + [(s[2], s[3]) for s in segs]
    last = None
    for _dist, wi in cands:
        wall, wx0, wy0, wx1, wy1, hw, _pen = walls[wi]
        L = math.hypot(wx1 - wx0, wy1 - wy0)
        ux, uy = (wx1 - wx0) / L, (wy1 - wy0) / L
        nx, ny = -uy, ux
        P = pts or [(cx, cy)]
        ts = [(p[0] - wx0) * ux + (p[1] - wy0) * uy for p in P]
        ns = [(p[0] - wx0) * nx + (p[1] - wy0) * ny for p in P]
        lo, hi = min(ts), max(ts)
        sgn = 1.0 if (min(ns) + max(ns)) / 2.0 >= 0 else -1.0
        t_mid = max(0.0, min(L, (lo + hi) / 2.0))
        qx = wx0 + ux * t_mid + nx * sgn * hw
        qy = wy0 + uy * t_mid + ny * sgn * hw
        wn = (nx * sgn, ny * sgn)               # hướng ra phía block (phía phòng)
        try:
            try:
                lvl = doc.GetElement(wall.LevelId) or level
            except Exception:
                lvl = level
            loc = XYZ(qx / MM, qy / MM, z_abs)
            if face_based:
                inst = _new_on_wall_face(doc, sym, wall, loc, XYZ(ux, uy, 0.0), wn)
            else:
                inst = _new_hosted(doc, loc, sym, wall, lvl)
                try:
                    f = inst.FacingOrientation
                    if (f.X * wn[0] + f.Y * wn[1]) < 0 and inst.CanFlipFacing:
                        inst.flipFacing()
                except Exception:
                    pass
        except Exception as ex:
            last = ex
            continue
        if fit:
            try:
                _fit_wall(doc, inst, sym, (ux, uy), wn, hi - lo, max(ns) - min(ns), h_mm, cache)
            except Exception:
                pass
        elif h_mm:
            try:
                _set_inst_height(doc, inst, sym, h_mm)
            except Exception:
                pass
        _enforce_z(doc, inst, z_abs)
        return inst
    raise ValueError(u"không gắn được vào {} tường gần nhất ({})".format(len(cands), last))


# ------------------------------------------------------------------ cửa đi / cửa sổ
def host_walls(doc, level):
    """Mọi tường THẲNG có thể gắn cửa ở level này: [(wall, x0,y0,x1,y1 mm, nửa dày mm, phạt mm)].
    Không còn đòi 'base constraint' đúng bằng level: chỉ cần tường cắt qua vùng cao 0-2100 mm
    trên level (nên tường đã chỉnh sửa vẫn nhận). Tường thuộc đúng level được ưu tiên."""
    out = []
    lid = CAD.eid_int(level.Id)
    z0 = level.Elevation
    for w in FilteredElementCollector(doc).OfClass(Wall):
        try:
            c = w.Location.Curve
            if not isinstance(c, Line):
                continue
            pen = 0.0
            try:
                p = w.get_Parameter(BuiltInParameter.WALL_BASE_CONSTRAINT)
                if p is None or CAD.eid_int(p.AsElementId()) != lid:
                    pen = 250.0
            except Exception:
                pen = 250.0
            try:
                bb = w.get_BoundingBox(None)
                if bb is not None and (bb.Max.Z < z0 + 100.0 / MM or bb.Min.Z > z0 + 2100.0 / MM):
                    continue                      # tường ở tầng khác
            except Exception:
                pass
            try:
                hw = w.Width * MM / 2.0
            except Exception:
                hw = 100.0
            a, b = c.GetEndPoint(0), c.GetEndPoint(1)
            out.append((w, a.X * MM, a.Y * MM, b.X * MM, b.Y * MM, hw, pen))
        except Exception:
            pass
    return out


def _wall_candidates(walls, px, py, ox, oy, rmax, topn=8):
    """Các tường gần điểm nhất (tính tới MẶT tường chứ không phải trục), tối đa topn."""
    cands = []
    for i, (wall, x0, y0, x1, y1, hw, pen) in enumerate(walls):
        dx, dy = x1 - x0, y1 - y0
        L2 = dx * dx + dy * dy
        if L2 < 1e-9:
            continue
        best = None
        for (qx0, qy0) in ((px, py), (ox, oy)):
            t = ((qx0 - x0) * dx + (qy0 - y0) * dy) / L2
            t = 0.0 if t < 0 else (1.0 if t > 1 else t)
            d = math.hypot(qx0 - (x0 + dx * t), qy0 - (y0 + dy * t))
            if best is None or d < best:
                best = d
        d = max(0.0, best - hw) + pen
        if d <= rmax:
            cands.append((d, i))
    cands.sort()
    return cands[:topn]


def _host_is(inst, wall):
    """True nếu Host của instance đúng là tường `wall` (không đọc được Host thì coi là chưa chắc -> None)."""
    try:
        h = inst.Host
    except Exception:
        return None
    if h is None:
        return False
    try:
        return CAD.eid_int(h.Id) == CAD.eid_int(wall.Id)
    except Exception:
        return None


def _new_hosted(doc, pt, sym, wall, lvl):
    """Tạo instance GẮN VÀO TƯỜNG (bắt buộc phải có host là tường, không tạo lỗ mở).
    Thử lần lượt: cao độ điểm đặt (cao độ tính + cao độ đường định vị tường + giữa chiều cao tường)
    x các kiểu gọi API. Mỗi lần tạo xong đều kiểm tra Host; không phải tường thì xoá và thử cách khác."""
    zs = [pt.Z]
    try:
        c = wall.Location.Curve
        zc = c.GetEndPoint(0).Z
        if abs(zc - pt.Z) > 1e-6:
            zs.append(zc)
        bb = wall.get_BoundingBox(None)
        if bb is not None:
            zm = (bb.Min.Z + bb.Max.Z) / 2.0
            if all(abs(zm - z) > 1e-6 for z in zs):
                zs.append(zm)
    except Exception:
        pass
    last = None
    for z in zs:
        p = XYZ(pt.X, pt.Y, z)
        for args in ((p, sym, wall, lvl, StructuralType.NonStructural),
                     (p, sym, wall, StructuralType.NonStructural)):
            try:
                inst = doc.Create.NewFamilyInstance(*args)
            except Exception as ex:
                last = ex
                continue
            ok = _host_is(inst, wall)
            if ok is False:
                last = ValueError(u"tạo được nhưng KHÔNG có host là tường")
                try:
                    doc.Delete(inst.Id)
                except Exception:
                    pass
                continue
            return inst
    raise last or ValueError(u"không gắn được vào tường")


def _door_arcs(doc, inst):
    """Cung mở cánh (symbolic) của cửa đã đặt, nhìn trong view mặt bằng hiện hành:
    [(tâm x, tâm y, bán kính, giữa-cung x, giữa-cung y)] mm."""
    out = []
    try:
        opts = Options()
        opts.View = doc.ActiveView
        opts.ComputeReferences = False
        ge = inst.get_Geometry(opts)
    except Exception:
        return out

    def walk(ge_):
        for g in ge_:
            if isinstance(g, GeometryInstance):
                walk(g.GetInstanceGeometry())
            elif isinstance(g, Arc):
                try:
                    if abs(g.Normal.Z) < 0.9 or g.Radius * MM < 200.0:
                        continue
                    c = g.Center
                    m = g.Evaluate(0.5, True)
                    out.append((c.X * MM, c.Y * MM, g.Radius * MM, m.X * MM, m.Y * MM))
                except Exception:
                    pass
    try:
        walk(ge)
    except Exception:
        pass
    return out


def _orient_door(doc, inst, sc, rec, qx, qy, ux, uy, nx, ny, cx, cy, opt):
    """Lật cửa cho ĐÚNG hướng mở + bản lề theo block CAD.
    Cách 1 (chính xác): đo cung mở cánh của cửa Revit rồi so với cung của block CAD.
    Cách 2 (dự phòng, family không có cung mặt bằng): dựa FacingOrientation/HandOrientation."""
    arcs_c = CAD.inst_arcs_full(sc, rec)
    f_swing = bool(opt.get("flip_swing"))
    f_hinge = bool(opt.get("flip_hinge"))

    def measure(arcs):
        a = max(arcs, key=lambda t: t[2])
        sw = (a[3] - a[0]) * nx + (a[4] - a[1]) * ny      # phía cánh quét ra (dọc pháp tuyến tường)
        hs = (a[0] - qx) * ux + (a[1] - qy) * uy          # bản lề nằm lệch dọc tường về phía nào
        return sw, hs

    if arcs_c:
        sw_c, hs_c = measure(arcs_c)
        if f_swing:
            sw_c = -sw_c
        if f_hinge:
            hs_c = -hs_c
        af = _door_arcs(doc, inst)
        if af:
            sw_f, hs_f = measure(af)
            if abs(sw_c) > 1.0 and abs(sw_f) > 1.0 and sw_c * sw_f < 0:
                try:
                    if inst.CanFlipFacing:
                        inst.flipFacing()
                        doc.Regenerate()
                        af = _door_arcs(doc, inst) or af
                        sw_f, hs_f = measure(af)
                except Exception:
                    pass
            if abs(hs_c) > 1.0 and abs(hs_f) > 1.0 and hs_c * hs_f < 0:
                try:
                    if inst.CanFlipHand:
                        inst.flipHand()
                        doc.Regenerate()
                except Exception:
                    pass
            return
    # ---- dự phòng
    cen_side = ((cx - qx) * nx + (cy - qy) * ny)
    if abs(cen_side) > 1.0:
        sgn = 1.0 if cen_side > 0 else -1.0
        if f_swing:
            sgn = -sgn
        want = XYZ(nx * sgn, ny * sgn, 0)
        try:
            f = inst.FacingOrientation
            if f.DotProduct(want) < 0 and inst.CanFlipFacing:
                inst.flipFacing()
                doc.Regenerate()
        except Exception:
            pass
    if arcs_c:
        hx, hy, _r = max(arcs_c, key=lambda a: a[2])[:3]
        hs = (hx - qx) * ux + (hy - qy) * uy
        if abs(hs) > 1.0:
            want = XYZ(ux * (1 if hs > 0 else -1), uy * (1 if hs > 0 else -1), 0)
            if f_hinge:
                want = want.Negate()
            try:
                h = inst.HandOrientation
                if h.DotProduct(want) < 0 and inst.CanFlipHand:
                    inst.flipHand()
            except Exception:
                pass


def place_hosted(doc, level, base_sym, kind, group, sc, walls, opt, cache, log):
    """Đặt cửa đi/cửa sổ cho mọi block của nhóm: cứ có tường sát block là gắn vào luôn.
    Tìm tường gần nhất (tính tới mặt tường); bán kính radius, nếu không có thì tự nới gấp 3
    (tối thiểu 1500 mm); tường đầu tiên không gắn được thì thử tường kế tiếp.
    opt: h, sill, w_fixed, radius, flip_swing, flip_hinge, round. Trả (đã đặt, [lý do bỏ qua])."""
    placed = 0
    skipped = []
    rmax = max(float(opt.get("radius") or 600.0) * 3.0, 1500.0)
    for rec in group["insts"]:
        try:
            segs = CAD.inst_segs(sc, rec)
            if segs:
                xs = [s[0] for s in segs] + [s[2] for s in segs]
                ys = [s[1] for s in segs] + [s[3] for s in segs]
                cx, cy = (min(xs) + max(xs)) / 2.0, (min(ys) + max(ys)) / 2.0
            else:
                cx, cy = rec["tf"][0], rec["tf"][1]
            ox, oy = rec["tf"][0], rec["tf"][1]
            cands = _wall_candidates(walls, cx, cy, ox, oy, rmax)
            if not cands:
                skipped.append(u"{} @ ({:.0f},{:.0f}): không có tường nào trong {:.0f} mm".format(
                    rec["name"], cx, cy, rmax))
                continue
            inst = None
            last = None
            for dist, wi in cands:
                wall, wx0, wy0, wx1, wy1, _hw, _pen = walls[wi]
                L = math.hypot(wx1 - wx0, wy1 - wy0)
                ux, uy = (wx1 - wx0) / L, (wy1 - wy0) / L
                nx, ny = -uy, ux
                pts = [(s[0], s[1]) for s in segs] + [(s[2], s[3]) for s in segs]
                ts = [(p[0] - wx0) * ux + (p[1] - wy0) * uy for p in pts] or \
                    [(cx - wx0) * ux + (cy - wy0) * uy]
                lo, hi = min(ts), max(ts)
                step = float(opt.get("round", 10) or 10)
                w_mm = opt["w_fixed"] if opt.get("w_fixed") else round((hi - lo) / step) * step
                if w_mm < 100:
                    last = u"bề rộng đo được quá nhỏ ({:.0f} mm)".format(w_mm)
                    continue
                t_mid = max(0.0, min(L, (lo + hi) / 2.0))
                qx, qy = wx0 + ux * t_mid, wy0 + uy * t_mid
                try:
                    lvl = doc.GetElement(wall.LevelId) or level
                except Exception:
                    lvl = level
                zb = lvl.Elevation
                try:
                    bb = wall.get_BoundingBox(None)
                    if bb is not None and bb.Min.Z > zb:
                        zb = bb.Min.Z            # tường đặt cao hơn level: cửa nằm trên chân tường
                except Exception:
                    pass
                try:
                    sym = get_or_make_type(doc, base_sym, w_mm, opt["h"], cache, log)
                    inst = _new_hosted(doc, XYZ(qx / MM, qy / MM, zb), sym, wall, lvl)
                except Exception as ex:
                    last = ex
                    inst = None
                    continue
                try:
                    p = inst.get_Parameter(BuiltInParameter.INSTANCE_SILL_HEIGHT_PARAM)
                    if p is not None and not p.IsReadOnly:
                        p.Set(opt["sill"] / MM + (zb - lvl.Elevation))
                except Exception:
                    pass
                if kind == "door" and segs:
                    doc.Regenerate()
                    _orient_door(doc, inst, sc, rec, qx, qy, ux, uy, nx, ny, cx, cy, opt)
                break
            if inst is None:
                skipped.append(u"{} @ ({:.0f},{:.0f}): không gắn được vào {} tường gần nhất ({})".format(
                    rec["name"], cx, cy, len(cands), last))
                continue
            placed += 1
        except Exception as ex:
            skipped.append(u"{}: {}".format(rec["name"], ex))
    return placed, skipped


# ------------------------------------------------------------------ thang (Create Sketch)
def _sk_geom(start, end, width, risers, z):
    """Hình học sketch 1 vế: biên trái/phải, các vạch bậc (risers), đường đi (path). z: feet."""
    sx, sy = start
    ex, ey = end
    dx, dy = ex - sx, ey - sy
    L = math.hypot(dx, dy)
    ux, uy = dx / L, dy / L
    lx, ly = -uy, ux                      # bên trái theo chiều đi lên
    hw = width / 2.0

    def P(x, y, off):
        return XYZ((x + lx * off) / MM, (y + ly * off) / MM, z)
    left = Line.CreateBound(P(sx, sy, hw), P(ex, ey, hw))
    right = Line.CreateBound(P(sx, sy, -hw), P(ex, ey, -hw))
    n = max(int(risers), 2)
    rl = []
    for i in range(n):
        t = i / float(n - 1)
        x, y = sx + dx * t, sy + dy * t
        rl.append(Line.CreateBound(P(x, y, hw), P(x, y, -hw)))
    path = Line.CreateBound(P(sx, sy, 0.0), P(ex, ey, 0.0))
    # biên kín (phương án 2)
    loop = [left,
            Line.CreateBound(P(ex, ey, hw), P(ex, ey, -hw)),
            Line.CreateBound(P(ex, ey, -hw), P(sx, sy, -hw)),
            Line.CreateBound(P(sx, sy, -hw), P(sx, sy, hw))]
    corners = {"s_l": (sx + lx * hw, sy + ly * hw), "s_r": (sx - lx * hw, sy - ly * hw),
               "e_l": (ex + lx * hw, ey + ly * hw), "e_r": (ex - lx * hw, ey - ly * hw),
               "dir": (ux, uy)}
    return left, right, rl, path, loop, corners


def _footprint_bbox_mm(run):
    """Hộp bao (mm) của hình chiếu bằng của vế thang vừa tạo; None nếu API không cho đọc."""
    try:
        loop = run.GetFootprintBoundary()
    except Exception:
        return None
    xs, ys = [], []
    try:
        for c in loop:
            for i in (0, 1):
                p = c.GetEndPoint(i)
                xs.append(p.X * MM)
                ys.append(p.Y * MM)
    except Exception:
        return None
    if not xs:
        return None
    return (min(xs), min(ys), max(xs), max(ys))


def _bbox_matches(bb, corners):
    """True/False: vế Revit có nằm đúng chỗ vế CAD không (None = không kiểm tra được)."""
    if bb is None:
        return None
    ks = ("s_l", "s_r", "e_l", "e_r")
    xs = [corners[k][0] for k in ks]
    ys = [corners[k][1] for k in ks]
    ex = (min(xs), min(ys), max(xs), max(ys))
    tol = max(350.0, 0.15 * max(ex[2] - ex[0], ex[3] - ex[1]))
    return all(abs(p - q) <= tol for p, q in zip(bb, ex))


def _actual_risers(doc, sid):
    try:
        doc.Regenerate()
        return int(doc.GetElement(sid).ActualRisersNumber)
    except Exception:
        return None


def _create_sketched_run(doc, sid, r, base_elev_ft, z_level_ft, expect_total=None):
    """StairsRun.CreateSketchedRun (Create Sketch).
    Lượt 1 (nghiêm ngặt): mỗi kiểu thử được tạo trong SubTransaction rồi KIỂM TRA:
      - hình chiếu của vế Revit phải trùng vế CAD (vị trí, hướng, kích thước),
      - tổng số riser của thang phải bằng số đọc từ CAD (thử số vạch bậc N, N+1, N-1).
    Kiểu nào sai thì huỷ, thử kiểu kế. Lượt 2 (nới lỏng, chỉ khi lượt 1 không kiểu nào đạt):
    lấy kiểu đầu tiên tạo được như bản cũ. Trả (run, corners, z_đã_dùng)."""
    errs = []
    zs = []
    for z in (z_level_ft + base_elev_ft, z_level_ft, 0.0):
        if z not in zs:
            zs.append(z)
    combos = []
    for extra in (0, 1, -1):             # số vạch bậc: N (chuẩn), N+1, N-1
        for z in zs:
            for variant in (1, 2, 3, 4):
                combos.append((extra, z, variant))
    for strict in (True, False):
        queue = list(combos)
        seen_extra = set(e_ for e_, _z, _v in combos)
        while queue:
            extra, z, variant = queue.pop(0)
            n_r = int(r["risers"]) + extra
            if n_r < 2:
                continue
            fix_extra = None
            sub = SubTransaction(doc)
            sub.Start()
            try:
                left, right, rl, path, loop, corners = _sk_geom(
                    r["start"], r["end"], r["width"], n_r, z)
                bl = List[Curve]()
                if variant == 1:        # trái đi lên + phải đi xuống (vòng ngược chiều kim đồng hồ)
                    bl.Add(left)
                    bl.Add(right.CreateReversed())
                elif variant == 2:      # 2 nét cùng chiều
                    bl.Add(left)
                    bl.Add(right)
                elif variant == 3:      # vòng kín 4 nét
                    for c in loop:
                        bl.Add(c)
                else:                   # đảo: phải đi lên + trái đi xuống
                    bl.Add(right)
                    bl.Add(left.CreateReversed())
                rc = List[Curve]()
                for c in rl:
                    rc.Add(c)
                pc = List[Curve]()
                pc.Add(path)
                run = StairsRun.CreateSketchedRun(doc, sid, base_elev_ft, bl, rc, pc)
                if strict:
                    ok_pos = _bbox_matches(_footprint_bbox_mm(run), corners)
                    if ok_pos is False:
                        raise Exception(u"hình chiếu vế Revit lệch vế CAD")
                    if expect_total is not None:
                        got = _actual_risers(doc, sid)
                        if got is not None and got != int(expect_total):
                            fix_extra = extra + (int(expect_total) - got)
                            raise Exception(u"tổng riser {} khác {} đọc từ CAD".format(
                                got, int(expect_total)))
                sub.Commit()
                _ui_log(u"Sketch thang OK ({}): vạch{:+d} z={:.2f} kiểu{}".format(
                    u"đã kiểm tra" if strict else u"CHƯA kiểm tra được", extra, z, variant))
                return run, corners, z
            except Exception as ex:
                try:
                    sub.RollBack()
                except Exception:
                    pass
                msg = u"{}vạch{:+d} z={:.2f} kiểu{}: {}".format(
                    u"" if strict else u"[nới lỏng] ", extra, z, variant, ex)
                errs.append(msg)
                _ui_log(u"Sketch thang thử lỗi - " + msg)
                if strict and fix_extra is not None and fix_extra not in seen_extra \
                        and abs(fix_extra) <= 3:
                    # biết lệch bao nhiêu riser -> thử ngay số vạch bậc đã hiệu chỉnh
                    seen_extra.add(fix_extra)
                    queue[0:0] = [(fix_extra, z, v_) for v_ in (1, 2, 3, 4)]
    raise Exception(u"CreateSketchedRun lỗi: " + u" | ".join(errs[:2]))


def _tread_curves(geo, z):
    """Đường cong sketch cho cả thang (1 vế liền, có thể có bậc chéo) từ tread_geometry().
    Trả dict: left, right (list Line), risers (list Line), path (list Line), pts (mọi điểm biên)."""
    def X(p):
        return XYZ(p[0] / MM, p[1] / MM, z)

    def lines(pts):
        out = []
        for a, b in zip(pts, pts[1:]):
            if math.hypot(b[0] - a[0], b[1] - a[1]) >= 5.0:
                out.append(Line.CreateBound(X(a), X(b)))
        return out
    risers = []
    for a, b in geo["risers"]:
        if math.hypot(b[0] - a[0], b[1] - a[1]) >= 5.0:
            risers.append(Line.CreateBound(X(a), X(b)))
    return {"left": lines(geo["left"]), "right": lines(geo["right"]), "risers": risers,
            "path": lines(geo["path"]), "pts": list(geo["left"]) + list(geo["right"]),
            "first": (geo["left"][0], geo["right"][0]), "last": (geo["left"][-1], geo["right"][-1])}


def _tread_boundary(cv, variant):
    """Danh sách biên theo 5 kiểu (Revit cần đúng chiều/độ kín; thử lần lượt)."""
    def rev(lst):
        return [c.CreateReversed() for c in reversed(lst)]

    def X(p):
        z = cv["left"][0].GetEndPoint(0).Z
        return XYZ(p[0] / MM, p[1] / MM, z)

    def seg(a, b):
        return [Line.CreateBound(X(a), X(b))] if math.hypot(b[0] - a[0], b[1] - a[1]) >= 5.0 else []
    L, R = cv["left"], cv["right"]
    if variant == 1:                    # trái đi lên + phải đi xuống
        return L + rev(R)
    if variant == 2:                    # 2 chuỗi cùng chiều
        return L + R
    if variant in (3, 5):               # vòng kín
        loop = L + seg(cv["last"][0], cv["last"][1]) + rev(R) + seg(cv["first"][1], cv["first"][0])
        return loop if variant == 3 else rev(loop)
    return R + rev(L)                   # 4: phải đi lên + trái đi xuống


def _create_tread_run(doc, sid, it, base_elev_ft, z_level_ft, expect_total):
    """Dựng cả thang bằng MỘT sketched run: biên + vạch bậc (kể cả vạch chéo) + đường đi đều lấy
    theo đúng các bậc đọc từ CAD. Mỗi kiểu thử trong SubTransaction, kiểm vị trí + tổng riser."""
    geo = TR.tread_geometry(it["treads"])
    if geo is None:
        raise Exception(u"không suy ra được vạch bậc từ các bậc CAD")
    xs = [p[0] for p in geo["left"] + geo["right"]]
    ys = [p[1] for p in geo["left"] + geo["right"]]
    ex = (min(xs), min(ys), max(xs), max(ys))
    tol = max(350.0, 0.15 * max(ex[2] - ex[0], ex[3] - ex[1]))
    zs = []
    for z in (z_level_ft + base_elev_ft, z_level_ft, 0.0):
        if z not in zs:
            zs.append(z)
    errs = []
    for strict in (True, False):
        for z in zs:
            for variant in (1, 3, 2, 4, 5):
                sub = SubTransaction(doc)
                sub.Start()
                try:
                    cv = _tread_curves(geo, z)
                    bl = List[Curve]()
                    for c in _tread_boundary(cv, variant):
                        bl.Add(c)
                    rc = List[Curve]()
                    for c in cv["risers"]:
                        rc.Add(c)
                    pc = List[Curve]()
                    for c in cv["path"]:
                        pc.Add(c)
                    run = StairsRun.CreateSketchedRun(doc, sid, base_elev_ft, bl, rc, pc)
                    if strict:
                        bb = _footprint_bbox_mm(run)
                        if bb is not None and not all(abs(a - b) <= tol for a, b in zip(bb, ex)):
                            raise Exception(u"hình chiếu thang Revit lệch hình CAD")
                        got = _actual_risers(doc, sid)
                        if got is not None and got != int(expect_total):
                            raise Exception(u"tổng riser {} khác {} (số bậc đọc từ CAD)".format(
                                got, expect_total))
                    sub.Commit()
                    _ui_log(u"Sketch thang theo bậc CAD OK ({}): {} riser, {} bậc chéo, z={:.2f} "
                            u"kiểu{}".format(u"đã kiểm tra" if strict else u"CHƯA kiểm tra được",
                                             len(cv["risers"]), it.get("winders", 0), z, variant))
                    return run
                except Exception as ex_:
                    try:
                        sub.RollBack()
                    except Exception:
                        pass
                    msg = u"{}z={:.2f} kiểu{}: {}".format(u"" if strict else u"[nới lỏng] ", z,
                                                          variant, ex_)
                    errs.append(msg)
                    _ui_log(u"Sketch thang (theo bậc CAD) thử lỗi - " + msg)
    raise Exception(u"CreateSketchedRun theo bậc CAD lỗi: " + u" | ".join(errs[:2]))


def _ui_log(msg):
    try:
        import b2r_ui as _U
        _U.log(msg)
    except Exception:
        pass


def _hull(pts):
    pts = sorted(set((round(x, 3), round(y, 3)) for x, y in pts))
    if len(pts) < 3:
        return pts

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo = []
    for p in pts:
        while len(lo) >= 2 and cross(lo[-2], lo[-1], p) <= 0:
            lo.pop()
        lo.append(p)
    up = []
    for p in reversed(pts):
        while len(up) >= 2 and cross(up[-2], up[-1], p) <= 0:
            up.pop()
        up.append(p)
    return lo[:-1] + up[:-1]


def _poly_area(p):
    a = 0.0
    for i in range(len(p)):
        x0, y0 = p[i]
        x1, y1 = p[(i + 1) % len(p)]
        a += x0 * y1 - x1 * y0
    return abs(a) / 2.0


def _landing_polygon(cp, cc, w_prev, w_next):
    """Chiếu nghỉ giữa vế trước và vế sau, suy ra từ mép cuối vế trước + mép đầu vế sau:
    L-turn: 2 mép chung góc -> thêm mép đối diện (sâu = bề rộng vế sau);
    U-turn: 2 mép thẳng hàng -> kéo thêm về phía trước vế trước;
    có đoạn chiếu nghỉ thẳng giữa 2 vế: lấy trọn hình bao."""
    A1, B1 = cp["e_l"], cp["e_r"]
    A2, B2 = cc["s_l"], cc["s_r"]
    ux, uy = cp["dir"]
    pts = [A1, B1, A2, B2]
    h = _hull(pts)
    d = w_next
    if len(h) < 3:                      # U-turn: 2 mép thẳng hàng -> đẩy cả hai về phía trước
        pts = pts + [(q[0] + ux * d, q[1] + uy * d) for q in (A1, B1, A2, B2)]
        h = _hull(pts)
    elif len(h) < 4 or _poly_area(h) < 0.3 * w_prev * w_next:     # L-turn: thiếu 1 góc
        pts = pts + [(A1[0] + ux * d, A1[1] + uy * d), (B1[0] + ux * d, B1[1] + uy * d)]
        h = _hull(pts)
    return h


def _clean_pts(pts, tol=3.0):
    """Bỏ điểm trùng/quá gần nhau (mm) để CurveLoop liền mạch, không có nét ngắn suy biến."""
    out = []
    for p in pts:
        if not out or math.hypot(p[0] - out[-1][0], p[1] - out[-1][1]) > tol:
            out.append(p)
    while len(out) > 1 and math.hypot(out[0][0] - out[-1][0], out[0][1] - out[-1][1]) <= tol:
        out.pop()
    return out


def _landing_loop(pts, z):
    """CurveLoop KHÍN (API CreateSketchedLanding nhận CurveLoop, KHÔNG nhận List[Curve])."""
    lp = CurveLoop()
    n = len(pts)
    for i in range(n):
        a_, b_ = pts[i], pts[(i + 1) % n]
        lp.Append(Line.CreateBound(XYZ(a_[0] / MM, a_[1] / MM, z),
                                   XYZ(b_[0] / MM, b_[1] / MM, z)))
    return lp


def _call_sketched_landing(doc, sid, pts, z, elev_ft):
    """Gọi CreateSketchedLanding(doc, stairsId, CurveLoop, baseElevation)."""
    lp = _landing_loop(pts, z)
    try:
        return StairsLanding.CreateSketchedLanding(doc, sid, lp, elev_ft)
    except TypeError as ex1:
        # bản API/pythonnet khác: thử kiểu danh sách nét
        cl = List[Curve]()
        for c in lp:
            cl.Add(c)
        try:
            return StairsLanding.CreateSketchedLanding(doc, sid, cl, elev_ft)
        except Exception:
            raise ex1


def _make_landing(doc, sid, prev_run, run, c_prev, c_cur, w_prev, w_next, elev_ft, z_level_ft,
                  z_run=None):
    """Chiếu nghỉ giữa 2 vế: VẼ SKETCH theo hình học CAD (CurveLoop) trước; lỗi mới dùng
    tự động của Revit. Trả None nếu ok, hoặc chuỗi mô tả lỗi."""
    if StairsLanding is None:
        return u"chiếu nghỉ: API không có StairsLanding"
    errs = []
    try:
        hull = _clean_pts(_landing_polygon(c_prev, c_cur, w_prev, w_next))
        if len(hull) < 3:
            raise Exception(u"hình chiếu nghỉ suy biến")
        zs = []
        for z in (z_run, z_level_ft + elev_ft, z_level_ft, 0.0):
            if z is not None and z not in zs:
                zs.append(z)
        for z in zs:
            for rev in (False, True):          # _hull trả ngược chiều kim đồng hồ; thử cả đảo
                sub = SubTransaction(doc)
                sub.Start()
                try:
                    pts = list(reversed(hull)) if rev else hull
                    _call_sketched_landing(doc, sid, pts, z, elev_ft)
                    sub.Commit()
                    _ui_log(u"Chiếu nghỉ sketch OK: z={:.2f}{} elev={:.3f}ft".format(
                        z, u" đảo" if rev else u"", elev_ft))
                    return None
                except Exception as ex:
                    try:
                        sub.RollBack()
                    except Exception:
                        pass
                    errs.append(u"sketch z={:.2f}{}: {}".format(z, u" đảo" if rev else u"", ex))
                    _ui_log(u"Chiếu nghỉ sketch lỗi - " + errs[-1])
    except Exception as ex:
        errs.append(u"sketch: {}".format(ex))
    sub = SubTransaction(doc)
    sub.Start()
    try:
        StairsLanding.CreateAutomaticLanding(doc, prev_run.Id, run.Id)
        sub.Commit()
        _ui_log(u"Chiếu nghỉ: dùng tự động của Revit")
        return None
    except Exception as ex:
        try:
            sub.RollBack()
        except Exception:
            pass
        errs.append(u"tự động: {}".format(ex))
    _ui_log(u"Chiếu nghỉ lỗi: " + u" | ".join(errs))
    return u"chiếu nghỉ KHÔNG tạo được (" + errs[0] + u" ... " + errs[-1] + u")"


def _build_sketch_item(doc, st, sid, it, base_lv, top_lv):
    """Dựng 1 thang (1 hoặc nhiều vế) bằng sketch. Trả danh sách cảnh báo (chiếu nghỉ...)."""
    warns = []
    if it.get("treads"):
        total = len(it["treads"]) + 1
        it["_want"] = total
        try:
            st.DesiredRisersNumber = total
        except Exception:
            pass
        try:
            _create_tread_run(doc, sid, it, 0.0, base_lv.Elevation, total)
            return warns
        except Exception as ex:
            _ui_log(u"Dựng theo bậc CAD lỗi: {}".format(ex))
            if not it.get("fb"):
                raise
            warns.append(u"không dựng sát từng bậc CAD được ({}) → đã dựng theo cách tách vế "
                         u"(KHÔNG có bậc chéo)".format(str(ex)[:160]))
            fb = it["fb"]
            it["_want"] = (sum(int(r["risers"]) for r in fb["runs"]) if fb.get("runs")
                           else int(fb["risers"]))
            it = dict(fb, name=it.get("name"))
    runs = it.get("runs") or [{"start": it["start"], "end": it["end"], "width": it["width"],
                               "length": it["length"], "risers": it["risers"]}]
    total = sum(int(r["risers"]) for r in runs)
    try:
        st.DesiredRisersNumber = total
    except Exception:
        pass
    rh = (top_lv.Elevation - base_lv.Elevation) / float(max(total, 1))
    z_lv = base_lv.Elevation
    cum = 0
    prev = None
    prev_c = None
    for k, r in enumerate(runs):
        base_elev = cum * rh
        run, corners, z_used = _create_sketched_run(doc, sid, r, base_elev, z_lv,
                                                    expect_total=cum + int(r["risers"]))
        if prev is not None:
            w = _make_landing(doc, sid, prev, run, prev_c, corners, runs[k - 1]["width"],
                              r["width"], base_elev, z_lv, z_used)
            if w:
                warns.append(w)
        cum += int(r["risers"])
        prev, prev_c = run, corners
    return warns


def _build_straight_item(doc, st, sid, it, base_lv, top_lv):
    """Dự phòng: Straight Run (không sketch) - cách cũ."""
    z = base_lv.Elevation
    if it.get("runs"):
        _build_multi_runs(doc, st, sid, it["runs"], base_lv, top_lv, z)
        return
    ln = Line.CreateBound(XYZ(it["start"][0] / MM, it["start"][1] / MM, z),
                          XYZ(it["end"][0] / MM, it["end"][1] / MM, z))
    run = StairsRun.CreateStraightRun(doc, sid, ln, StairsRunJustification.Center)
    try:
        run.ActualRunWidth = it["width"] / MM
    except Exception:
        pass
    risers = int(it["risers"])
    try:
        st.DesiredRisersNumber = risers
    except Exception:
        pass
    try:
        st.ActualTreadDepth = (it["length"] / max(risers - 1, 1)) / MM
    except Exception:
        pass


def _build_multi_runs(doc, st, sid, runs, base_lv, top_lv, z):
    total = sum(int(r["risers"]) for r in runs)
    try:
        st.DesiredRisersNumber = total
    except Exception:
        pass
    treads = [r["length"] / max(int(r["risers"]) - 1, 1) for r in runs]
    try:
        st.ActualTreadDepth = (sum(treads) / len(treads)) / MM
    except Exception:
        pass
    rh = (top_lv.Elevation - base_lv.Elevation) / float(max(total, 1))
    cum = 0
    prev = None
    for k, r in enumerate(runs):
        ln = Line.CreateBound(XYZ(r["start"][0] / MM, r["start"][1] / MM, z),
                              XYZ(r["end"][0] / MM, r["end"][1] / MM, z))
        run = StairsRun.CreateStraightRun(doc, sid, ln, StairsRunJustification.Center)
        try:
            run.ActualRunWidth = r["width"] / MM
        except Exception:
            pass
        if k > 0:
            try:
                run.BaseElevation = cum * rh
            except Exception:
                pass
        cum += int(r["risers"])
        if prev is not None and StairsLanding is not None:
            try:
                StairsLanding.CreateAutomaticLanding(doc, prev.Id, run.Id)
            except Exception:
                pass
        prev = run


def _one_stair(doc, it, stype, base_lv, top_lv, pre, sketch):
    scope = None
    t = None
    try:
        scope = StairsEditScope(doc, u"Dựng thang từ block")
        sid = scope.Start(base_lv.Id, top_lv.Id)
        t = Transaction(doc, u"Vế thang")
        t.Start()
        st = doc.GetElement(sid)
        if stype is not None:
            st.ChangeTypeId(stype.Id)
        warns = []
        if sketch:
            warns = _build_sketch_item(doc, st, sid, it, base_lv, top_lv)
        else:
            _build_straight_item(doc, st, sid, it, base_lv, top_lv)
        try:
            want = int(it.get("_want") or (len(it["treads"]) + 1 if it.get("treads") else 0)
                       or (sum(int(r["risers"]) for r in it["runs"]) if it.get("runs")
                           else int(it["risers"])))
            doc.Regenerate()
            got = int(st.ActualRisersNumber)
            if got != want:
                warns.append(u"số riser thực tế {} khác {} đọc từ CAD".format(got, want))
        except Exception:
            pass
        t.Commit()
        scope.Commit(pre)
        return warns
    except Exception:
        try:
            if t is not None and t.HasStarted():
                t.RollBack()
        except Exception:
            pass
        try:
            scope.Dispose()
        except Exception:
            pass
        raise


_MONO_KW = (u"monolith", u"cast", u"đúc", u"đổ", u"bê tông", u"be tong", u"concrete",
            u"liền khối", u"lien khoi")


def is_mono_name(name):
    n = (name or u"").lower()
    return any(k in n for k in _MONO_KW)


def build_stairs(doc, items, stype, base_lv, top_lv, sketch=True, all_types=None,
                 allow_straight=False):
    """items: [{start:(x,y), end:(x,y), width, length, risers, runs?}] mm.
    Dựng bằng Create Sketch (CreateSketchedRun). Sketch chỉ chạy với loại thang hỗ trợ
    (thường là Monolithic / đúc liền khối) nên nếu loại đang chọn lỗi, tool tự thử các loại
    thang khác (ưu tiên tên đúc/monolithic). Chỉ khi allow_straight=True mới dựng lại bằng
    Straight Run. Trả (số thang dựng được, [thông báo])."""
    ok = 0
    fails = []
    if not HAS_STAIRS:
        return 0, [u"Không nạp được API thang của Revit, thiếu: {}. "
                   u"Gửi nội dung này cho người hỗ trợ.".format(u", ".join(STAIRS_MISSING))]
    pre, pre_err = get_stair_pre()
    if pre is None:
        return 0, [u"Không tạo được bộ xử lý lỗi cho thang: {}".format(pre_err)]
    cands = []
    if stype is not None:
        cands.append((name_of(stype), stype))
    others = [(n, t) for n, t in (all_types or {}).items()
              if stype is None or CAD.eid_int(t.Id) != CAD.eid_int(stype.Id)]
    others.sort(key=lambda nt: (not is_mono_name(nt[0]), nt[0].lower()))
    cands.extend(others[:12])
    for it in items:
        nm = it.get("name", u"thang")
        done = False
        last = None
        if sketch:
            for ci, (tn, tt) in enumerate(cands or [(u"", None)]):
                try:
                    warns = _one_stair(doc, it, tt, base_lv, top_lv, pre, True)
                    ok += 1
                    done = True
                    if ci > 0:
                        fails.append(u"{}: loại thang bạn chọn không hỗ trợ Sketch → đã dùng loại "
                                     u"'{}'".format(nm, tn))
                    for w in warns:
                        fails.append(u"{}: {}".format(nm, w))
                    break
                except Exception as ex1:
                    last = ex1
                    _ui_log(u"Thang '{}' loại '{}' dựng sketch lỗi: {}".format(nm, tn, ex1))
        if done:
            continue
        if sketch and not allow_straight:
            fails.append(u"{}: KHÔNG dựng được bằng Create Sketch ({}). Hãy chọn loại thang "
                         u"đúc liền khối (Monolithic / Cast-In-Place) hoặc tick cho phép Straight "
                         u"Run. Chi tiết trong Block2Revit.log".format(nm, last))
            continue
        try:
            _one_stair(doc, it, stype, base_lv, top_lv, pre, False)
            ok += 1
            if sketch:
                fails.append(u"{}: Sketch lỗi → đã dựng bằng Straight Run ({})".format(nm, last))
        except Exception as ex:
            fails.append(u"{}: {}".format(nm, ex))
    return ok, fails


# ------------------------------------------------------------------ khoanh màu vùng đang chọn
def hl_draw(doc, view, old_ids, shapes):
    """Xoá các nét khoanh cũ (old_ids) rồi vẽ nét khoanh mới bằng detail line có màu + nét đậm
    trong view hiện hành. shapes: [(polygon [(x,y) mm], (r,g,b), độ dày nét 1..16)].
    Trả danh sách ElementId của nét mới (để lần sau xoá). Phải gọi trong API context."""
    new_ids = []
    t = Transaction(doc, u"Khoanh vùng đang chọn")
    t.Start()
    try:
        for eid in old_ids:
            try:
                doc.Delete(eid)
            except Exception:
                pass
        try:
            z = view.Origin.Z
        except Exception:
            z = 0.0
        err = None
        for pts, rgb, weight in shapes:
            ogs = OverrideGraphicSettings()
            try:
                ogs.SetProjectionLineColor(RColor(rgb[0], rgb[1], rgb[2]))
                ogs.SetProjectionLineWeight(int(weight))
            except Exception:
                pass
            n = len(pts)
            for i in range(1 if n == 2 else n):          # 2 điểm = 1 đoạn thẳng (không khép kín)
                a, b = pts[i], pts[(i + 1) % n]
                if math.hypot(b[0] - a[0], b[1] - a[1]) < 1.0:
                    continue
                try:
                    dc = doc.Create.NewDetailCurve(
                        view, Line.CreateBound(XYZ(a[0] / MM, a[1] / MM, z),
                                               XYZ(b[0] / MM, b[1] / MM, z)))
                    try:
                        view.SetElementOverrides(dc.Id, ogs)
                    except Exception:
                        pass
                    new_ids.append(dc.Id)
                except Exception as ex:
                    err = ex
        t.Commit()
        if err is not None and not new_ids:
            raise err
    except Exception:
        try:
            if t.HasStarted():
                t.RollBack()
        except Exception:
            pass
        return list(old_ids)
    return new_ids


# ------------------------------------------------------------------ zoom / chọn trong Revit
def zoom_rect(uidoc, minx, miny, maxx, maxy, margin=1200.0):
    """Zoom view mặt bằng đang mở vào hình chữ nhật (mm) + lề. Phải gọi trong API context."""
    vid = CAD.eid_int(uidoc.ActiveView.Id)
    p1 = XYZ((minx - margin) / MM, (miny - margin) / MM, 0.0)
    p2 = XYZ((maxx + margin) / MM, (maxy + margin) / MM, 0.0)
    for uv in uidoc.GetOpenUIViews():
        if CAD.eid_int(uv.ViewId) == vid:
            uv.ZoomAndCenterRectangle(p1, p2)
            return True
    return False


# ------------------------------------------------------------------ nạp family từ thư mục
def load_families(doc, paths, problems):
    """Nạp các file .rfa vào project (gọi trong Transaction). Trả danh sách tên family
    (tên file không đuôi). Family đã có trong project thì giữ nguyên."""
    stems = []
    for p in paths:
        stem = os.path.splitext(os.path.basename(p))[0]
        try:
            doc.LoadFamily(p)      # trả False nếu family đã có -> vẫn dùng được
            stems.append(stem)
        except Exception as ex:
            problems.append(u"{}: {}".format(stem, ex))
    return stems


# ------------------------------------------------------------------ sàn theo Room
def get_floor_types(doc):
    d = {}
    for t in FilteredElementCollector(doc).OfClass(FloorType):
        try:
            if t.IsFoundationSlab:
                continue
        except Exception:
            pass
        d[name_of(t)] = t
    return d


def get_rooms(doc, level):
    """Room đã đặt (có diện tích) trên level, sắp theo số phòng."""
    out = []
    lid = CAD.eid_int(level.Id)
    col = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Rooms)
    for r in col.WhereElementIsNotElementType():
        try:
            if r.Location is None or r.Area <= 0:
                continue
            if CAD.eid_int(r.LevelId) != lid:
                continue
            out.append(r)
        except Exception:
            pass
    out.sort(key=lambda r: (room_number(r), room_name(r)))
    return out


def room_name(r):
    try:
        p = r.get_Parameter(BuiltInParameter.ROOM_NAME)
        return p.AsString() or u""
    except Exception:
        return u""


def room_number(r):
    try:
        return r.Number or u""
    except Exception:
        return u""


def auto_rooms(doc, level):
    """Đặt Room vào mọi vùng kín trên level (gọi trong Transaction). Trả số Room mới."""
    ids = doc.Create.NewRooms2(level)
    try:
        return len(list(ids))
    except Exception:
        return 0


def build_floors(doc, level, rooms, ftype, off_mm):
    """Mỗi Room -> 1 sàn theo biên hoàn thiện (vòng ngoài + lỗ). Gọi trong Transaction."""
    ok = 0
    fails = []
    opt = SpatialElementBoundaryOptions()
    opt.SpatialElementBoundaryLocation = SpatialElementBoundaryLocation.Finish
    for r in rooms:
        label = u"{} {}".format(room_number(r), room_name(r)).strip() or str(CAD.eid_int(r.Id))
        try:
            src = r.GetBoundarySegments(opt)
            if not src or len(src) == 0:
                fails.append(u"{}: Room không có biên".format(label))
                continue
            loops = List[CurveLoop]()
            for segs in src:
                cl = CurveLoop()
                for sg in segs:
                    cl.Append(sg.GetCurve())
                loops.Add(cl)
            fl = Floor.Create(doc, loops, ftype.Id, level.Id)
            p = fl.get_Parameter(BuiltInParameter.FLOOR_HEIGHTABOVELEVEL_PARAM)
            if p is not None and not p.IsReadOnly:
                p.Set(off_mm / MM)
            ok += 1
        except Exception as ex:
            fails.append(u"{}: {}".format(label, ex))
    return ok, fails

