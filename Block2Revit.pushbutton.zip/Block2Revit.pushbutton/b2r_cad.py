# -*- coding: utf-8 -*-
"""Đọc CAD link/import trong Revit: layer, block (kèm hình), nét thẳng, chữ."""
import re
import math
import unicodedata
from Autodesk.Revit.DB import (
    FilteredElementCollector, ImportInstance, GeometryInstance, Options,
    ViewDetailLevel, Line, PolyLine, Arc, Curve
)
try:
    from Autodesk.Revit.DB import TextNode
except Exception:
    TextNode = None
import b2r_geom as G

MM = 304.8
_ls_cache = {}


def eid_int(e):
    try:
        return int(e.Value)
    except Exception:
        return int(e.IntegerValue)


def name_of(el):
    try:
        return el.Name
    except Exception:
        return str(el.Id)


def layer_of(doc, g):
    k = None
    try:
        i = g.GraphicsStyleId
        k = eid_int(i)
        if k in _ls_cache:
            return _ls_cache[k]
        gs = doc.GetElement(i)
        nm = gs.GraphicsStyleCategory.Name if gs is not None else u""
    except Exception:
        nm = u""
    if k is not None:
        _ls_cache[k] = nm
    return nm


def list_cads(doc):
    out = {}
    for c in FilteredElementCollector(doc).OfClass(ImportInstance):
        try:
            t = doc.GetElement(c.GetTypeId())
            nm = u"{} ({})".format(name_of(t) if t else u"CAD",
                                   u"link" if c.IsLinked else u"import")
        except Exception:
            nm = u"CAD"
        out[u"{}  [id {}]".format(nm, eid_int(c.Id))] = c
    return out


def _ascii(s):
    s = unicodedata.normalize("NFD", u"{}".format(s or u""))
    s = u"".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    return s.replace(u"đ", u"d").replace(u"Đ", u"D").lower()


def guess_level_by_name(label, lv_names):
    """Đoán tầng từ tên file CAD (T1, Tang 2, Level 3, FL4, L5, 'mai'/'roof'...).
    So khớp theo SỐ trong tên level của project. Không đoán được -> None."""
    a = _ascii(label)
    m = re.search(r"(?<![a-z])(?:tang|level|lvl|lv|fl|floor|l|t)[\s_\-\.]*0*(\d{1,2})(?!\d)", a)
    if m:
        n = int(m.group(1))
        for nm in lv_names:
            mm = re.search(r"0*(\d{1,2})(?!\d)", _ascii(nm))
            if mm and int(mm.group(1)) == n:
                return nm
    if re.search(r"(?<![a-z])(?:mai|roof)(?![a-z])", a):
        for nm in lv_names:
            if re.search(r"(?<![a-z])(?:mai|roof)(?![a-z])", _ascii(nm)):
                return nm
    return None


def list_cads_info(doc, levels):
    """Mọi CAD link/import trong project, kèm tầng (level) của từng file.
    Tầng lấy theo thứ tự: Level đặt CAD trong Revit -> view chứa CAD (view riêng) ->
    đoán theo tên file. Trả list dict(label, obj, level, src) sắp theo cao độ level."""
    by_id = {}
    elev = {}
    for lv in levels:
        by_id[eid_int(lv.Id)] = lv.Name
        elev[lv.Name] = lv.Elevation
    names = [lv.Name for lv in levels]
    out = []
    for label, c in list_cads(doc).items():
        lvn, src = None, u""
        try:
            k = eid_int(c.LevelId)
            if k in by_id:
                lvn, src = by_id[k], u"Revit"
        except Exception:
            pass
        if lvn is None:
            try:
                v = doc.GetElement(c.OwnerViewId)
                gl = v.GenLevel if v is not None else None
                if gl is not None and eid_int(gl.Id) in by_id:
                    lvn, src = by_id[eid_int(gl.Id)], u"view"
            except Exception:
                pass
        if lvn is None:
            lvn = guess_level_by_name(label, names)
            src = u"tên file" if lvn else u""
        out.append({"label": label, "obj": c, "level": lvn, "src": src})
    out.sort(key=lambda d: (elev.get(d["level"], 1e12), d["label"].lower()))
    return out


def _xy(p):
    return (p.X * MM, p.Y * MM)


def _text_pos(g):
    for nm in ("Position", "Origin", "Coord", "Location"):
        try:
            p = getattr(g, nm)
            if p is not None and hasattr(p, "X"):
                return p
        except Exception:
            pass
    return None


def read_local(doc, gi, cap=4000):
    """Hình học bên trong block (toạ độ cục bộ, mm)."""
    segs, arcs, texts, layers = [], [], [], set()
    swing_ranges = []  # [(đầu, cuối)) các nét là mảnh của CUNG MỞ CÁNH (không tính vào thân block)

    def add_poly(pts):
        for a, b in zip(pts[:-1], pts[1:]):
            segs.append(_xy(a) + _xy(b))

    def walk(ge):
        for g in ge:
            if len(segs) > cap:
                return
            if isinstance(g, GeometryInstance):
                walk(g.GetInstanceGeometry())
                continue
            if TextNode is not None and isinstance(g, TextNode):
                try:
                    p = _text_pos(g)
                    if p is not None:
                        texts.append((u"{}".format(g.Text), p.X * MM, p.Y * MM))
                except Exception:
                    pass
                continue
            lay = None
            if isinstance(g, Line):
                segs.append(_xy(g.GetEndPoint(0)) + _xy(g.GetEndPoint(1)))
                lay = True
            elif isinstance(g, PolyLine):
                add_poly(list(g.GetCoordinates()))
                lay = True
            elif isinstance(g, Arc):
                c = g.Center
                try:
                    sweep = float(g.Length) / max(float(g.Radius), 1e-9)
                except Exception:
                    sweep = 0.0
                try:
                    mp = g.Evaluate(0.5, True)
                    arcs.append((c.X * MM, c.Y * MM, g.Radius * MM, mp.X * MM, mp.Y * MM, sweep))
                except Exception:
                    arcs.append((c.X * MM, c.Y * MM, g.Radius * MM, c.X * MM, c.Y * MM, sweep))
                n0 = len(segs)
                add_poly(list(g.Tessellate()))
                if _is_swing(g.Radius * MM, sweep):
                    swing_ranges.append((n0, len(segs)))
                lay = True
            elif isinstance(g, Curve):
                add_poly(list(g.Tessellate()))
                lay = True
            if lay:
                ly = layer_of(doc, g)
                if ly:
                    layers.add(ly)

    try:
        walk(gi.GetSymbolGeometry())
    except Exception:
        pass
    swmask = [False] * len(segs)
    for (i0, i1) in swing_ranges:
        for i in range(i0, min(i1, len(segs))):
            swmask[i] = True
    return {"segs": segs, "arcs": arcs, "texts": texts, "layers": layers, "swmask": swmask}


def _is_swing(r_mm, sweep):
    """Cung mở cánh: gần 1/4 vòng tròn (45°-108°), bán kính >= 300 mm."""
    return r_mm >= 300.0 and math.radians(45.0) <= sweep <= math.radians(108.0)


class Scan(object):
    def __init__(self):
        self.segs_by_layer = {}   # layer -> [(x0,y0,x1,y1)] toạ độ thế giới (mm)
        self.defs = {}            # tên block -> read_local + "fp"
        self.insts = []           # mỗi block: dict(name, layer, layers, tf)
        self.layers_blocks = {}   # layer -> số block


def block_key(g, idx):
    """Tên block; nếu không đọc được thì sinh khoá riêng để các block KHÔNG bị gộp nhầm."""
    nm = None
    try:
        nm = name_of(g.Symbol)
    except Exception:
        nm = None
    if not nm or nm == u"?":
        try:
            nm = u"Block#{}".format(eid_int(g.Symbol.Id))
        except Exception:
            nm = u"Block#{}".format(idx)
    return nm


def _tname(g):
    try:
        return g.GetType().Name
    except Exception:
        return type(g).__name__


def scan(doc, cad, nested, tol=2.0):
    opts = Options()
    opts.DetailLevel = ViewDetailLevel.Fine
    try:
        opts.IncludeNonVisibleObjects = True
    except Exception:
        pass
    sc = Scan()
    sc.stats = {}          # đếm loại hình học gặp phải (để chẩn đoán khi 0 block)

    def count(g, depth):
        k = u"{}@{}".format(_tname(g), depth)
        sc.stats[k] = sc.stats.get(k, 0) + 1

    def add_seg(layer, p, q):
        sc.segs_by_layer.setdefault(layer, []).append(_xy(p) + _xy(q))

    def add_inst(g, nm, tf):
        if nm not in sc.defs:
            d = read_local(doc, g)
            d["fp"] = G.fingerprint(d["segs"], tol)
            sc.defs[nm] = d
        lay = layer_of(doc, g)
        layers = set(sc.defs[nm]["layers"])
        if lay:
            layers.add(lay)
        sc.insts.append({
            "name": nm, "layer": lay, "layers": layers,
            "tf": (tf.Origin.X * MM, tf.Origin.Y * MM,
                   tf.BasisX.X, tf.BasisX.Y, tf.BasisY.X, tf.BasisY.Y)})
        for ly in layers:
            sc.layers_blocks[ly] = sc.layers_blocks.get(ly, 0) + 1

    def is_container(children):
        """Block bọc cả bản vẽ (chứa nhiều block con / hàng trăm nét) -> không tính là 1 block."""
        n_inst = n_cur = 0
        for c in children:
            if isinstance(c, GeometryInstance):
                n_inst += 1
            elif isinstance(c, (Line, PolyLine, Arc)):
                n_cur += 1
        return n_inst >= 3 or (n_inst >= 1 and n_cur >= 50)

    def walk(ge, depth=0):
        for g in ge:
            count(g, depth)
            if isinstance(g, GeometryInstance):
                try:
                    children = list(g.GetInstanceGeometry())
                except Exception:
                    children = []
                if depth < 6 and is_container(children):
                    sc.stats["container"] = sc.stats.get("container", 0) + 1
                    walk(children, depth + 1)       # đi xuyên qua lớp bọc
                    continue
                nm = block_key(g, len(sc.insts))
                add_inst(g, nm, g.Transform)
                if nested:
                    walk(children, depth + 1)
            elif isinstance(g, Line):
                add_seg(layer_of(doc, g), g.GetEndPoint(0), g.GetEndPoint(1))
            elif isinstance(g, PolyLine):
                pts = list(g.GetCoordinates())
                ly = layer_of(doc, g)
                for a, b in zip(pts[:-1], pts[1:]):
                    add_seg(ly, a, b)

    # --- Cách 1: hình học đã biến đổi (GetInstanceGeometry) ---
    for top in cad.get_Geometry(opts):
        count(top, -1)
        if isinstance(top, GeometryInstance):
            walk(top.GetInstanceGeometry(), 0)
        else:
            walk([top], 0)      # CAD không có lớp bọc ngoài

    # --- Cách 2 (dự phòng): đi theo GetSymbolGeometry, tự nhân ma trận ---
    if not sc.insts:
        sc.stats["fallback"] = 1

        def walk_sym(ge, parent_tf, depth=0):
            for g in ge:
                if isinstance(g, GeometryInstance):
                    nm = block_key(g, len(sc.insts))
                    tf = parent_tf.Multiply(g.Transform)
                    add_inst(g, nm, tf)
                    count(g, u"S{}".format(depth))
                    walk_sym(g.GetSymbolGeometry(), tf, depth + 1)

        try:
            for top in cad.get_Geometry(opts):
                if isinstance(top, GeometryInstance):
                    walk_sym(top.GetSymbolGeometry(), top.Transform)
        except Exception as ex:
            sc.stats["fallback_err"] = str(ex)
    return sc


def to_world(tf, x, y):
    return (tf[0] + tf[2] * x + tf[4] * y, tf[1] + tf[3] * x + tf[5] * y)


def inst_segs(sc, inst):
    d = sc.defs[inst["name"]]
    tf = inst["tf"]
    out = []
    for (x0, y0, x1, y1) in d["segs"]:
        a = to_world(tf, x0, y0)
        b = to_world(tf, x1, y1)
        out.append((a[0], a[1], b[0], b[1]))
    return out


def inst_texts(sc, inst):
    d = sc.defs[inst["name"]]
    tf = inst["tf"]
    out = []
    for (s, x, y) in d["texts"]:
        p = to_world(tf, x, y)
        out.append((s, p[0], p[1]))
    return out


def inst_arcs_full(sc, inst):
    """[(tâm x, tâm y, bán kính, giữa-cung x, giữa-cung y)] toạ độ thế giới (mm)."""
    d = sc.defs[inst["name"]]
    tf = inst["tf"]
    sx = math.hypot(tf[2], tf[3])
    out = []
    for a in d["arcs"]:
        x, y, r = a[0], a[1], a[2]
        mx, my = (a[3], a[4]) if len(a) >= 5 else (x, y)
        p = to_world(tf, x, y)
        m = to_world(tf, mx, my)
        out.append((p[0], p[1], r * sx, m[0], m[1]) + ((a[5],) if len(a) >= 6 else ()))
    return out


def inst_parts(sc, inst):
    """Chia hình block (thế giới, mm) cho nội thất: (thân, cung thường, cung mở cánh).
    thân: nét đã bỏ cung mở cánh + tay cánh + nét rời xa (dim, ghi chú);
    cung thường: [(x, y)] điểm giữa; cung mở cánh: [(x, y)] điểm giữa."""
    import b2r_furn as FU
    d = sc.defs[inst["name"]]
    segs = inst_segs(sc, inst)
    mask = d.get("swmask")
    tf = inst["tf"]
    sx = math.hypot(tf[2], tf[3])
    sw3, sw_mid, arcs_mid = [], [], []
    for a in d["arcs"]:
        if len(a) < 6:
            continue
        p = to_world(tf, a[0], a[1])
        m = to_world(tf, a[3], a[4])
        if _is_swing(a[2] * sx, a[5]):
            sw3.append((p[0], p[1], a[2] * sx))
            sw_mid.append(m)
        else:
            arcs_mid.append(m)
    body = FU.body_segs(segs, mask, sw3)
    return body, arcs_mid, sw_mid


def inst_bbox(sc, inst):
    """(minx, miny, maxx, maxy) mm của block (nét + cung), hoặc điểm gốc nếu rỗng."""
    segs = inst_segs(sc, inst)
    xs = [q[0] for q in segs] + [q[2] for q in segs]
    ys = [q[1] for q in segs] + [q[3] for q in segs]
    for a in inst_arcs_full(sc, inst):
        # cung mở cánh: lấy tâm + điểm giữa cung (đủ phủ vùng cửa, không lấy cả hình tròn)
        xs += [a[0], a[3]]
        ys += [a[1], a[4]]
    if not xs:
        return (inst["tf"][0], inst["tf"][1], inst["tf"][0], inst["tf"][1])
    return (min(xs), min(ys), max(xs), max(ys))


def inst_rot(tf):
    """(góc xoay rad quanh Z, có mirror?) theo quy ước: mirror = lật hand rồi xoay."""
    det = tf[2] * tf[5] - tf[3] * tf[4]
    if det < 0:
        return math.atan2(-tf[4], tf[5]), True
    return math.atan2(tf[3], tf[2]), False


def group_blocks(sc, merge=True):
    """Gộp block có cùng hình học (khác tên) thành 1 nhóm. merge=False: mỗi tên 1 dòng.
    Block không đọc được nét nào KHÔNG bao giờ bị gộp theo hình (gộp theo tên)."""
    groups = {}
    for ins in sc.insts:
        d = sc.defs[ins["name"]]
        fp = d["fp"]
        if (not merge) or (not d["segs"]) or fp == "empty":
            key = u"name:" + ins["name"]
        else:
            key = fp
        g = groups.setdefault(key, {"fp": key, "names": [], "insts": [],
                                    "layers": set(), "defn": d})
        if ins["name"] not in g["names"]:
            g["names"].append(ins["name"])
        g["insts"].append(ins)
        g["layers"] |= ins["layers"]
    out = list(groups.values())
    for g in out:
        g["names"].sort(key=lambda s: s.lower())
    out.sort(key=lambda g: g["names"][0].lower())
    return out
