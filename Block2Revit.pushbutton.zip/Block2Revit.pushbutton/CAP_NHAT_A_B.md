# Cập nhật đợt A+B (nội thất đặt đúng mặt trước + nhớ block giữa các tầng)

## Mới
- b2r_furn.py (file mới): nhận loại nội thất, tìm mặt trước, chữ ký hình "gần giống".
- Tab Nội thất: cột "Loại nội thất" (tự nhận, sửa được), "Co giãn theo block", "Lệch mặt trước (°)".
- Ô tick: "Đặt theo mặt trước", "Tự điền block giống từ tầng / lần trước".
- Dòng điền tự động theo kiểu GẦN GIỐNG được tô vàng; bấm Đặt = xác nhận và được nhớ.

## Cách đặt nội thất
1. Mặt trước block = lưng sát tường (tường Revit; không có thì nét tường CAD) + chi tiết:
   gối (giường), cung chữ/két (bồn cầu), cánh mở (tủ). Tab đầu giường theo hướng giường gần nhất.
2. Xoay family để FacingOrientation trùng mặt trước block. Family lệch quy ước -> sửa cột
   "Lệch mặt trước (°)" một lần (vd 180), tool nhớ cho family đó.
3. Co giãn: kéo sâu/rộng theo thân block (không tính cung mở cánh). Không kéo được -> đặt ở tim.
4. Căn tâm bằng hình khối Solid của family (bỏ nét symbolic / clearance).
5. Không biết mặt trước (đồ đối xứng) hoặc lỗi -> rơi về cách khớp hình cũ.
