# -*- coding: utf-8 -*-
"""Cầu nối ExternalEvent: cho phép form MODELESS (vừa dùng tool vừa thao tác model Revit)
vẫn gọi được Revit API. Mọi thao tác chạm API được xếp hàng rồi chạy trong Execute() của
ExternalEvent (API context hợp lệ)."""
import time
import traceback
from collections import deque
import b2r_ui as UI

_Q = deque()
_S = {"event": None, "handler": None, "hwnd": 0, "err": u""}


def _drain(uiapp):
    while _Q:
        job = _Q.popleft()
        UI.CTX["api"] = True
        try:
            job()
        except Exception as ex:
            UI.log(traceback.format_exc())
            try:
                UI.alert(u"Lỗi khi thao tác với Revit:\n{}".format(ex))
            except Exception:
                pass
        finally:
            UI.CTX["api"] = False


def _emit_handler():
    """Dự phòng: tự sinh lớp .NET implement IExternalEventHandler (Reflection.Emit),
    gọi về 1 delegate Action<UIApplication> do Python cung cấp."""
    import clr
    import System
    from System import Array, Type
    from System.Reflection import AssemblyName, MethodAttributes, TypeAttributes, FieldAttributes
    from System.Reflection.Emit import AssemblyBuilder, AssemblyBuilderAccess, OpCodes
    from Autodesk.Revit.UI import IExternalEventHandler, UIApplication
    t_if = clr.GetClrType(IExternalEventHandler)
    t_act = clr.GetClrType(System.Action[UIApplication])
    asm = AssemblyBuilder.DefineDynamicAssembly(
        AssemblyName("B2REvt{}".format(int(time.time()))), AssemblyBuilderAccess.Run)
    mod = asm.DefineDynamicModule("B2REvtMod")
    tb = mod.DefineType("B2REventHandler", TypeAttributes.Public, clr.GetClrType(System.Object),
                        Array[Type]([t_if]))
    fld = tb.DefineField("act", t_act, FieldAttributes.Public)
    tb.DefineDefaultConstructor(MethodAttributes.Public)
    attrs = (MethodAttributes.Public | MethodAttributes.Virtual | MethodAttributes.HideBySig
             | MethodAttributes.NewSlot | MethodAttributes.Final)
    m1 = tb.DefineMethod("Execute", attrs, clr.GetClrType(System.Void),
                         Array[Type]([clr.GetClrType(UIApplication)]))
    il = m1.GetILGenerator()
    il.Emit(OpCodes.Ldarg_0)
    il.Emit(OpCodes.Ldfld, fld)
    il.Emit(OpCodes.Ldarg_1)
    il.Emit(OpCodes.Callvirt, t_act.GetMethod("Invoke"))
    il.Emit(OpCodes.Ret)
    tb.DefineMethodOverride(m1, t_if.GetMethod("Execute"))
    m2 = tb.DefineMethod("GetName", attrs, clr.GetClrType(System.String), Type.EmptyTypes)
    il2 = m2.GetILGenerator()
    il2.Emit(OpCodes.Ldstr, "Block2Revit")
    il2.Emit(OpCodes.Ret)
    tb.DefineMethodOverride(m2, t_if.GetMethod("GetName"))
    t = tb.CreateType()
    obj = System.Activator.CreateInstance(t)
    t.GetField("act").SetValue(obj, System.Action[UIApplication](_drain))
    return obj


def init(uiapp):
    """Gọi 1 lần trong API context (lúc bấm nút lệnh). Trả True nếu tạo được ExternalEvent."""
    from Autodesk.Revit.UI import IExternalEventHandler, ExternalEvent
    errs = []
    ev = None
    ns = "Block2RevitEvt{}".format(int(time.time() * 1000))
    try:
        class _H(IExternalEventHandler):
            __namespace__ = ns

            def Execute(self, app):
                _drain(app)

            def GetName(self):
                return "Block2Revit"
        h = _H()
        ev = ExternalEvent.Create(h)
        _S["handler"] = h
    except Exception as ex:
        errs.append(u"python-interface: {}".format(ex))
        ev = None
    if ev is None:
        try:
            h = _emit_handler()
            ev = ExternalEvent.Create(h)
            _S["handler"] = h
        except Exception as ex:
            errs.append(u"reflection-emit: {}".format(ex))
            ev = None
    _S["event"] = ev
    _S["err"] = u"; ".join(errs)
    if ev is None:
        UI.CTX["api"] = True     # chế độ modal: luôn nằm trong API context của lệnh
    try:
        _S["hwnd"] = int(uiapp.MainWindowHandle.ToInt64())
    except Exception:
        _S["hwnd"] = 0
    return ev is not None


def ready():
    return _S["event"] is not None


def error():
    return _S["err"]


def main_hwnd():
    return _S["hwnd"]


def _wake():
    """Đánh thức message loop của Revit để ExternalEvent chạy ngay (không chờ rê chuột)."""
    try:
        import ctypes
        if _S["hwnd"]:
            ctypes.windll.user32.PostMessageW(ctypes.c_void_p(_S["hwnd"]), 0, 0, 0)
    except Exception:
        pass


def post(job):
    """Xếp job() (không tham số) để chạy trong API context của Revit."""
    ev = _S["event"]
    if ev is None:
        # không có ExternalEvent (form chạy kiểu modal trong chính lệnh) -> chạy thẳng
        job()
        return
    _Q.append(job)
    ev.Raise()
    _wake()


def api(fn):
    """Decorator cho event handler của form: thân hàm chạy trong API context."""
    def handler(*a):
        post(lambda: fn(*a))
    handler.raw = fn      # gọi thẳng khi đã đang ở API context (chạy hàng loạt nhiều tầng)
    return handler


def dispose():
    try:
        if _S["event"] is not None:
            _S["event"].Dispose()
    except Exception:
        pass
    _S["event"] = None
    _Q.clear()
