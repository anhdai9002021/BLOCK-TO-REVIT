# -*- coding: utf-8 -*-
"""Hình học thuần (đơn vị mm) - không phụ thuộc Revit.
- fingerprint(): dấu vân tay hình học của block (nhận ra block giống nhau khác tên)
- analyze_stair(): đọc block thang (số bậc, bề rộng, chiều dài, hướng lên)
- min_area_rect() / wrap90(): hình chữ nhật bao nhỏ nhất, chuẩn hoá góc (căn hướng nội thất)
"""
import math
import hashlib
from collections import defaultdict

BW = math.radians(1.0)
NB = int(round(math.pi / BW))


# ---------------------------------------------------------------- đoạn thẳng
class Seg(object):
    __slots__ = ("x0", "y0", "x1", "y1", "ux", "uy", "L", "mx", "my", "ang", "k")

    def __init__(self, x0, y0, x1, y1):
        dx = x1 - x0
        dy = y1 - y0
        L = math.hypot(dx, dy)
        ux = dx / L
        uy = dy / L
        if uy < -1e-9 or (abs(uy) <= 1e-9 and ux < 0):
            x0, y0, x1, y1 = x1, y1, x0, y0
            ux, uy = -ux, -uy
        self.x0, self.y0, self.x1, self.y1 = x0, y0, x1, y1
        self.ux, self.uy, self.L = ux, uy, L
        self.mx = (x0 + x1) / 2.0
        self.my = (y0 + y1) / 2.0
        self.ang = math.atan2(uy, ux)
        self.k = int(math.floor(self.ang / BW)) % NB


# ---------------------------------------------------------------- vân tay block
def fingerprint(segs, tol=2.0):
    if not segs:
        return "empty"
    minx = min(min(s[0], s[2]) for s in segs)
    miny = min(min(s[1], s[3]) for s in segs)
    items = set()
    for (x0, y0, x1, y1) in segs:
        a = (int(round((x0 - minx) / tol)), int(round((y0 - miny) / tol)))
        b = (int(round((x1 - minx) / tol)), int(round((y1 - miny) / tol)))
        if a == b:
            continue
        if a > b:
            a, b = b, a
        items.add((a, b))
    items = sorted(items)
    h = hashlib.md5(repr(items).encode("utf-8")).hexdigest()
    return "{}-{}".format(len(items), h)


# ---------------------------------------------------------------- thang
def analyze_stair(segs, texts=None):
    """segs: [(x0,y0,x1,y1)] toạ độ thế giới (mm); texts: [(chuỗi, x, y)].
    Trả về dict: ok, width, length, risers (số đường bậc), n_text, start, end,
    dir (hướng đi lên), src (nguồn hướng), multi (thang nhiều vế)."""
    res = {"ok": False, "reason": u""}
    S = [Seg(r[0], r[1], r[2], r[3]) for r in segs
         if math.hypot(r[2] - r[0], r[3] - r[1]) >= 1.0]
    if len(S) < 4:
        res["reason"] = u"block có quá ít nét"
        return res
    cnt = defaultdict(int)
    for s in S:
        if s.L >= 200.0:
            cnt[s.k] += 1
    if not cnt:
        res["reason"] = u"không có nét đủ dài"
        return res
    bestk = max(range(NB), key=lambda k: cnt.get((k - 1) % NB, 0) + cnt.get(k, 0)
                + cnt.get((k + 1) % NB, 0))
    grp = [s for s in S if s.k in (bestk, (bestk - 1) % NB, (bestk + 1) % NB)]
    ref = None
    sx = sy = 0.0
    for s in grp:
        ux, uy = s.ux, s.uy
        if ref is None:
            ref = (ux, uy)
        if ux * ref[0] + uy * ref[1] < 0:
            ux, uy = -ux, -uy
        sx += ux * s.L
        sy += uy * s.L
    nrm = math.hypot(sx, sy)
    if nrm < 1e-9:
        res["reason"] = u"không xác định được hướng bậc"
        return res
    tx, ty = sx / nrm, sy / nrm
    rx, ry = -ty, tx
    T = [s for s in S if abs(s.ux * ty - s.uy * tx) <= 0.05]
    maxlen = max(s.L for s in T)
    T = [s for s in T if s.L >= 0.45 * maxlen]
    rows = []
    for s in T:
        o = s.mx * rx + s.my * ry
        t0 = s.x0 * tx + s.y0 * ty
        t1 = s.x1 * tx + s.y1 * ty
        rows.append((o, min(t0, t1), max(t0, t1)))
    rows.sort()
    cl = []
    for o, a, b in rows:
        if cl and o - cl[-1][0] / cl[-1][1] <= 30.0:
            c = cl[-1]
            c[0] += o
            c[1] += 1
            c[2] = min(c[2], a)
            c[3] = max(c[3], b)
        else:
            cl.append([o, 1, a, b])
    def _med(v):
        v = sorted(v)
        n = len(v)
        return v[n // 2] if n % 2 else (v[n // 2 - 1] + v[n // 2]) / 2.0
    # loại nét lạ: vạch dài/ngắn bất thường so với số đông (tay vịn, đường kích thước, nét cắt...)
    med_w = _med([c[3] - c[2] for c in cl])
    keep = [c for c in cl if 0.7 * med_w <= (c[3] - c[2]) <= 1.3 * med_w]
    if len(keep) >= 3:
        cl = keep
    # cắt bớt đầu/đuôi cách quá xa nhịp bậc (chiếu nghỉ, nét ngoài)
    for _i in range(4):
        if len(cl) < 4:
            break
        oo = [c[0] / c[1] for c in cl]
        gp = [oo[i + 1] - oo[i] for i in range(len(oo) - 1)]
        mg = _med(gp)
        if mg <= 0:
            break
        if gp[0] > 1.6 * mg:
            cl = cl[1:]
        elif gp[-1] > 1.6 * mg:
            cl = cl[:-1]
        else:
            break
    m = len(cl)
    if m < 3:
        res["reason"] = u"chỉ thấy {} đường bậc".format(m)
        return res
    o_list = [c[0] / c[1] for c in cl]
    width = _med([c[3] - c[2] for c in cl])
    tc = _med([(c[2] + c[3]) / 2.0 for c in cl])
    length = o_list[-1] - o_list[0]

    # thang nhiều vế: có nhiều nét bậc thứ hai vuông góc
    other = []
    for s in S:
        if abs(s.ux * tx + s.uy * ty) <= 0.05 and 0.4 * width <= s.L <= 1.4 * width \
                and s.L < 0.7 * max(length, 1.0):
            other.append(s.mx * tx + s.my * ty)
    other.sort()
    oc = 0
    last = None
    for v in other:
        if last is None or v - last > 30.0:
            oc += 1
        last = v
    multi = oc >= 3

    up = 0
    src = u"chưa rõ"
    nums = []
    for tt in (texts or []):
        s2 = tt[0].strip()
        if s2.isdigit() and len(s2) <= 3:
            nums.append((int(s2), tt[1] * rx + tt[2] * ry))
    n_text = max([n for n, _ in nums]) if nums else 0
    if len(nums) >= 3:
        mn = sum(n for n, _ in nums) / float(len(nums))
        mo = sum(o for _, o in nums) / float(len(nums))
        cov = sum((n - mn) * (o - mo) for n, o in nums)
        if abs(cov) > 1e-6:
            up = 1 if cov > 0 else -1
            src = u"chữ số"
    if up == 0:
        cands = [s for s in S if abs(s.ux * tx + s.uy * ty) <= 0.05
                 and s.L >= 0.3 * length
                 and abs((s.mx * tx + s.my * ty) - tc) <= 0.3 * width]
        if cands:
            sh = max(cands, key=lambda s: s.L)
            ends = [(sh.x0, sh.y0), (sh.x1, sh.y1)]
            rad = max(0.15 * sh.L, 80.0)
            sc = []
            for (ex, ey) in ends:
                c = 0
                for s in S:
                    if s is sh or s.L > 0.3 * sh.L:
                        continue
                    if math.hypot(s.x0 - ex, s.y0 - ey) <= rad or \
                            math.hypot(s.x1 - ex, s.y1 - ey) <= rad:
                        c += 1
                sc.append(c)
            if sc[0] != sc[1]:
                head, tail = (ends[0], ends[1]) if sc[0] > sc[1] else (ends[1], ends[0])
                d = (head[0] - tail[0]) * rx + (head[1] - tail[1]) * ry
                if abs(d) > 1e-6:
                    up = 1 if d > 0 else -1
                    src = u"mũi tên"
    if up == 0:
        up = 1
    o_lo, o_hi = (o_list[0], o_list[-1]) if up > 0 else (o_list[-1], o_list[0])
    start = (tx * tc + rx * o_lo, ty * tc + ry * o_lo)
    end = (tx * tc + rx * o_hi, ty * tc + ry * o_hi)
    res.update({"ok": True, "width": width, "length": length, "risers": m,
                "n_text": n_text, "start": start, "end": end,
                "dir": (rx * up, ry * up), "src": src, "multi": multi})
    return res


# ---------------------------------------------------------------- thang nhiều vế
def _dominant_axis(S):
    """Góc chủ đạo (mod 90 độ) của các nét dài."""
    hist = defaultdict(float)
    for s in S:
        if s.L < 200.0:
            continue
        a = math.atan2(s.uy, s.ux) % (math.pi / 2.0)
        hist[int(round(math.degrees(a)))] += s.L
    if not hist:
        return 0.0
    best = max(hist, key=lambda k: hist[k] + hist.get((k + 1) % 90, 0) + hist.get((k - 1) % 90, 0))
    return math.radians(best)


def analyze_stair_multi(segs, texts=None, tread_min=120.0, tread_max=450.0):
    """Tách thang nhiều vế (L, U, 3 vế, 4 vế...) thành các vế thẳng.
    Trả về dict: ok, reason, runs=[{start,end,width,length,risers}] theo thứ tự đi lên,
    src (nguồn thứ tự/hướng), n_text."""
    res = {"ok": False, "reason": u"", "runs": [], "src": u"chưa rõ", "n_text": 0}
    S = [Seg(r[0], r[1], r[2], r[3]) for r in segs
         if math.hypot(r[2] - r[0], r[3] - r[1]) >= 1.0]
    if len(S) < 6:
        res["reason"] = u"block có quá ít nét"
        return res
    th = _dominant_axis(S)
    axes = [(math.cos(th), math.sin(th)), (-math.sin(th), math.cos(th))]

    # --- 1) gom nét bậc thành "hàng" cho từng trục
    rows = []   # dict(ax, o, p0, p1)
    for ai, (fx, fy) in enumerate(axes):
        nx, ny = -fy, fx            # phương đi của vế (vuông góc nét bậc)
        for s in S:
            if abs(s.ux * fy - s.uy * fx) > 0.05:
                continue
            if s.L < 500.0 or s.L > 2600.0:
                continue
            o = s.mx * nx + s.my * ny
            ta = s.x0 * fx + s.y0 * fy
            tb = s.x1 * fx + s.y1 * fy
            p0, p1 = min(ta, tb), max(ta, tb)
            for r in rows:
                if r["ax"] != ai or abs(r["o"] - o) > 30.0:
                    continue
                ov = min(r["p1"], p1) - max(r["p0"], p0)
                if ov >= 0.3 * min(r["p1"] - r["p0"], p1 - p0):
                    r["p0"] = min(r["p0"], p0)
                    r["p1"] = max(r["p1"], p1)
                    break
            else:
                rows.append({"ax": ai, "o": o, "p0": p0, "p1": p1})
    if len(rows) < 3:
        res["reason"] = u"không đủ đường bậc"
        return res

    # --- 2) nối các hàng kề nhau (cách tread_min..tread_max, trùng nhau theo bề rộng)
    n = len(rows)
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for i in range(n):
        for j in range(i + 1, n):
            a, b = rows[i], rows[j]
            if a["ax"] != b["ax"]:
                continue
            d = abs(a["o"] - b["o"])
            if d < tread_min or d > tread_max:
                continue
            wa, wb = a["p1"] - a["p0"], b["p1"] - b["p0"]
            ov = min(a["p1"], b["p1"]) - max(a["p0"], b["p0"])
            if ov >= 0.7 * min(wa, wb) and abs(wa - wb) <= 0.3 * max(wa, wb):
                parent[find(i)] = find(j)
    comps = defaultdict(list)
    for i in range(n):
        comps[find(i)].append(rows[i])
    flights = []
    for mem in comps.values():
        if len(mem) < 3:
            continue
        mem.sort(key=lambda r: r["o"])
        ai = mem[0]["ax"]
        fx, fy = axes[ai]
        nx, ny = -fy, fx
        # bề rộng = số đông (median), KHÔNG lấy max: 1 nét thừa dài hơn làm cả vế bị rộng ra
        _ws = sorted(r["p1"] - r["p0"] for r in mem)
        wid = _ws[len(_ws) // 2]
        wr = min(mem, key=lambda r: abs((r["p1"] - r["p0"]) - wid))
        pc = (wr["p0"] + wr["p1"]) / 2.0
        o_lo, o_hi = mem[0]["o"], mem[-1]["o"]
        a_pt = (fx * pc + nx * o_lo, fy * pc + ny * o_lo)
        b_pt = (fx * pc + nx * o_hi, fy * pc + ny * o_hi)
        flights.append({"ax": ai, "fx": fx, "fy": fy, "nx": nx, "ny": ny,
                        "width": wid, "length": o_hi - o_lo, "risers": len(mem),
                        "a": a_pt, "b": b_pt, "pc": pc, "o_lo": o_lo, "o_hi": o_hi,
                        "p0": min(r["p0"] for r in mem), "p1": max(r["p1"] for r in mem)})
    if not flights:
        res["reason"] = u"không tách được vế nào"
        return res

    # --- 3) thứ tự & hướng: ưu tiên chữ số, nếu không thì theo chuỗi liền kề
    nums = []
    for tt in (texts or []):
        s2 = tt[0].strip()
        if s2.isdigit() and len(s2) <= 3:
            nums.append((int(s2), tt[1], tt[2]))
    res["n_text"] = max([x[0] for x in nums]) if nums else 0
    for f in flights:
        f["nums"] = []
    for (v, x, y) in nums:
        for f in flights:
            p = x * f["fx"] + y * f["fy"]
            o = x * f["nx"] + y * f["ny"]
            if f["p0"] - 60 <= p <= f["p1"] + 60 and f["o_lo"] - 200 <= o <= f["o_hi"] + 200:
                f["nums"].append((v, o))
                break
    ordered = None
    if all(len(f["nums"]) >= 2 for f in flights):
        ordered = sorted(flights, key=lambda f: min(v for v, _ in f["nums"]))
        for f in ordered:
            mn = sum(v for v, _ in f["nums"]) / float(len(f["nums"]))
            mo = sum(o for _, o in f["nums"]) / float(len(f["nums"]))
            cov = sum((v - mn) * (o - mo) for v, o in f["nums"])
            if cov >= 0:
                f["start"], f["end"] = f["a"], f["b"]
            else:
                f["start"], f["end"] = f["b"], f["a"]
        res["src"] = u"chữ số"
    if ordered is None:
        # chuỗi liền kề: nối đầu-cuối gần nhau nhất
        def dist(p, q):
            return math.hypot(p[0] - q[0], p[1] - q[1])
        pool = list(flights)
        reach = 2.2 * max(f["width"] for f in flights) + 600.0

        def nbrs(f):
            c = 0
            for g in pool:
                if g is f:
                    continue
                if min(dist(f["a"], g["a"]), dist(f["a"], g["b"]),
                       dist(f["b"], g["a"]), dist(f["b"], g["b"])) <= reach:
                    c += 1
            return c
        ends = [f for f in pool if nbrs(f) <= 1] or pool
        first = min(ends, key=lambda f: (round(f["a"][1] / 500.0), f["a"][0]))
        seq = [first]
        left = [f for f in pool if f is not first]
        while left:
            last = seq[-1]
            best = None
            for g in left:
                d = min(dist(last["a"], g["a"]), dist(last["a"], g["b"]),
                        dist(last["b"], g["a"]), dist(last["b"], g["b"]))
                if best is None or d < best[0]:
                    best = (d, g)
            seq.append(best[1])
            left.remove(best[1])
        if len(seq) >= 2:
            f0, f1 = seq[0], seq[1]
            dA = min(dist(f0["a"], f1["a"]), dist(f0["a"], f1["b"]))
            dB = min(dist(f0["b"], f1["a"]), dist(f0["b"], f1["b"]))
            if dA < dB:
                f0["start"], f0["end"] = f0["b"], f0["a"]
            else:
                f0["start"], f0["end"] = f0["a"], f0["b"]
        else:
            seq[0]["start"], seq[0]["end"] = seq[0]["a"], seq[0]["b"]
        for k in range(1, len(seq)):
            prev, f = seq[k - 1], seq[k]
            da = dist(prev["end"], f["a"])
            db = dist(prev["end"], f["b"])
            if da <= db:
                f["start"], f["end"] = f["a"], f["b"]
            else:
                f["start"], f["end"] = f["b"], f["a"]
        ordered = seq
        res["src"] = u"chuỗi vế (kiểm tra / Đảo hướng)"
    res["runs"] = [{"start": f["start"], "end": f["end"], "width": f["width"],
                    "length": f["length"], "risers": f["risers"]} for f in ordered]
    res["ok"] = True
    return res


# ---------------------------------------------------------------- ăn theo lưới trục (Grid)


# ---------------------------------------------------------------- hình chữ nhật bao
def _hull(points):
    pts = sorted(set((round(p[0], 3), round(p[1], 3)) for p in points))
    if len(pts) <= 2:
        return pts

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo = []
    for p in pts:
        while len(lo) >= 2 and cross(lo[-2], lo[-1], p) <= 0:
            lo.pop()
        lo.append(p)
    up = []
    for p in reversed(pts):
        while len(up) >= 2 and cross(up[-2], up[-1], p) <= 0:
            up.pop()
        up.append(p)
    return lo[:-1] + up[:-1]


def wrap90(a):
    """Đưa góc về [-45°, 45°)."""
    q = math.pi / 2.0
    return (a + q / 2.0) % q - q / 2.0


def min_area_rect(points):
    """Hình chữ nhật bao nhỏ nhất. Trả (cx, cy, a, b, th): a dọc theo góc th (rad), b vuông góc.
    None nếu không đủ điểm."""
    H = _hull(points)
    if len(H) < 2:
        return None
    best = None
    n = len(H)
    for i in range(n):
        x0, y0 = H[i]
        x1, y1 = H[(i + 1) % n]
        if math.hypot(x1 - x0, y1 - y0) < 1e-6:
            continue
        th = math.atan2(y1 - y0, x1 - x0)
        c, s = math.cos(th), math.sin(th)
        us = [p[0] * c + p[1] * s for p in H]
        vs = [-p[0] * s + p[1] * c for p in H]
        a = max(us) - min(us)
        b = max(vs) - min(vs)
        area = a * b
        if best is None or area < best[0] - 1e-6:
            best = (area, th, a, b, (max(us) + min(us)) / 2.0, (max(vs) + min(vs)) / 2.0)
    if best is None:
        return None
    _ar, th, a, b, mu, mv = best
    c, s = math.cos(th), math.sin(th)
    return (mu * c - mv * s, mu * s + mv * c, a, b, th)
