# -*- coding: utf-8 -*-
"""Bộ chọn family kiểu thư viện (viết lại):
  - Lưới ô có ảnh: 3 cỡ ô (Nhỏ / Vừa / Lớn) để xem được nhiều family cùng lúc; Ctrl + cuộn chuột đổi cỡ.
  - Nhóm theo family (có tiêu đề từng nhóm) hoặc dàn phẳng; chế độ Danh sách.
  - Ảnh nạp dần cho các ô đang nhìn thấy (không đứng hình), ô chưa có ảnh hiện khung chờ.
  - Cuộn mượt (hết 'lướt như gió'), ↑ ↓ ← → chọn theo vị trí ô, Enter xác nhận, Esc huỷ.
  - Vẽ lỗi sẽ ghi traceback đầy đủ vào Block2Revit.log."""
import traceback
from System.Reflection import BindingFlags
import b2r_ui as UI
import b2r_layout as LY
from b2r_ui import WF, Size, Rectangle, SolidBrush, Pen, T, font
from System.Drawing import StringFormat, StringAlignment, StringTrimming, StringFormatFlags, RectangleF
from System.Drawing.Text import TextRenderingHint
from System.Drawing.Drawing2D import SmoothingMode, InterpolationMode

KIND_TXT = {"level": u"Theo level", "door": u"Cửa đi", "window": u"Cửa sổ",
            "column": u"Cột kết cấu", "wall": u"Treo tường"}
GAP, PAD = 10, 14
LIST_H = 60
SIZES = (192, 128, 96, 72)          # các cỡ ảnh có thể đã có trong cache (lớn -> nhỏ)
DENS_TXT = {"S": u"Nhỏ", "M": u"Vừa", "L": u"Lớn"}


def _dbuf(c):
    try:
        pi = c.GetType().GetProperty("DoubleBuffered",
                                     BindingFlags.NonPublic | BindingFlags.Instance)
        pi.SetValue(c, True, None)
    except Exception:
        pass


def _badge_colors(kind):
    dark = UI.STATE["dark"]
    if kind == "window":
        return ((UI._c("#1E3A2D"), UI._c("#4ADE9A")) if dark
                else (UI._c("#DDF4E6"), UI._c("#15803D")))
    return ((UI._c("#243A63"), UI._c("#8FB8FF")) if dark
            else (UI._c("#E3ECFE"), UI._c("#1D4FD0")))


def _txt(g, text, fnt, x, y, w, h, color, align=0, wrap=False):
    """Vẽ chữ bằng Graphics.DrawString (không dùng TextFormatFlags -> tránh lỗi enum|int)."""
    sf = StringFormat()
    try:
        sf.Alignment = (StringAlignment.Center if align == 1 else
                        (StringAlignment.Far if align == 2 else StringAlignment.Near))
        sf.LineAlignment = StringAlignment.Near if wrap else StringAlignment.Center
        sf.Trimming = StringTrimming.EllipsisCharacter
        if not wrap:
            sf.FormatFlags = StringFormatFlags.NoWrap
        br = SolidBrush(color)
        try:
            g.DrawString(text, fnt, br, RectangleF(float(x), float(y), float(w), float(h)), sf)
        finally:
            br.Dispose()
    finally:
        sf.Dispose()


def _ctrl_down():
    try:
        return (int(WF.Control.ModifierKeys) & int(WF.Keys.Control)) != 0
    except Exception:
        return False


def pick_family(symbols, title=u"Chọn family", kind_filter=u"all", initial=u"", current=None):
    """symbols: {'Family : Type': (symbol, kind)}. Trả 'Family : Type' hoặc None."""
    t = T()
    items = []
    for key, (sym, kind) in symbols.items():
        fam, _s, typ = key.partition(u" : ")
        items.append((key, fam, typ or fam, kind, sym))
    items.sort(key=lambda x: x[0].lower())
    fam_total = {}
    for it in items:
        fam_total[it[1]] = fam_total.get(it[1], 0) + 1
    kinds_present = set(it[3] for it in items)
    two = ("door" in kinds_present) and ("window" in kinds_present)

    sw, sh = UI.work_area()
    f = UI.new_dialog(title, min(1180, sw - 60), min(780, sh - 80), True)
    f.MinimumSize = Size(820, 520)
    dens0 = UI.SET.get("pk_dens", "M")
    st = {"vis": [], "sel": -1, "hover": -1,
          "mode": UI.SET.get("pk_mode", "grid") if UI.SET.get("pk_mode") in ("grid", "list") else "grid",
          "dens": dens0 if dens0 in LY.DENS else "M",
          "group": bool(UI.SET.get("pk_group", True)),
          "kind": kind_filter if kind_filter in ("door", "window") else "all",
          "lay": {"rects": {}, "heads": [], "content": 0, "cols": 1, "tw": 100, "th": 100, "step": 100},
          "cur": 0.0, "tgt": 0.0, "busy": False, "failed": set(), "errn": 0, "grouped": False}

    def log_err(tag):
        if st["errn"] < 6:
            st["errn"] += 1
            UI.log(u"picker {} lỗi:\n{}".format(tag, traceback.format_exc()))

    # ------------------------------------------------ thanh trên (2 hàng)
    top = UI.panel(WF.DockStyle.Top, 100, "toolbar")
    tb = UI.txt(16, 12, 400)
    tb.Font = font(11)
    top.Controls.Add(tb)
    lb_n = UI.lbl(u"", 0, 18, "sub")
    top.Controls.Add(lb_n)
    chips = {}
    if two:
        for k, lab in (("all", u"Tất cả"), ("door", u"Cửa đi"), ("window", u"Cửa sổ")):
            b = UI.btn(lab, 0, 54, 92, 32, "chip")
            chips[k] = b
            top.Controls.Add(b)
    b_grp = UI.btn(u"▤  Nhóm", 0, 54, 96, 32, "chip")
    dbtn = {}
    for d in LY.DENS_ORDER:
        dbtn[d] = UI.btn(DENS_TXT[d], 0, 54, 62, 32, "chip")
        top.Controls.Add(dbtn[d])
    b_grid = UI.btn(u"▦  Lưới", 0, 54, 88, 32, "chip")
    b_list = UI.btn(u"☰  Danh sách", 0, 54, 122, 32, "chip")
    for c in (b_grp, b_grid, b_list):
        top.Controls.Add(c)

    def lay_top(s=None, e=None):
        W = top.ClientSize.Width
        lb_n.Left = max(16, W - 16 - lb_n.PreferredSize.Width)
        tb.Width = max(160, min(520, lb_n.Left - 32))
        x = W - 16 - b_list.Width
        b_list.Left = x
        x -= 6 + b_grid.Width
        b_grid.Left = x
        x -= 18
        for d in reversed(LY.DENS_ORDER):
            x -= dbtn[d].Width
            dbtn[d].Left = x
            x -= 4
        x -= 14 + b_grp.Width
        b_grp.Left = x
        cx = 16
        for k in ("all", "door", "window"):
            if k in chips:
                chips[k].Left = cx
                cx += chips[k].Width + 6
    top.SizeChanged += lay_top

    # ------------------------------------------------ khung xem trước bên phải
    side = UI.panel(WF.DockStyle.Right, 300, "card")
    pic = WF.PictureBox()
    pic.SetBounds(20, 20, 260, 230)
    pic.SizeMode = WF.PictureBoxSizeMode.Zoom
    pic.BorderStyle = WF.BorderStyle.FixedSingle
    l_typ = UI.lbl(u"", 20, 262, "h2")
    l_fam = UI.lbl(u"", 20, 310, "sub")
    l_kind = UI.lbl(u"", 20, 356, "ok")
    l_hint = UI.lbl(u"", 20, 390, "sub")
    for c in (l_typ, l_fam, l_kind, l_hint):
        c.AutoSize = False
        side.Controls.Add(c)
    l_typ.SetBounds(20, 260, 260, 46)
    l_fam.SetBounds(20, 308, 260, 44)
    l_kind.SetBounds(20, 354, 260, 24)
    l_hint.SetBounds(20, 384, 260, 90)
    side.Controls.Add(pic)

    # ------------------------------------------------ thanh dưới
    bottom = UI.panel(WF.DockStyle.Bottom, 62, "bottom")
    ok = UI.btn(u"Chọn family", 0, 14, 140, 36, "primary")
    ok.DialogResult = WF.DialogResult.OK
    cancel = UI.btn(u"Hủy", 0, 14, 100, 36)
    cancel.DialogResult = WF.DialogResult.Cancel
    hint = UI.lbl(u"Gõ để tìm  ·  ↑ ↓ ← → chọn  ·  Enter xác nhận  ·  bấm đúp để chọn nhanh  ·  "
                  u"Ctrl + cuộn chuột: đổi cỡ ô", 16, 22, "sub")
    for c in (ok, cancel, hint):
        bottom.Controls.Add(c)
    UI.pin_right(bottom, cancel, 16)
    UI.pin_right(bottom, ok, 124)

    # ------------------------------------------------ vùng thẻ (tự vẽ + cuộn)
    host = UI.panel(WF.DockStyle.Fill)
    canvas = WF.Panel()
    canvas.Dock = WF.DockStyle.Fill
    _dbuf(canvas)
    vs = WF.VScrollBar()
    vs.Dock = WF.DockStyle.Right
    host.Controls.Add(canvas)
    host.Controls.Add(vs)

    f.Controls.Add(host)
    f.Controls.Add(side)
    f.Controls.Add(top)
    f.Controls.Add(bottom)
    f.AcceptButton = ok
    f.CancelButton = cancel

    # ------------------------------------------------ bố cục + cuộn
    def view_h():
        return max(canvas.ClientSize.Height, 50)

    def max_scroll():
        return max(0, int(st["lay"]["content"]) - view_h())

    def sync_scroll():
        ch = view_h()
        content = max(int(st["lay"]["content"]), ch)
        st["busy"] = True
        try:
            vs.Minimum = 0
            vs.SmallChange = 40
            vs.LargeChange = ch
            vs.Maximum = max(content - 1, 0)
            vs.Enabled = content > ch
            mx = max_scroll()
            st["tgt"] = max(0.0, min(float(mx), st["tgt"]))
            st["cur"] = max(0.0, min(float(mx), st["cur"]))
            vs.Value = int(round(st["cur"]))
        except Exception:
            log_err(u"sync_scroll")
        finally:
            st["busy"] = False

    def relayout():
        try:
            vis = st["vis"]
            fams = [items[i][1] for i in vis]
            grouped = bool(st["group"] and not UI.norm(tb.Text).strip() and st["mode"] == "grid")
            st["grouped"] = grouped
            groups = LY.group_positions(fams, grouped)
            cw = max(canvas.ClientSize.Width, 100)
            st["lay"] = LY.compute_layout(groups, cw, st["mode"], st["dens"], PAD, GAP, LIST_H)
            sync_scroll()
        except Exception:
            log_err(u"relayout")
        canvas.Invalidate()

    def apply_scroll(v):
        st["busy"] = True
        try:
            vs.Value = int(max(0, min(max(vs.Maximum - vs.LargeChange + 1, 0), round(v))))
        except Exception:
            pass
        finally:
            st["busy"] = False
        canvas.Invalidate()

    def set_target(v, instant=False):
        v = max(0.0, min(float(max_scroll()), float(v)))
        st["tgt"] = v
        if instant:
            st["cur"] = v
            apply_scroll(v)

    def ensure_visible(k, instant=False):
        r = st["lay"]["rects"].get(k)
        if r is None:
            return
        x, y, w, h = r
        ch = view_h()
        cur = st["tgt"]
        if y - PAD < cur:
            set_target(y - PAD, instant)
        elif y + h + PAD > cur + ch:
            set_target(y + h + PAD - ch, instant)

    # ------------------------------------------------ ảnh: nạp dần theo ô đang thấy
    def want_size():
        if st["mode"] == "list":
            return 96
        return 192 if st["dens"] == "L" else 128

    def best_img(key):
        for sz in SIZES:
            im = UI.fam_preview_cached(key, sz)
            if im is not None:
                return im
        return None

    def visible_ks():
        ch = view_h()
        off = vs.Value
        out = []
        for k, (x, y, w, h) in st["lay"]["rects"].items():
            if y + h >= off - h and y <= off + ch + h:
                out.append((y, k))
        out.sort()
        return [k for _y, k in out]

    def load_pending(limit=3):
        if not UI.CTX["api"]:
            return False
        n = 0
        ws = want_size()
        for k in visible_ks():
            key, fam, typ, kind, sym = items[st["vis"][k]]
            if key in st["failed"] or UI.fam_preview_cached(key, ws) is not None:
                continue
            im = UI.fam_preview(key, sym, ws)
            if im is None:
                st["failed"].add(key)
            n += 1
            if n >= limit:
                break
        return n > 0

    tm = WF.Timer()
    tm.Interval = 30

    def on_tick(s, e):
        try:
            d = st["tgt"] - st["cur"]
            if abs(d) >= 0.5:
                st["cur"] = st["cur"] + (d * 0.38 if abs(d) > 3 else d)
                apply_scroll(st["cur"])
                return
            if d != 0:
                st["cur"] = st["tgt"]
                apply_scroll(st["cur"])
            if load_pending():
                canvas.Invalidate()
        except Exception:
            log_err(u"timer")
    tm.Tick += on_tick

    # ------------------------------------------------ vẽ
    def draw_badge(g, kind, right, y, small):
        if not two or kind not in ("door", "window"):
            return
        bg, fg = _badge_colors(kind)
        txt_ = KIND_TXT[kind]
        fnt = font(7.5 if small else 8.5, True)
        w = int(g.MeasureString(txt_, fnt).Width) + (6 if small else 10)
        hh = 16 if small else 20
        p = UI.round_path(right - w, y, w, hh, 7)
        br = SolidBrush(bg)
        g.FillPath(br, p)
        br.Dispose()
        p.Dispose()
        _txt(g, txt_, fnt, right - w, y, w, hh, fg, 1)

    def draw_img(g, key, box):
        im = best_img(key)
        if im is None:
            pen = Pen(t["border"], 1.0)
            try:
                g.DrawRectangle(pen, box.X + 4, box.Y + 4, box.Width - 8, box.Height - 8)
            finally:
                pen.Dispose()
            _txt(g, u"…" if key not in st["failed"] else u"—", font(12), box.X, box.Y, box.Width,
                 box.Height, t["sub"], 1)
            return
        s_ = max(16, min(box.Width, box.Height))
        g.DrawImage(im, Rectangle(box.X + (box.Width - s_) // 2, box.Y + (box.Height - s_) // 2, s_, s_))

    def draw_tile(g, k, rc):
        key, fam, typ, kind, sym = items[st["vis"][k]]
        sel = (k == st["sel"])
        hov = (k == st["hover"])
        p = UI.round_path(rc.X, rc.Y, rc.Width - 1, rc.Height - 1, 8)
        try:
            br = SolidBrush(t["sel"] if sel else (t["card_hover"] if hov else t["card"]))
            try:
                g.FillPath(br, p)
            finally:
                br.Dispose()
            pen = Pen(t["accent"] if sel else t["border"], 2.0 if sel else 1.0)
            try:
                g.DrawPath(pen, p)
            finally:
                pen.Dispose()
        finally:
            p.Dispose()
        tcol = t["sel_text"] if sel else t["text"]
        scol = t["sel_text"] if sel else t["sub"]
        small = st["dens"] == "S"
        if st["mode"] == "grid":
            if st["grouped"]:
                ta = 34
                draw_img(g, key, Rectangle(rc.X + 6, rc.Y + 6, rc.Width - 12, rc.Height - 12 - ta))
                _txt(g, typ, font(8.5 if small else 9.5, True), rc.X + 6, rc.Bottom - ta - 4,
                     rc.Width - 12, ta, tcol, 1, True)
            else:
                ta = 38
                draw_img(g, key, Rectangle(rc.X + 6, rc.Y + 6, rc.Width - 12, rc.Height - 12 - ta))
                _txt(g, typ, font(8.5 if small else 9.5, True), rc.X + 6, rc.Bottom - ta - 2,
                     rc.Width - 12, 19, tcol, 1)
                _txt(g, fam, font(7.5 if small else 8.5), rc.X + 6, rc.Bottom - 21,
                     rc.Width - 12, 17, scol, 1)
            draw_badge(g, kind, rc.Right - 8, rc.Y + 8, small)
        else:
            draw_img(g, key, Rectangle(rc.X + 8, rc.Y + 6, 48, rc.Height - 12))
            _txt(g, typ, font(10, True), rc.X + 68, rc.Y + 8, rc.Width - 200, 24, tcol)
            _txt(g, fam, font(9), rc.X + 68, rc.Y + 32, rc.Width - 200, 22, scol)
            draw_badge(g, kind, rc.Right - 12, rc.Y + (rc.Height - 20) // 2, False)

    def draw_head(g, y, h, title, cw):
        _txt(g, title, font(10, True), PAD + 2, y, cw - PAD * 2, h - 4, t["text"])
        pen = Pen(t["border"], 1.0)
        try:
            g.DrawLine(pen, PAD, y + h - 3, cw - PAD, y + h - 3)
        finally:
            pen.Dispose()

    def on_paint(s, e):
        g = e.Graphics
        try:
            g.SmoothingMode = SmoothingMode.AntiAlias
            g.InterpolationMode = InterpolationMode.HighQualityBicubic
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit
            g.Clear(t["bg"])
        except Exception:
            log_err(u"paint-init")
        try:
            vis = st["vis"]
            cw = max(canvas.ClientSize.Width, 100)
            ch = view_h()
            if not vis:
                _txt(g, u"Không có family nào khớp.  Thử gõ ngắn hơn hoặc bỏ lọc loại.",
                     font(10.5), 0, 20, cw, 60, t["sub"], 1)
                return
            off = vs.Value
            L = st["lay"]
            for (hy, hh, ttl) in L["heads"]:
                if hy - off + hh < 0 or hy - off > ch:
                    continue
                try:
                    draw_head(g, hy - off, hh, ttl, cw)
                except Exception:
                    log_err(u"head")
            for k, (x, y, w, h) in L["rects"].items():
                if y - off + h < 0 or y - off > ch:
                    continue
                try:
                    draw_tile(g, k, Rectangle(x, y - off, w, h))
                except Exception:
                    log_err(u"tile")
        except Exception:
            log_err(u"paint")

    canvas.Paint += on_paint

    # ------------------------------------------------ cập nhật dữ liệu
    def update_side():
        k = st["sel"]
        if 0 <= k < len(st["vis"]):
            key, fam, typ, kind, sym = items[st["vis"][k]]
            pic.Image = UI.fam_preview(key, sym, 192) or best_img(key)
            l_typ.Text = typ
            l_fam.Text = u"Family:  " + fam
            l_kind.Text = KIND_TXT.get(kind, u"")
            l_hint.Text = u"{} type trong family này".format(fam_total.get(fam, 1))
        else:
            pic.Image = None
            l_typ.Text = u""
            l_fam.Text = u""
            l_kind.Text = u""
            l_hint.Text = u""

    def refilter(keep_current=False):
        q = tb.Text
        kind = st["kind"]
        base = [i for i, it in enumerate(items) if kind == "all" or it[3] == kind]
        if UI.norm(q).strip():
            sc = []
            for i in base:
                v = UI.smart_score(q, items[i][0] + u" " + KIND_TXT.get(items[i][3], u""))
                if v > 0:
                    sc.append((-v, i))
            sc.sort()
            vis = [i for _v, i in sc]
        else:
            vis = base
        st["vis"] = vis
        st["sel"] = 0 if vis else -1
        if keep_current and current:
            for k, i in enumerate(vis):
                if items[i][0] == current:
                    st["sel"] = k
                    break
        st["cur"] = st["tgt"] = 0.0
        relayout()
        ensure_visible(st["sel"], True)
        lb_n.Text = u"{} type  ·  {} family".format(
            len(vis), len(set(items[i][1] for i in vis)))
        lay_top()
        update_side()
        canvas.Invalidate()

    def style_toggles():
        b_grp.Tag = "chip_on" if st["group"] else "chip"
        b_grid.Tag = "chip_on" if st["mode"] == "grid" else "chip"
        b_list.Tag = "chip_on" if st["mode"] == "list" else "chip"
        for d, b in dbtn.items():
            b.Tag = "chip_on" if (st["dens"] == d and st["mode"] == "grid") else "chip"
            b.Visible = st["mode"] == "grid"
        b_grp.Visible = st["mode"] == "grid"
        UI.style_controls(top)

    def set_kind(k):
        st["kind"] = k
        for kk, b in chips.items():
            b.Tag = "chip_on" if kk == k else "chip"
        UI.style_controls(top)
        refilter()
        tb.Focus()

    def set_mode(m):
        st["mode"] = m
        style_toggles()
        keep = st["sel"]
        relayout()
        ensure_visible(keep, True)
        tb.Focus()

    def set_dens(d):
        st["dens"] = d
        if st["mode"] != "grid":
            st["mode"] = "grid"
        style_toggles()
        keep = st["sel"]
        relayout()
        ensure_visible(keep, True)
        tb.Focus()

    def toggle_group(s=None, e=None):
        st["group"] = not st["group"]
        style_toggles()
        keep = st["sel"]
        relayout()
        ensure_visible(keep, True)
        tb.Focus()

    for kk, b in chips.items():
        b.Click += (lambda k_: (lambda s, e: set_kind(k_)))(kk)
    for dd, b in dbtn.items():
        b.Click += (lambda d_: (lambda s, e: set_dens(d_)))(dd)
    b_grid.Click += lambda s, e: set_mode("grid")
    b_list.Click += lambda s, e: set_mode("list")
    b_grp.Click += toggle_group

    def accept():
        if 0 <= st["sel"] < len(st["vis"]):
            f.DialogResult = WF.DialogResult.OK
            f.Close()

    def select(k):
        st["sel"] = k
        ensure_visible(k)
        update_side()
        canvas.Invalidate()

    def move_v(direction, times=1):
        k = st["sel"]
        for _ in range(times):
            k = LY.nav_vertical(st["lay"]["rects"], k, direction)
        if k != st["sel"]:
            select(k)

    def move_h(delta):
        n = len(st["vis"])
        if n:
            select(max(0, min(n - 1, st["sel"] + delta)))

    def tb_key(s, e):
        kc = e.KeyCode
        if kc == WF.Keys.Down:
            move_v(1)
        elif kc == WF.Keys.Up:
            move_v(-1)
        elif kc == WF.Keys.PageDown:
            move_v(1, 3)
        elif kc == WF.Keys.PageUp:
            move_v(-1, 3)
        elif kc == WF.Keys.Right and (e.Control or not tb.Text):
            move_h(1)
        elif kc == WF.Keys.Left and (e.Control or not tb.Text):
            move_h(-1)
        elif kc == WF.Keys.Enter:
            accept()
        else:
            return
        e.Handled = True
        e.SuppressKeyPress = True
    tb.KeyDown += tb_key
    tb.TextChanged += lambda s, e: refilter()

    def wheel(s, e):
        try:
            if _ctrl_down():
                order = list(LY.DENS_ORDER)
                i = order.index(st["dens"])
                i = max(0, min(len(order) - 1, i + (1 if e.Delta > 0 else -1)))
                if order[i] != st["dens"] or st["mode"] != "grid":
                    set_dens(order[i])
                return
            step = max(40.0, 0.8 * st["lay"]["step"])
            set_target(st["tgt"] - (e.Delta / 120.0) * step)
        except Exception:
            log_err(u"wheel")
    canvas.MouseWheel += wheel
    tb.MouseWheel += wheel

    def vs_changed(s, e):
        if not st["busy"]:
            st["cur"] = st["tgt"] = float(vs.Value)
        canvas.Invalidate()
    vs.ValueChanged += vs_changed

    def mhit(x, y):
        return LY.hit(st["lay"]["rects"], x, y + vs.Value)

    def mmove(s, e):
        k = mhit(e.X, e.Y)
        canvas.Cursor = WF.Cursors.Hand if k >= 0 else WF.Cursors.Default
        if k != st["hover"]:
            st["hover"] = k
            canvas.Invalidate()
    canvas.MouseMove += mmove

    def mleave(s, e):
        st["hover"] = -1
        canvas.Invalidate()
    canvas.MouseLeave += mleave

    def mdown(s, e):
        k = mhit(e.X, e.Y)
        if k >= 0:
            st["sel"] = k
            update_side()
            canvas.Invalidate()
        tb.Focus()
    canvas.MouseDown += mdown

    def mdbl(s, e):
        k = mhit(e.X, e.Y)
        if k >= 0:
            st["sel"] = k
            accept()
    canvas.MouseDoubleClick += mdbl
    canvas.Resize += lambda s, e: relayout()

    # ------------------------------------------------ khởi động
    UI.style_controls(f)
    side.BackColor = t["panel"]
    for kk, b in chips.items():
        b.Tag = "chip_on" if kk == st["kind"] else "chip"
    style_toggles()
    tb.Text = initial or u""

    def shown(s, e):
        UI.set_titlebar(f)
        UI.set_placeholder(tb, u"Gõ để tìm family…  vd: s1, sliding, cua di")
        tb.Focus()
        tb.SelectionStart = len(tb.Text)
        tb.SelectionLength = 0
        refilter(True)
        tm.Start()
    f.Shown += shown

    def closed(s, e):
        try:
            tm.Stop()
            tm.Dispose()
        except Exception:
            pass
        try:
            UI.SET["pk_mode"] = st["mode"]
            UI.SET["pk_dens"] = st["dens"]
            UI.SET["pk_group"] = bool(st["group"])
            UI.save_settings()
        except Exception:
            pass
    f.FormClosed += closed
    lay_top()
    refilter(True)
    res = f.ShowDialog()
    out = None
    if res == WF.DialogResult.OK and 0 <= st["sel"] < len(st["vis"]):
        out = items[st["vis"][st["sel"]]][0]
    f.Dispose()
    return out
