# -*- coding: utf-8 -*-
"""Dựng TƯỜNG từ CAD (thuật toán của tool 'CAD → Tường').

- Đọc layer tường từ file CAD link/import (ImportInstance) trong Revit
- Chế độ 2 nét/tường (tự tìm tim + độ dày) hoặc 1 nét (nét = tim tường)
- Nối liền tường qua các lỗ cửa đi / cửa sổ (chỉ nối chỗ có nét cửa)
- Căn tường thẳng hàng & phẳng với lưới (Grid) gần nhất
- Kéo/cắt góc tường cho khớp nhau

Đơn vị trong module này: FEET (hệ toạ độ Revit). FT = đổi mm -> feet.
Không có giao diện: form nằm ở script.py, module chỉ nhận dict cài đặt S.
"""
import math
import bisect
from Autodesk.Revit.DB import (
    FilteredElementCollector, Options, ViewDetailLevel, GeometryInstance,
    Line, PolyLine, Curve, Grid, WallType, WallKind, Wall, XYZ, Transaction,
    BuiltInParameter, ElementId, Solid, Mesh,
)
import b2r_build as B

FT = 1.0 / 304.8          # mm -> feet
NOLAYER = u"(không layer)"


# ----------------------------------------------------------------------------
# Vector 2D
# ----------------------------------------------------------------------------
def sub(a, b): return (a[0] - b[0], a[1] - b[1])
def add(a, b): return (a[0] + b[0], a[1] + b[1])
def mul(a, k): return (a[0] * k, a[1] * k)
def dot(a, b): return a[0] * b[0] + a[1] * b[1]
def cross(a, b): return a[0] * b[1] - a[1] * b[0]
def length(a): return math.hypot(a[0], a[1])


def unit(a):
    d = length(a)
    return (a[0] / d, a[1] / d) if d > 1e-12 else (1.0, 0.0)


def _new_tx(doc, name):
    """Transaction tự xoá CẢNH BÁO (overlap, join...) khi commit để Revit không bật hộp thoại."""
    t = Transaction(doc, name)
    try:
        pre, _err = B.get_stair_pre()
        if pre is not None:
            o = t.GetFailureHandlingOptions()
            o.SetFailuresPreprocessor(pre)
            o.SetClearAfterRollback(True)
            t.SetFailureHandlingOptions(o)
    except Exception:
        pass
    return t


def _safe_rollback(t):
    try:
        if t.HasStarted():
            t.RollBack()
    except Exception:
        pass


# ----------------------------------------------------------------------------
# Đọc hình học CAD
# ----------------------------------------------------------------------------
def _walk(geom):
    for obj in geom:
        if isinstance(obj, GeometryInstance):
            for sub_obj in _walk(obj.GetInstanceGeometry()):
                yield sub_obj
        else:
            yield obj


def _layer_name(doc, obj):
    try:
        gid = obj.GraphicsStyleId
        if gid is None or gid.Equals(ElementId.InvalidElementId):
            return u""
        gs = doc.GetElement(gid)
        if gs is None:
            return u""
        cat = gs.GraphicsStyleCategory
        if cat is not None and cat.Name:
            return cat.Name
        return gs.Name or u""
    except Exception:
        pass
    return u""


def _cad_geometry(doc, ii):
    """Hình học CAD: đọc với View hiện tại trước (layer/block gắn đúng tên);
    không ra gì thì thử lại không gắn View."""
    geom = None
    for use_view in (True, False):
        try:
            opt = Options()
            opt.DetailLevel = ViewDetailLevel.Fine
            opt.IncludeNonVisibleObjects = True
            if use_view:
                opt.View = doc.ActiveView
            g = ii.get_Geometry(opt)
            if g is not None and any(True for _ in g):
                geom = g
                break
        except Exception:
            pass
    return geom


def _walk_tagged(doc, geom, inherited=frozenset()):
    """Như _walk nhưng trả (obj, tập layer): layer của chính đối tượng + layer của các block cha,
    nên block đặt trên layer cửa mà nét bên trong ở layer 0 vẫn được nhận."""
    for obj in geom:
        own = _layer_name(doc, obj)
        tags = (inherited | frozenset([own])) if own else inherited
        if isinstance(obj, GeometryInstance):
            for r in _walk_tagged(doc, obj.GetInstanceGeometry(), tags):
                yield r
        else:
            yield obj, tags


def _subcategory_layers(ii):
    names = set()
    try:
        cat = ii.Category
        if cat is not None:
            for sc in cat.SubCategories:
                try:
                    if sc.Name:
                        names.add(sc.Name)
                except Exception:
                    pass
    except Exception:
        pass
    return names


def list_layers(doc, ii):
    names = set()
    geom = _cad_geometry(doc, ii)
    if geom is not None:
        for obj, tags in _walk_tagged(doc, geom):
            if isinstance(obj, (PolyLine, Curve, Solid, Mesh)):
                names.update(tags if tags else [NOLAYER])
    names |= _subcategory_layers(ii)
    return sorted(names)


def collect_segments(doc, ii, layers):
    """list ((x,y),(x,y)) feet (hệ toạ độ Revit) của các nét thẳng trên layer đã chọn."""
    layers = set(layers)
    segs = []
    geom = _cad_geometry(doc, ii)
    if geom is None:
        return segs
    for obj in _walk(geom):
        if _layer_name(doc, obj) not in layers:
            continue
        if isinstance(obj, Line):
            p, q = obj.GetEndPoint(0), obj.GetEndPoint(1)
            segs.append(((p.X, p.Y), (q.X, q.Y)))
        elif isinstance(obj, PolyLine):
            pts = list(obj.GetCoordinates())
            for i in range(len(pts) - 1):
                segs.append(((pts[i].X, pts[i].Y), (pts[i + 1].X, pts[i + 1].Y)))
    return segs


# ----------------------------------------------------------------------------
# Hình học CỬA (chỉ để biết chỗ nào có cửa)
# ----------------------------------------------------------------------------
def _sample_seg(out, p, q, step):
    d = length(sub(q, p))
    n = max(1, int(d / step))
    for k in range(n + 1):
        f = float(k) / n
        out.append((p[0] + (q[0] - p[0]) * f, p[1] + (q[1] - p[1]) * f))


def collect_door_points(doc, ii, layers):
    """Lấy mẫu điểm (x,y feet) của các nét thuộc layer cửa: Line, PolyLine, Arc/Curve (kể cả trong block)."""
    layers = frozenset(layers)
    step = 50 * FT
    pts = []
    geom = _cad_geometry(doc, ii)
    if geom is None:
        return pts
    for obj, tags in _walk_tagged(doc, geom):
        if not (tags & layers):
            continue
        if isinstance(obj, Line):
            p, q = obj.GetEndPoint(0), obj.GetEndPoint(1)
            _sample_seg(pts, (p.X, p.Y), (q.X, q.Y), step)
        elif isinstance(obj, PolyLine):
            c = list(obj.GetCoordinates())
            for i in range(len(c) - 1):
                _sample_seg(pts, (c[i].X, c[i].Y), (c[i + 1].X, c[i + 1].Y), step)
        elif isinstance(obj, Curve):
            try:
                c = list(obj.Tessellate())
                for i in range(len(c) - 1):
                    _sample_seg(pts, (c[i].X, c[i].Y), (c[i + 1].X, c[i + 1].Y), step)
            except Exception:
                pass
    return pts


def _door_in_gap(dpts, dts, g0, g1, s, half, tol_l, tol_t):
    """dpts: list (t, s) đã SẮP THEO t; dts: list t tương ứng (để bisect).
    Trả (có_cửa, khoảng_cách_gần_nhất_feet). Có cửa khi các nét hợp lệ phủ >= 40% bề rộng hở."""
    W = max(tol_t, 1500.0 / 304.8)
    a = bisect.bisect_left(dts, g0 - W)
    b = bisect.bisect_right(dts, g1 + W)
    best = None
    tmin = tmax = None
    for k in range(a, b):
        t, sd = dpts[k]
        dt = 0.0 if g0 <= t <= g1 else min(abs(t - g0), abs(t - g1))
        dl = max(0.0, abs(sd - s) - half)
        d = max(dt, dl)
        if best is None or d < best:
            best = d
        if dt <= tol_t and dl <= tol_l:
            tmin = t if tmin is None else min(tmin, t)
            tmax = t if tmax is None else max(tmax, t)
    if tmin is not None and (tmax - tmin) >= 0.4 * (g1 - g0):
        return True, best
    return False, best


# ----------------------------------------------------------------------------
# Tạo "mảnh tường" từ các nét CAD
# ----------------------------------------------------------------------------
def _cluster_by_direction(segs, ang_tol, min_len, stats=None):
    items = []
    for p, q in segs:
        d = sub(q, p)
        L = length(d)
        if L < min_len:
            if stats is not None:
                stats['short_seg'] += 1
            continue
        a = math.atan2(d[1], d[0]) % math.pi
        items.append((a, p, q, L))
    items.sort(key=lambda x: x[0])
    clusters = []
    for it in items:
        if clusters and it[0] - clusters[-1][0][0] <= ang_tol:
            clusters[-1].append(it)
        else:
            clusters.append([it])
    if len(clusters) > 1 and clusters[0][0][0] + math.pi - clusters[-1][0][0] <= ang_tol:
        clusters[0].extend(clusters.pop())
    return clusters


def _t_overlap(a, b):
    return min(a[3], b[3]) - max(a[2], b[2])


def make_wall_pieces(segs, S):
    ang_tol = math.radians(S['ang_tol'])
    walls = []
    bridged = 0
    skipped = 0           # số chỗ hở KHÔNG nối vì không có cửa
    skipped_info = []     # (bề rộng hở, khoảng cách nét cửa gần nhất) để báo
    use_door = bool(S.get('door_layers'))
    stats = S['stats']
    for cl in _cluster_by_direction(segs, ang_tol, S['seg_min'], stats):
        longest = max(cl, key=lambda x: x[3])
        d0 = unit(sub(longest[2], longest[1]))
        n0 = (-d0[1], d0[0])
        dpts = None
        dts = None
        lines = []        # (s, t0, t1)
        for _, p, q, _L in cl:
            tp, tq = dot(p, d0), dot(q, d0)
            s = (dot(p, n0) + dot(q, n0)) / 2.0
            lines.append((s, min(tp, tq), max(tp, tq)))
        lines.sort()

        pieces = []       # (th, s, t0, t1)
        if S['double']:
            n = len(lines)
            cand = []     # (gap, s_mid, t0, t1, i, j)
            for i in range(n):
                si, a0, a1 = lines[i]
                for j in range(i + 1, n):
                    sj, b0, b1 = lines[j]
                    gap = sj - si
                    if gap > S['tmax']:
                        break
                    if gap < S['tmin']:
                        continue
                    t0, t1 = max(a0, b0), min(a1, b1)
                    if t1 - t0 < S['min_overlap']:
                        continue
                    # chỉ ghép 2 nét KỀ NHAU: bỏ phần bị nét khác nằm GIỮA che mất
                    blocks = []
                    for k in range(i + 1, j):
                        sk, k0, k1 = lines[k]
                        if sk - si > 1 * FT and sj - sk > 1 * FT and k1 > t0 and k0 < t1:
                            blocks.append((max(k0, t0), min(k1, t1)))
                    blocks.sort()
                    cur = t0
                    for bb0, bb1 in blocks + [(t1, t1)]:
                        if bb0 - cur >= S['min_overlap']:
                            cand.append((gap, (si + sj) / 2.0, cur, bb0, i, j))
                        cur = max(cur, bb1)
            # bỏ "khe không khí" nằm giữa 2 tường
            by_i, by_j = {}, {}
            for c in cand:
                by_i.setdefault(c[4], []).append(c)
                by_j.setdefault(c[5], []).append(c)
            for c in cand:
                below = [q for q in by_j.get(c[4], []) if _t_overlap(c, q) >= S['min_overlap']]
                above = [r for r in by_i.get(c[5], []) if _t_overlap(c, r) >= S['min_overlap']]
                if below and above:
                    continue
                pieces.append((c[0], c[1], c[2], c[3]))
        else:
            for s, t0, t1 in lines:
                pieces.append((S['base_width'], s, t0, t1))

        # nhóm theo (độ dày, s). Có cửa: nới dung sai vì CAD vẽ thường lệch vài chục mm
        s_tol = (40 if use_door else 10) * FT
        th_tol = (30 if use_door else 5) * FT
        pieces.sort(key=lambda p: p[1])
        groups = []
        for pc in pieces:
            placed = False
            for g in reversed(groups):
                if pc[1] - g['s0'] > s_tol:
                    break
                if abs(pc[0] - g['th0']) <= th_tol:
                    g['items'].append(pc)
                    placed = True
                    break
            if not placed:
                groups.append({'s0': pc[1], 'th0': pc[0], 'items': [pc]})

        for g in groups:
            its = sorted(g['items'], key=lambda x: x[2])
            th = sum(x[0] for x in its) / len(its)
            s = sum(x[1] for x in its) / len(its)
            cur0, cur1 = its[0][2], its[0][3]
            merged = []
            for _, _s, t0, t1 in its[1:]:
                if t0 <= cur1 + 1 * FT:
                    cur1 = max(cur1, t1)              # chạm / chồng nhau -> gộp
                elif t0 <= cur1 + S['max_gap']:
                    ok, near = True, None
                    if use_door:
                        if dpts is None:
                            dpts = sorted((dot(p, d0), dot(p, n0)) for p in S['door_pts'])
                            dts = [x[0] for x in dpts]
                        ok, near = _door_in_gap(dpts, dts, cur1, t0, s, th / 2.0,
                                                S['door_tol'], 200 * FT)
                    if ok:
                        bridged += 1
                        cur1 = max(cur1, t1)
                    else:
                        skipped += 1                  # hở không có cửa -> để hở
                        skipped_info.append((t0 - cur1, near))
                        merged.append((cur0, cur1))
                        cur0, cur1 = t0, t1
                else:
                    merged.append((cur0, cur1))
                    cur0, cur1 = t0, t1
            merged.append((cur0, cur1))
            for t0, t1 in merged:
                if t1 - t0 < S['min_len']:
                    stats['short_piece'].append(t1 - t0)
                    continue
                p0 = add(mul(d0, t0), mul(n0, s))
                p1 = add(mul(d0, t1), mul(n0, s))
                walls.append({'p0': p0, 'p1': p1, 'th': th})
    return walls, bridged, skipped, skipped_info


# ----------------------------------------------------------------------------
# Căn theo lưới
# ----------------------------------------------------------------------------
def collect_grids(doc):
    res = []
    for g in FilteredElementCollector(doc).OfClass(Grid):
        c = g.Curve
        if isinstance(c, Line):
            p = c.GetEndPoint(0)
            d = unit((c.Direction.X, c.Direction.Y))
            res.append(((p.X, p.Y), d, (-d[1], d[0])))
    return res


def snap_to_grid(walls, grids, S):
    sin_tol = math.sin(math.radians(S['grid_ang_tol']))
    count = 0
    for w in walls:
        p0, p1 = w['p0'], w['p1']
        L = length(sub(p1, p0))
        wd = unit(sub(p1, p0))
        mid = mul(add(p0, p1), 0.5)
        h = w.get('width', w['th']) / 2.0
        best = None
        for g0, gd, gn in grids:
            if abs(cross(wd, gd)) > sin_tol:
                continue
            s = dot(sub(mid, g0), gn)
            # tim trước (hoà thì ưu tiên tim), rồi 2 mặt tường
            cands = [s, s - h, s + h] if S['snap_face'] else [s]
            for c in cands:
                if best is None or abs(c) < abs(best[0]):
                    best = (c, gd, gn)
        if best is not None and abs(best[0]) <= S['snap_tol']:
            c, gd, gn = best
            if dot(wd, gd) < 0:
                gd = (-gd[0], -gd[1])
            newmid = (mid[0] - gn[0] * c, mid[1] - gn[1] * c)
            w['p0'] = sub(newmid, mul(gd, L / 2.0))
            w['p1'] = add(newmid, mul(gd, L / 2.0))
            w['snapped'] = True
            count += 1
    return count


# ----------------------------------------------------------------------------
# Khớp góc / T
# ----------------------------------------------------------------------------
def fix_corners(walls, S):
    snap = [(tuple(w['p0']), tuple(w['p1']), w['th']) for w in walls]
    ext = S['ext_tol']
    for ia, a in enumerate(walls):
        for e in (0, 1):
            pt = a['p0'] if e == 0 else a['p1']
            da = unit(sub(a['p1'], a['p0']))
            best = None
            for ib, (b0, b1, _bth) in enumerate(snap):
                if ib == ia:
                    continue
                Lb = length(sub(b1, b0))
                db = unit(sub(b1, b0))
                if abs(dot(da, db)) > 0.17:   # chỉ lấy tường ~vuông góc
                    continue
                cr = cross(da, db)
                if abs(cr) < 1e-9:
                    continue
                u = cross(sub(b0, pt), db) / cr   # khoảng cách dọc tường a từ pt tới giao điểm
                X = add(pt, mul(da, u))
                vb = dot(sub(X, b0), db)
                half = a.get('width', a['th']) / 2.0
                if abs(u) <= ext and -(half + ext) <= vb <= Lb + half + ext:
                    if best is None or abs(u) < abs(best[0]):
                        best = (u, X)
            if best is not None:
                if e == 0:
                    a['p0'] = best[1]
                else:
                    a['p1'] = best[1]


# ----------------------------------------------------------------------------
# Tạo tường
# ----------------------------------------------------------------------------
def basic_wall_types(doc):
    res = []
    for wt in FilteredElementCollector(doc).OfClass(WallType):
        try:
            if wt.Kind == WallKind.Basic:
                res.append(wt)
        except Exception:
            pass
    return sorted(res, key=lambda x: x.Name)


def pick_type(doc, base, th_ft, cache, S):
    if not S['auto_type']:
        return base
    key = int(round(th_ft / FT / 5.0) * 5)
    if key in cache:
        return cache[key]
    for wt in basic_wall_types(doc):
        if abs(wt.Width - key * FT) <= 2 * FT:
            cache[key] = wt
            return wt
    new = None
    try:
        dup = base.Duplicate("%s_%dmm" % (base.Name, key))
        new = doc.GetElement(dup.Id)
        cs = new.GetCompoundStructure()
        if cs is not None and cs.LayerCount == 1:
            cs.SetLayerWidth(0, key * FT)
            new.SetCompoundStructure(cs)
        else:
            new = None
    except Exception:
        new = None
    if new is None:       # dự phòng: type gần độ dày nhất
        new = min(basic_wall_types(doc), key=lambda x: abs(x.Width - key * FT))
    cache[key] = new
    return new


def resolve_types(doc, walls, S):
    """Chọn/tạo Wall Type trước khi căn lưới để biết BỀ DÀY THẬT của tường."""
    cache = {}
    t = _new_tx(doc, u"CAD Wall types")
    t.Start()
    try:
        for w in walls:
            wt = pick_type(doc, S['wall_type'], w['th'], cache, S)
            w['wt'] = wt
            w['width'] = wt.Width
        t.Commit()
    except Exception:
        _safe_rollback(t)
        raise
    return sum(1 for w in walls if abs(w['width'] - w['th']) > 2 * FT)


def create_walls(doc, walls, S):
    base_level = S['base_level']
    top_level = S['top_level']
    z = base_level.Elevation
    if top_level is not None:
        h = top_level.Elevation - base_level.Elevation
    else:
        h = S['height']
    if h <= 0:
        h = 3300 * FT
    created = 0
    failed = 0
    cache = {}
    t = _new_tx(doc, u"CAD to Wall")
    t.Start()
    try:
        for w in walls:
            if length(sub(w['p1'], w['p0'])) < S['min_len']:
                continue
            try:
                line = Line.CreateBound(XYZ(w['p0'][0], w['p0'][1], z), XYZ(w['p1'][0], w['p1'][1], z))
                wt = w.get('wt') or pick_type(doc, S['wall_type'], w['th'], cache, S)
                wall = Wall.Create(doc, line, wt.Id, base_level.Id, h, S['base_off'], False, False)
                p = wall.get_Parameter(BuiltInParameter.WALL_KEY_REF_PARAM)
                if p is not None and not p.IsReadOnly:
                    p.Set(0)      # Wall Centerline
                if top_level is not None:
                    pt = wall.get_Parameter(BuiltInParameter.WALL_HEIGHT_TYPE)
                    if pt is not None and not pt.IsReadOnly:
                        pt.Set(top_level.Id)
                    po = wall.get_Parameter(BuiltInParameter.WALL_TOP_OFFSET)
                    if po is not None and not po.IsReadOnly:
                        po.Set(S['top_off'])
                created += 1
            except Exception:
                failed += 1
        t.Commit()
    except Exception:
        _safe_rollback(t)
        raise
    return created, failed


# ----------------------------------------------------------------------------
# Chạy cả quy trình
# ----------------------------------------------------------------------------
def _range_text(S):
    base, top = S['base_level'], S['top_level']
    boff = int(round(S['base_off'] / FT))
    toff = int(round(S['top_off'] / FT))
    if top is not None:
        return u"%s → %s (offset chân %d mm, đỉnh %d mm)" % (base.Name, top.Name, boff, toff)
    return u"%s, cao %d mm (offset chân %d mm)" % (base.Name, int(round(S['height'] / FT)), boff)


def analyze(doc, S):
    """Bước 1 (KHÔNG sửa model): đọc nét CAD -> ghép thành mảnh tường.
    Trả (A, lỗi): A là dict kết quả (None nếu không ghép được), lỗi là câu báo."""
    segs = collect_segments(doc, S['cad'], S['layers'])
    if not segs:
        return None, u"Không có đường line nào trong layer tường đã chọn."
    S['door_pts'] = []
    notes = []
    if S['door_layers']:
        S['door_pts'] = collect_door_points(doc, S['cad'], S['door_layers'])
        if not S['door_pts']:
            notes.append(u"⚠ Không đọc được nét nào trong layer cửa đã chọn -> KHÔNG nối tường qua chỗ hở nào "
                         u"(tool đọc Line / Polyline / Arc, kể cả nằm trong block).")
    S['stats'] = {'short_seg': 0, 'short_piece': []}
    walls, bridged, skipped, skipped_info = make_wall_pieces(segs, S)
    if not walls:
        return None, u"Không tạo được tường. Kiểm tra lại kiểu vẽ (1 nét / 2 nét) và khoảng dày tường."
    return {"pieces": walls, "bridged": bridged, "skipped": skipped, "skipped_info": skipped_info,
            "stats": S['stats'], "notes": notes, "nsegs": len(segs)}, u""


def preview(doc, S, A):
    """Vị trí tường dự kiến (đã căn lưới + khớp góc) để xem trước. Không sửa model.
    Trả (list tường, số tường căn lưới). Độ dày xem trước = độ dày đo từ CAD."""
    ws = [dict(w) for w in A["pieces"]]
    snapped = 0
    if S['do_grid']:
        grids = collect_grids(doc)
        if grids:
            snapped = snap_to_grid(ws, grids, S)
    fix_corners(ws, S)
    return ws, snapped


def type_preview(doc, S, th_ft):
    """Tên Wall Type sẽ dùng cho độ dày th_ft (không tạo gì)."""
    if not S['auto_type']:
        return S['wall_type'].Name
    key = int(round(th_ft / FT / 5.0) * 5)
    for wt in basic_wall_types(doc):
        if abs(wt.Width - key * FT) <= 2 * FT:
            return wt.Name
    return u"(tạo mới %s_%dmm)" % (S['wall_type'].Name, key)


def build(doc, S, A):
    """Bước 2: chọn/tạo type -> căn lưới -> khớp góc -> dựng tường.
    Trả (số tường tạo, số lỗi, [dòng thông báo]); dòng đầu là tóm tắt."""
    walls = [dict(w) for w in A["pieces"]]
    bridged, skipped, skipped_info = A["bridged"], A["skipped"], A["skipped_info"]
    notes = list(A["notes"])
    thick_diff = resolve_types(doc, walls, S)
    snapped = 0
    if S['do_grid']:
        grids = collect_grids(doc)
        if not grids:
            notes.append(u"⚠ Project không có Grid dạng đường thẳng - bỏ qua bước căn lưới.")
        else:
            snapped = snap_to_grid(walls, grids, S)

    fix_corners(walls, S)
    created, failed = create_walls(doc, walls, S)

    if S['door_layers']:
        gap_info = (u"%d chỗ hở có cửa được nối liền; %d chỗ hở KHÔNG nối (không thấy cửa)"
                    % (bridged, skipped))
        near_list = sorted([a for a in skipped_info if a[1] is not None], key=lambda a: a[1])[:5]
        if near_list:
            notes.append(u"Chỗ hở gần cửa nhất (nếu thực ra có cửa, tăng 'Cửa cách tường tối đa' lên >= số 'cửa cách'): "
                         + u"; ".join(u"hở %d mm, nét cửa gần nhất cách %d mm"
                                      % (round(gp / FT), round(nr / FT)) for gp, nr in near_list))
    else:
        gap_info = u"%d chỗ hở được nối (chưa chọn layer cửa -> nối theo khoảng hở)" % bridged

    st = A["stats"]
    lines = [u"Đã tạo %d tường (lỗi %d)." % (created, failed),
             u"Tường: %s" % _range_text(S),
             gap_info,
             u"Căn phẳng theo lưới: %d / %d tường" % (snapped, len(walls))]
    if thick_diff:
        lines.append(u"%d tường có độ dày type KHÁC độ dày CAD (>2 mm): type gốc nhiều lớp nên không tự tạo được "
                     u"type đúng dày -> hãy chọn type 1 lớp hoặc tạo sẵn type đúng dày rồi chạy lại." % thick_diff)
    if st['short_piece']:
        top5 = sorted(st['short_piece'], reverse=True)[:5]
        lines.append(u"Bỏ %d đoạn tường ngắn hơn %d mm (dài nhất: %s mm) -> muốn vẽ thì giảm 'Dài tối thiểu'."
                     % (len(st['short_piece']), round(S['min_len'] / FT),
                        u", ".join(str(int(round(x / FT))) for x in top5)))
    if st['short_seg']:
        lines.append(u"Nét rác (<20 mm) bị bỏ: %d" % st['short_seg'])
    return created, failed, lines + notes


def run(doc, S):
    """Phân tích + dựng liền. Trả (số tường tạo, số lỗi, [dòng thông báo])."""
    A, err = analyze(doc, S)
    if A is None:
        return 0, 0, [err]
    return build(doc, S, A)
