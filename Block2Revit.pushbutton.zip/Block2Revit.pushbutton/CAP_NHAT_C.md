# Cập nhật đợt C: nội thất theo LAYER + tự tìm/nạp family + kiểm chéo hướng

## Thay đổi
1. **Bỏ nhận diện nội thất** (từ khoá tên block / chữ / kích thước). Loại nội thất lấy từ **tên layer** của block
   (`b2r_furn.cat_from_layers`). Luật mặc định: GIUONG, TAB-DAU-GIUONG, TU-QUAN-AO, TU-LANH, KE-TV, SOFA, BON-CAU,
   BON-TAM, SEN-TAM, CHAU-RUA, BEP-NAU, BAN-*, GHE-*, PHU-KIEN (không tự đặt).
   Thêm/sửa luật: `settings.json` -> `"layer_rules": {"toilet": ["wc bon cau"], "bed": ["nt giuong"]}`.
2. **Tự tìm & nạp family** (`b2r_lib.py`): theo loại (layer) + kích thước thân block, chọn trong family đã có trong
   model và file .rfa trong thư viện (`fam_folder`, đệ quy). File chưa nạp được nạp vào model, chọn type gần kích
   thước nhất. Nút **Tự tìm family theo layer**; tick "Tự tìm & nạp family theo layer..." thì bấm *Đặt nội thất*
   cũng tự tìm cho dòng chưa gán. Dòng tự tìm tô vàng; đặt xong được nhớ vào mapping.json.
3. **Hướng đặt**:
   - Hộp bao của vật bầu dục/tròn (bồn cầu, ghế) được căn theo hướng tường sát nó (trước đây bị xoay tuỳ ý -> không
     bắt được tường).
   - Mặt trước theo tường/chi tiết là căn cứ chính, rồi **kiểm chéo bằng hình**: thử 4 hướng x lật/không lật, so hình
     family với hình block; chỉ đổi khi khớp tốt hơn rõ rệt (family vẽ lệch quy ước mặt trước, block bị lật gương).
   - Sau khi đặt ghi log `[HƯỚNG] ...` (mặt trước CAD, mặt trước family, độ lệch, quyết định) và báo cảnh báo nếu
     lệch > 5° hoặc hình family khác block nhiều.
4. Thêm loại: Bồn tắm, Sen tắm, Bếp nấu, Tủ lạnh, Phụ kiện.

## Giới hạn đã biết
- Dải tủ quần áo dài (4-12 m) vẫn là 1 block -> 1 family co giãn, chưa tách từng cánh.
- Vật không có tường sát (sofa, bếp giữa phòng...) không có "mặt trước" từ tường -> dùng khớp hình.
- Chưa chạy thử trong Revit (chỉ kiểm bằng DXF + dữ liệu giả). Xem Block2Revit.log dòng [HƯỚNG] / [TỰ TÌM].
